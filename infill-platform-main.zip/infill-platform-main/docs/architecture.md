# Architecture

Modular monolith (Python 3.12) over PostgreSQL 16 + PostGIS 3, with an immutable
S3 raw archive. One process, clean internal module boundaries, splittable into
services later.

```
 public sources ── extractors ──> raw archive (S3/MinIO, immutable, timestamped)
                       │
                       ▼
                 normalize + resolve ──> parcel_master   (PostGIS, EPSG:4326)
                       │                  parcel_signals  (append-only events)
                       ▼
              scoring engine (dbt SQL + Python) ──> parcel_scores (versioned)
                       │
                       ▼
                 FastAPI  ──>  React + MapLibre explorer
```

## Modules

| Module | Responsibility |
|---|---|
| `ingestion/` | One `Extractor` per source (`discover`/`extract`/`normalize`). Shared HTTP client (retry, rate-limit, offset pagination) and normalizers in `common.py`. Raw archived before transform. |
| `ingestion/resolve.py` | Reconcile every record to the canonical Auditor Property Number (`parcel_id`). |
| `ingestion/load.py` | Raw archive (S3/MinIO or local fs) + PostGIS upsert of `parcel_master` and `parcel_signals`. |
| `scoring/` | Use classification + the five-component opportunity score. `scoring.yaml` versions all thresholds/weights; every score row records its version. |
| `dbt/` | SQL-expressible metrics as models (staging → intermediate → marts). |
| `api/` | FastAPI: ranked search, parcel dossier, GeoJSON/MVT, stats. |
| `orchestration/` | Prefect flows on per-source cadences (Section 1.3). |

## Key design decisions

- **`parcel_id` is the universal join key.** Address matching is fallback only.
- **Raw is immutable.** Every score traces back to a timestamped raw extract, so
  results are reproducible and auditable.
- **Config over hardcoding.** Scoring weights live in versioned YAML; source
  endpoints are *discovered* at runtime (ArcGIS service directory / catalog APIs)
  so URL drift degrades gracefully instead of breaking the pipeline.

## Notable data discovery (Phase 1)

The spec splits the base spatial layer (CAGIS) from ownership/valuation (Auditor).
In practice the **CAGIS "Hamilton County Parcels - Open Data" FeatureServer/51**
already carries Auditor attributes — market land/improvement value, ownership,
sale history, and tax-delinquency / foreclosure flags — alongside geometry. So the
underutilization MVP (and an early distress signal) runs off one authoritative
county source. A dedicated Auditor extractor is still warranted in Phase 1b for
valuation source-of-truth and fields the Open Data layer omits (e.g. zoning,
which lives in a separate CAGIS layer and is Phase 3's concern).
