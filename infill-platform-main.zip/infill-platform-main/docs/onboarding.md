# Infill Finder — Design-Partner Guide

**Hamilton County land-development lead finder · private beta**
Your login is your email. Everything you save is private to your account.

---

## What this is

It reads the county's own records — every parcel in Hamilton County, plus
building permits, code violations, and sheriff-sale filings — and ranks the
parcels most likely to be a **land development opportunity**: vacant lots,
under-built sites, and adjacent lots under one owner that could be combined.

The point is to surface parcels **before** they're listed, obvious, or on
anyone's radar. It has already found sites that turned out to be real: one
Oakley lot flagged by the model had a new build going up on it by the time an
agent looked.

## What this is *not*

- **Not a listing service.** Almost nothing here is for sale. These are parcels
  worth a conversation with an owner.
- **Not investment, legal, or appraisal advice.** It's a research starting point.
- **Not a substitute for diligence.** Zoning, utilities, easements, soils,
  setbacks, title, and actual owner willingness are all on you.
- **Not always right.** It is a model. See "when it's wrong" below — that part
  is the most valuable thing you can give us.

All data is **public record** (Hamilton County Auditor / CAGIS, City of
Cincinnati open data). Nothing about you or your clients is collected.

---

The app has two tabs: **Discover** (find leads) and **Pipeline** (work them).

### Discover — find leads

1. **Pick your area.** Choose your neighborhood from the region selector. It's
   saved, so the app opens there next time.
2. **Read the Top 10.** Ranked best-first for that neighborhood, updating with
   your selection.
3. **Open a parcel** for the dossier: owner, absentee status, land vs building
   value, last sale, zoning capacity, distress signals, and — if it's part of a
   same-owner cluster — every underlying lot in the assemblage.
4. **＋ Add to Leads.** When a parcel looks worth pursuing, one click drops it
   into your Pipeline. Everything we know about it — score, zoning, market
   demand, signals, data checks — travels with it automatically.
5. **Export to Excel** if you'd rather work a whole list offline.

### Pipeline — work the funnel

Your saved leads live on a board with a column per stage. Move a lead right as it
progresses (← / → on the card, or click a stage inside the lead):

- **Watchlist** — your online research: comps, zoning read, owner search, why
  it's interesting.
- **Site Visit** — what you found on the ground. Add **notes and photos** (snap
  them on your phone) right from the lead.
- **Deal** — record the **offer amount, date, and terms**, plus a running log of
  the negotiation.
- **Closed** — the close price and date when you win it.
- **Passed** — anything you decide against, archived (not deleted) with the
  reason, so you remember why next time.

Everything you write is private to your account and kept between sessions — a
working notebook and CRM in one. The more you use it, the more useful it gets,
and the better the tool learns what a real lead looks like.

## What the score means

Each parcel gets a 0–100 score blended from five things you can see in the
dossier, so you can second-guess the ranking instead of trusting a black box:

| Component | Plain English |
|---|---|
| **Underutilization** | Vacant, or the building is worth little next to the land |
| **Capacity gap** | Zoning allows meaningfully more than what's there now |
| **Distress** | Code violations, sheriff sale, tax or foreclosure pressure |
| **Assemblage** | Adjacent lots under one owner that could sell as one site |
| **Demand** | How much new construction is actually happening nearby |

Parcels that can't realistically be developed — parks, schools, hospitals,
government land, condo regimes, apartment complexes, and lots where someone has
**already pulled a build permit** — are filtered out or heavily discounted.

Watch for the **⚠ Data checks** box on a dossier. It flags where the county's
own data looks odd (a value that doesn't add up, a suspicious lot size). It
doesn't change the score, but verify before you act on it.

**Data freshness** is shown in the app. Permits and violations refresh daily,
sheriff sales weekly, parcel records quarterly. If a feed is behind, you'll see
it flagged rather than being left to guess.

---

## When it's wrong — please tell us

**This is the job.** You are a design partner, not a customer. The model gets
better almost entirely by an experienced person looking at a lead and saying
*"no, that's the Deeper Roots coffee shop"* or *"that's behind the Petsmart,
nobody's building a house there."*

Both of those are real. An agent flagged four bad leads in Oakley on a Friday;
all four were diagnosed and fixed the same day, and the model's accuracy went
*up*, not down. That loop is the entire reason for this beta.

So: **a bad lead is more useful to us than a good one.** Write the reason in the
notes field on the parcel, or just text Max. One line is plenty — "that's a
church parking lot" tells us everything.

Also worth telling us:
- A lead you'd **actually pursue** (and whether you did anything about it)
- Data you need that isn't here (owner phone, lot dimensions, price estimate…)
- Anything slow, confusing, or hard to find

## The ask

Over the next few weeks, when you have a spare few minutes: find **three
parcels in your farm area you'd genuinely consider pursuing**, and flag anything
that looks wrong. We'll check in for 20 minutes a week. That's it.

---

*Private beta — please don't share your login or redistribute exports outside
your brokerage. Data is public record; the ranking is proprietary. No warranty:
verify everything before acting or advising a client.*

**Questions:** Max S · mstallmeyer1@gmail.com
