# Pilot Plan — Design-Partner Beta with Real Estate Agents

**Status:** proposed · **Owner:** Max · **Last updated:** 2026-07-26

> **Pre-pilot diligence note:** deployment is paused while we keep hardening the
> rankings — each real "that's not a lead" catch (e.g. a Kroger parking lot +
> gas station topping Oakley, fixed in scoring v2026.16) is closed before agents
> see it. This is the same loop the pilot will scale; doing a few rounds now
> keeps first impressions clean.
>
> **Loop proven with a real agent (2026-07-27).** An agent reviewed Oakley's top
> 10 unprompted: 4 hits (including one they confirmed was "a great find" where
> someone had *already built*), 4 misses each with a crisp reason (a coffee shop,
> its parking lot, lots behind a Petsmart, a food-truck lot). All 4 misses were
> diagnosed and fixed the same day (v2026.18); the model now agrees with the
> agent on all 8, and back-tested discovery lift *rose* 2.23x → 2.69x. This is
> exactly the §6 loop working — and strong evidence the pilot is the right
> investment.

## 1. Why a pilot (and not straight to production)

The intelligence is built and *validated* — 5-component score, hardened through
15 diligence-driven versions, back-tested at AUC ≈ 0.887 with 1.93× lift on
parcels that actually get developed, and weight-checked without overfitting. What
is **not** yet validated is **product-market fit**: does a working agent find the
leads useful, trustworthy, and worth acting on?

Full production (managed infra, auth, MVT tiles, autoscaling, more data feeds) is
weeks of work and ongoing cost. Spending that *before* we know what agents
actually value would be building in the dark. A pilot with 3–5 known agents buys
that knowledge cheaply and turns their domain instinct into product direction.

> **Core bet:** the fastest path to a great product is to put a rough-but-real
> version in front of a few trusted agents, watch what they do, and let their
> feedback — especially their "that's not a real lead" reactions — drive the next
> build. Every false positive we've killed so far (Eden Park, country clubs,
> apartment complexes, condo regimes) came from a human eyeballing output. The
> pilot scales that loop.

## 2. What the pilot is designed to learn

| # | Question | How we'll answer it |
|---|---|---|
| L1 | Do agents **trust** the leads? Where does trust break? | In-app feedback flags + check-in calls |
| L2 | Do the rankings match **domain intuition**? What false positives remain? | "Flag this lead" button → new diligence backlog |
| L3 | Which **workflow** matters most — map, neighborhood top-10, or Excel export? | Usage instrumentation |
| L4 | What **data/filters are missing** (owner contact, price est., lot dims, setbacks)? | Feedback + interviews |
| L5 | Does it **change what they'd do** — do they pursue any lead? | Direct ask + follow-up |
| L6 | Is it **worth paying for**, and roughly how much? | Exit interview |

These map to explicit go/no-go criteria in §7.

## 3. Pilot cohort & logistics

- **Who:** 3–5 agents Max already knows. Deliberately span **different
  submarkets** (e.g., an urban-core infill agent, a west-side value agent, a
  suburban agent) so we learn whether the model generalizes beyond one geography
  — the back-test showed development concentrates in urban infill corridors, so
  we want to hear from someone whose farm area is *not* those.
- **Onboarding:** a 30-minute 1:1 walkthrough each, ending with a concrete task:
  *"find 3 parcels in your farm area you'd actually consider pursuing, and flag
  anything that looks wrong."* A task beats "poke around" for generating signal.
- **Duration:** ~3–4 weeks of real use.
- **Cadence:** one 20-min check-in call per agent per week + always-on in-app
  feedback. Keep it light or they'll disengage.
- **Framing:** they are **design partners**, not customers. Set the expectation
  that it's rough, their criticism is the product, and bad leads are the most
  useful thing they can report.

## 4. Pre-pilot hardening — the minimum to not waste their time

Scoped tight. Everything here is "needed for a few known agents to get real value
and give reliable feedback" — nothing more.

### Must-build (in priority order)

1. **Lead pipeline (CRM funnel) ✅ BUILT (2026-07-29)** — *upgraded from the
   original per-parcel notes.*
   Agents hit **＋ Add to Leads** on any parcel they like, then work it through a
   diligence funnel on a dedicated **Pipeline** board: **Watchlist → Site Visit
   → Deal → Closed** (plus **Passed** to archive dead leads). Each stage has its
   own notes, Site Visit and Deal take **photos** (phone camera), and Deal/Closed
   have structured fields (offer amount/date/terms, close price/date). The moment
   a lead is saved, the metrics we already computed — score breakdown, zoning,
   market demand, signals, data checks — are **auto-attached** to it. This is a
   far richer pilot-metadata source than flat notes: which parcels agents pursue,
   how far each gets, offer economics, and why they pass — all in their own words.
   Identity = agent email from Cloudflare Access (prod) with a dev fallback;
   everything is private per agent. `leads` + `lead_entries` tables (migration
   019, existing notes migrated in as Watchlist entries), photos on the API's
   filesystem, `/leads` CRUD + `/leads/{id}/entries` + `/leads/{id}/photos`
   endpoints, Pipeline board + lead-detail drawer + ＋Add-to-Leads on the dossier.
   Verified end-to-end against the live stack and in the browser: add → advance →
   note → photo (upload + serve round-trip) → deal fields → delete, per-agent
   isolation, and the auto-populated basics.

2. **Get it off the laptop (lean hosting).**
   Recommended: a single small cloud VM (~$12–24/mo) running the **existing**
   `docker-compose` stack (PostGIS + API), with the built frontend served
   statically, fronted by **Cloudflare Tunnel + Access**. This gives HTTPS and
   **per-agent email login with zero auth code to write** — Access gates the site
   to an allow-list of agent emails. Reuses everything we have; no rewrite.
   *(Production upgrade later: managed Postgres/Supabase + a real auth layer.)*

3. **Neighborhood-first default ✅ BUILT (2026-07-26).**
   Each agent's home/farm region is saved to their account (`user_prefs`,
   `/prefs`); the app opens straight into it. A single neighborhood's leads sit
   far under the 5,000-parcel map cap, so this sidesteps the limitation entirely —
   MVT tiles stay deferred. Verified: selecting a region persists it, and reload
   opens into it (Oakley, 76 parcels shown — well under the cap).

4. **Usage instrumentation ✅ BUILT (2026-07-26).**
   `event_log` table + fire-and-forget `POST /events` (never blocks/fails the UI).
   Frontend logs `session`, `select_region`, `view_parcel`, `export`, and
   `open_my_leads`. Answers L3/L4 (which workflows matter) without asking.
   Verified: real browser activity lands in the log per agent.

5. **Reliable scheduled data refresh ✅ BUILT (2026-07-27).**
   Three things, because "schedule the existing pipeline" turned out to hide a
   real gap:
   - **Building permits are now in the refresh** (`orchestration/pipelines.py`
     `DERIVED`), on the **daily** tier. They were in *no* tier — yet since
     v2026.18 a recent permit is what suppresses a lot someone has already broken
     ground on. A stale permit feed silently re-creates exactly the false
     positive the pilot agent caught (3917 Paxton). Assemblage and demand also
     now rebuild on every tier rather than only weekly.
   - **Every step records an `ingest_runs` row** (success/failure, duration, row
     count), including the tier itself, so a half-failed refresh is visible.
   - **`orchestration/freshness.py` + `GET /health` + a header pill.** Each feed
     has a staleness budget (cadence x2 + slack); the UI shows "data current" or
     "N feeds behind" with a per-feed hover. This is the mitigation for the §9
     stale-data risk — an agent should never act on a passed auction date
     without knowing the feed is behind. Found live data 19 days stale on first
     run, which is the point.
   - Deploy artifacts: `ops/refresh.sh` (locked, logged, log-rotating) and
     `ops/crontab` (daily 05:15, weekly Mon 04:30, quarterly, hourly freshness
     probe). Install with `crontab ops/crontab` once the VM exists.

6. **One-page onboarding + disclaimer ✅ BUILT (2026-07-27).**
   `docs/onboarding.md` — what it is / what it isn't / public record / not
   investment or legal advice / verify before acting, plus a five-minute usage
   walkthrough, a plain-English table of the five score components, and an
   explicit "a bad lead is more useful to us than a good one" ask that cites the
   Oakley round as proof the loop works.

### Nice-to-have (only if quick)

- A "Data checks" explainer tooltip (we already compute the flags).
- A shareable per-parcel link (agents will want to send a lead to a colleague).

## 5. Explicitly deferred to post-pilot / full production

Guarding against scope creep — these do **not** block the pilot:

- **MVT vector tiles** (removes the 5k-parcel cap) — deferred; neighborhood
  default mitigates it. Build for production or if agents hit the cap.
- **Full auth / roles / SSO** — Cloudflare Access covers the pilot.
- **Autoscaling / managed Postgres / CI-CD** — a single VM is plenty for ≤5 users.
- **New data feeds** (VBML, Connected Communities, township zoning rules) — add
  only if agents demand them.
- **Phase 4b multi-owner assemblage, portfolio-sale demand exclusion** — backlog.
- **Mobile-optimized UI** — note whether agents want it; don't build yet.

## 6. Feedback → improvement loop

The engine of the pilot. Weekly:

1. **Collect:** in-app flags + session logs + call notes into one backlog.
2. **Triage into three buckets:**
   - **Model false positives** ("that's a school") → new diligence rules, exactly
     like Eden Park/condos. Each becomes a scoring fix + a regression test.
   - **Missing data / features** ("I need the owner's phone", "show lot width") →
     prioritized feature list.
   - **UX friction** ("couldn't find export", "map too slow") → quick fixes.
3. **Act:** ship scoring fixes and re-score; **re-run `backtest.py` after every
   scoring change** to confirm no regression in predictive lift.
4. **Close the loop:** tell the agent what changed from their feedback — it keeps
   design partners engaged and honest.

## 7. Go / no-go criteria for full production

Proceed to full productionization only if, by end of pilot:

- **Engagement:** most agents used it in ≥3 distinct sessions unprompted.
- **Utility:** at least one agent took a **real-world action** on a lead
  (looked up ownership, drove by, contacted an owner, ran comps).
- **Trust trajectory:** false-positive flags are *decreasing* as we ship fixes —
  i.e., the feedback loop demonstrably improves the product.
- **Willingness:** credible signal of willingness to pay or a business case.
- **Backlog is finite:** the feedback surfaces a *manageable* improvement list,
  not a fundamental "this isn't useful."

If these hold, the production build (infra + MVT tiles + auth + the top-voted
feature requests) is justified. If not, we've spent ~$50 and a few weeks instead
of a full build to learn it.

## 8. Timeline (indicative)

| Phase | Work | Est. |
|---|---|---|
| **0 · Pre-pilot hardening** | Feedback button, VM deploy + Cloudflare Access, neighborhood default, instrumentation, scheduled refresh, onboarding doc | ~1–1.5 weeks |
| **1 · Onboard** | 30-min walkthrough per agent, hand out the task | 2–3 days |
| **2 · Live pilot** | Real use + weekly check-ins + ship fixes each week | 3–4 weeks |
| **3 · Synthesize** | Consolidate feedback, score against go/no-go, write findings | ~3 days |
| **4 · Decision** | Go/no-go on full production + prioritized build plan | — |

## 9. Risks & mitigations

| Risk | Mitigation |
|---|---|
| A bad lead embarrasses the tool / erodes trust | Data-confidence flags already shipped; disclaimer; frame as beta; feedback button turns bad leads into value |
| Agents don't engage | Hand-picked known agents; concrete task; short weekly calls; show them their feedback shipped |
| Data/privacy concern (owner info) | All public record; disclaimer; no new PII collected; access gated to known emails |
| Scope creep during pilot | Strict deferral list (§5); weekly triage keeps changes small |
| Stale data (auctions/violations) | Scheduled weekly refresh; monitor the refresh job |
| Single-VM outage | Acceptable for a ≤5-user beta; managed infra is the production upgrade |

## 10. Rough cost

- Cloud VM: ~$12–24/mo · Cloudflare Tunnel + Access: **free** at this scale ·
  domain (optional): ~$12/yr. **Pilot infra ≈ $20/mo.** The expensive input is
  Max's time on onboarding and the weekly loop — which is the point.

## 11. First concrete steps

1. ~~Per-realtor notes + My Leads~~ ✅ **built & verified 2026-07-26.**
2. ~~Neighborhood-default + instrumentation~~ ✅ **built & verified 2026-07-26.**
3. ~~Scheduled refresh + freshness monitoring; one-page onboarding~~
   ✅ **built & verified 2026-07-27.**
4. Stand up the **VM + Cloudflare Access** deploy of the existing stack (notes +
   prefs + events all read the Access email header, so identity "just works"
   once Access is in front), then `crontab ops/crontab`.
   **Blocked on three choices from Max:** VM host, access method, domain.

   *Identity hardening ✅ done 2026-08-14 (prerequisite, no longer blocking).*
   `current_user()` used to fall through to a shared dev identity, so an app
   reachable without Access would have signed **every visitor in as the same
   user** — each seeing and editing everyone's leads, notes and photos — and
   the `X-User-Email` header let any caller name whoever they liked. Now the
   Cloudflare Access header is the only identity trusted by default; the dev
   path is gated behind `DEV_AUTH`, which **defaults to false so a deploy that
   sets nothing fails closed (401)** rather than silently opening up. Local dev
   opts in via `.env`. 6 tests in `api/tests/test_identity.py`.
   Remaining caveat for a *public* origin: trusting the email header assumes
   nothing can reach the API except through Access, which holds behind a
   Cloudflare Tunnel (no public inbound port). If the API is ever exposed
   directly, verify the signed `Cf-Access-Jwt-Assertion` JWT instead.
5. Line up the **3–5 agents** and book onboarding sessions.

> Everything that does not require a decision from Max is now done. The pilot is
> gated on step 4 and step 5 only.
