# Master Plan — Purpose-Built Land Finder for the Oyler Hines Team

**Status:** proposed · **Owner:** Max · **Created:** 2026-08-03

The pivot: this stops being a general Hamilton County tool and becomes a system
that is *great at exactly what this team does* — sourcing land in their target
markets, on their terms. This plan is grounded in (a) the team's own deal history
(554 LOI offers, `Oyler Hines LOI - all-people-2026-06-30.csv`) and (b) a check of
what our data covers today.

---

## 0. Decisions locked (2026-08-03, with Max)

- **Build order:** **Infill markets first** — Phase 1 municipal labeling → Mode A
  tuning — then Warren County / Mode B.
- **Mode A = all four infill plays:** teardown/rebuild, vacant/underused lots,
  lot splits/subdivisions, and assemblage.
- **Mode B = a developable-land inventory ranked toward development-ready**
  (utility-served) land; motivated owners are a *boost*, never a gate; nothing is
  excluded on owner motivation or price. Size is not a floor (5 acres is fine).
- **Fringe geography:** **Warren County only** for now (Kings Mills, Loveland).
- **Utilities:** source **public** data (MSD sanitary-sewer service areas,
  water-district boundaries, Warren County GIS); sanitary sewer is the primary
  "development-ready" signal.
- **Price is NOT a gate** in either mode — the team often brokers, so price is
  shown as information (assessed value, last sale) but never filters or penalizes.
- **Lot size dropped as a scoring criterion** (requirements vary by municipality);
  shown as info, and only relevant inside the lot-split thesis via municipal
  minimums.
- **Ownership signals** (30-yr same-owner, bank-owned, CMHA, Port): available as
  filters in both modes; a ranking boost in Mode B.
- **Owner contact:** surface the public-record **owner name + mailing address**
  on every lead for outreach.
- **Deal history:** used for **calibration + a "their-deals" back-test only** — no
  owner-contact import.

---

## 1. What the team actually does (from their deal history)

Their CRM export is the strongest signal we have. It is a **guide, not gospel** —
but it's remarkably clear:

**Engine A — east-side infill (the bread and butter).** 554 LOI offers,
concentrated in a handful of affluent municipalities:

| Market | LOI offers (tag count) |
|---|---|
| **Madeira** | **380** |
| Montgomery | 131 |
| Indian Hill | 66 |
| Blue Ash | 46 |
| N. Mingo / others | ~40 |

- **Offer band: $150k–$255k** (median $200k, IQR $160–229k), a few up to $1.5M.
  That's the price envelope for an infill/teardown lot in these markets.
- Agent on 618 of them: **Bill Hines**. This is a mature, repeatable playbook.

**Engine B — large-tract fringe (the expansion).** The team now wants **40+ acre
properties in Cincinnati's outer ring — Kings Mills, Loveland — which are in
Warren County.** This is the *opposite* of infill: big raw tracts, not teardown
lots, and a county we don't yet ingest.

**The named target set going forward:**
- **Infill:** Madeira, Montgomery, Indian Hill, Blue Ash, Symmes, Hyde Park, Oakley.
- **Large-tract:** Warren County fringe (Kings Mills, Loveland), 40+ acres.

> **Lot-size caveat:** the CSV's `Lot Size` field reads median ~75 with a 0.18
> minimum — the unit is inconsistent (acres vs frontage-feet vs mixed). We'll
> normalize it against county acreage during calibration rather than trust it raw.

---

## 2. The gap between today and "great for them"

A coverage check against those exact markets exposed the work:

| Target market | In our data today? |
|---|---|
| Hyde Park | ✅ 6,879 parcels |
| Oakley | ✅ 5,801 parcels |
| Montgomery | ✅ 4,723 parcels |
| **Madeira** | ❌ **0 labeled** (parcels exist but unlabeled) |
| **Indian Hill** | ❌ **0 labeled** |
| **Blue Ash** | ❌ **0 labeled** |
| **Symmes** | ⚠️ only 2 labeled |
| **Warren County (Kings Mills, Loveland)** | ❌ **not ingested at all** |

Root causes:
1. **Region labeling is incomplete.** Neighborhoods came from Cincinnati's SNA
   layer plus a partial jurisdiction fallback; **106,935 parcels have no region
   label**, including the team's #1 market (Madeira) and most of the east-side
   municipalities. *They literally cannot filter to their best markets today.*
2. **Only Hamilton County exists.** The fringe large-tract play needs Warren
   County parcels + CAMA — a brand-new source.
3. **Scoring is infill-only.** It actively *penalizes* large acreage and low
   residential context — correct for Engine A, exactly wrong for Engine B.

---

## 3. The product: two modes, one system

The system becomes a **market-master with two lenses**, switchable in the UI:

### Mode A — Infill Hunter (their proven engine)
Scoped to the target municipalities. Keeps the infill scoring we've hardened, but
**tuned to their profile**: the $150–255k value envelope, teardown/underused lots,
and the owner-motivation signals below. Default view opens on Madeira.

### Mode B — Large-Tract Finder (the expansion)
A distinct scoring lens for **40+ acre developable tracts** in the fringe. Here
big acreage is the *goal*, not a penalty; residential-context and infill dampers
are off; the signals that matter are size, road frontage, access, subdividability,
and motivated ownership. Covers Warren County fringe + Hamilton's outer townships.

The two modes share the data platform, pipeline, filters, pipeline-CRM, and audit
harness — only the scoring lens and default geography differ.

---

## 4. New filters the team asked for (all exact-data)

| Filter | How | Feasible now? |
|---|---|---|
| **Owned by same person 30+ years** | `last_sale_date ≤ today − 30yr` (exact; excludes the corrupted dates we already cleaned) | ✅ now |
| **Owned by a bank** (REO/foreclosed) | owner-name pattern: BANK, N.A., MORTGAGE, FEDERAL NATIONAL, FANNIE/FREDDIE, "… REO", trustee-of-lender | ✅ now (owner classifier) |
| **Owned by CMHA** (Cincinnati Metro Housing Authority) | owner-name pattern: "METROPOLITAN HOUSING", "CMHA" | ✅ now |
| **Owned by the Port** (Port of Greater Cincinnati Dev. Authority) | already detected for the land-bank feed — expose as a filter | ✅ now |
| **40+ acre tracts** | `area_acres ≥ 40`, Mode B | ✅ now (needs Warren County for the fringe) |

These extend the exact-data filter set we just shipped (owner, trust, tax lien,
distress, value, lot size). The three ownership classes (bank / CMHA / Port)
become a new **owner-type facet** — all three are motivated, institutional, and
acquirable, which is exactly what the team hunts.

---

## 5. How we use the team's deal history (guide, not source of truth)

The 554 LOIs are the calibration asset — used three ways, never as hard rules:

1. **Region priors.** Their offer distribution confirms the target markets and
   weights them (Madeira ≫ Montgomery > Indian Hill > Blue Ash). We tilt Mode A's
   default geography and demand priors toward where they actually transact.
2. **A real back-test cohort.** Geocode the LOI/closed properties to parcel_ids
   and ask: *does our score rank the lots they actually pursued above random lots
   in the same market?* That's a far better validation than permits alone — it's
   their real revealed preference. We tune to lift this **without overfitting**
   (hold out a slice; a rule must generalize across markets, not memorize deals).
3. **Owner-outreach enrichment (optional).** The export carries skip-traced owner
   names/phones for past targets. Treat as private reference the team already
   owns; we don't redistribute it, and any new contact data is theirs.

> The guardrail from the audit work stays: every scoring change is validated
> (their-deals lift + permit back-test must hold) and regression-tested. The deal
> data dials the model in; it never gets hard-coded.

---

## 6. Roadmap (phased, prioritized)

Sequenced so the team gets usable value from their **proven** engine first, then
the expansion.

### Phase 1 — Make their core markets real *(highest priority)*
The team can't use the tool for their best markets until this lands.
- **Ingest Hamilton County municipal/jurisdiction boundaries** (CAGIS political
  jurisdictions layer) and label every parcel with its municipality — Madeira,
  Indian Hill, Blue Ash, Symmes, Montgomery, etc. Fixes the 106,935 unlabeled
  parcels.
- Verify the target municipalities appear with real parcel counts and are
  filterable; set **Madeira as the default region** for the team.

### Phase 2 — Tune Mode A to their playbook
- Add the **ownership filters** (30+ yr tenure, bank, CMHA, Port).
- **Calibrate infill scoring** to their $150–255k envelope and lot profile using
  the LOI cohort (region priors + their-deals back-test). Anti-overfit gates.
- Re-point the pipeline/Top-list defaults to the target markets.

### Phase 3 — Stand up Mode B (large-tract) + Warren County
- **Ingest Warren County** parcels + CAMA (Warren County GIS/Auditor open data —
  feasibility spike first: confirm the endpoint, geometry, ownership, acreage).
- Build the **Large-Tract scoring lens** (size + frontage/access + subdividability
  + motivated ownership; infill dampers off).
- UI **mode switch** (Infill ⇄ Large-Tract) with per-mode default geography.

### Phase 4 — Deal-history back-test + continuous tuning
- Geocode the LOIs to parcels; wire the **their-deals lift** metric alongside the
  permit back-test and the audit precision metric.
- Keep the **Audit tab** running on the new markets so the team's own "that's not
  a lead" feedback keeps sharpening it (the loop we already proved).

### Phase 5 — Deploy for the team
- The existing pilot-plan deploy (single VM + Cloudflare Access, per-agent login)
  — now pointed at *their* markets, with their pipeline and deal context loaded.

---

## 7. Feasibility notes & open decisions

**Feasible now, no new data:** all three ownership filters, 30+ yr tenure, the
municipal labeling (CAGIS layer we can pull like the others), Mode A tuning.

**Needs a new source (a real spike):** Warren County. Its GIS/Auditor publishes
parcel data, but access, schema, and geometry need confirming before we commit —
this is the one genuine unknown. Everything else reuses our existing pipeline.

**Resolved** (see §0). Two refinements still to dial in during Phase 2:
1. **Teardown definition** — Mode A now hunts teardowns, i.e. *improved* parcels
   (an older/under-built house on a valuable lot) — the opposite of the vacant
   signal. We'll derive the profile from the team's closed deals + a
   land-dominant-improvement heuristic in a premium market, and validate it via
   the deal back-test. A team rule-of-thumb (e.g. "house value < X% of land",
   build year) would sharpen it.
2. **Municipal minimums for lot-splits** — each target municipality has its own
   minimum lot size / subdivision rules (why "lot size varies by area"). Detecting
   a splittable lot needs those minimums; we'll source municipal zoning, or use
   the team's numbers if they have them.

---

## 8. What "great for them" looks like

A rep opens the tool, it lands on **Madeira**, shows the ranked infill lots that
match the team's real buy-box ($150–255k, teardown/underused), filtered to
**30-year owners, bank-owned, CMHA, and Port** parcels they can actually acquire —
and one mode-switch away, the **40+ acre Warren County tracts** for the big plays.
Every lead traceable, every score tuned to deals they've actually done, and their
own feedback continuously sharpening it. Not a general tool that happens to cover
their area — *their* tool.
