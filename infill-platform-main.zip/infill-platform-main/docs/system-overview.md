# System Overview — Infill & Development Land Discovery Platform

**Last updated:** 2026-07-30 · scoring config **v2026.18** · **419,814** parcels
countywide (Hamilton County, OH)

This is the single reference for how the backend works: what data comes in, how
it's turned into a score, and how it's served. Read top to bottom for the whole
picture, or jump to a section.

1. [What the platform does](#1-what-the-platform-does)
2. [Architecture at a glance](#2-architecture-at-a-glance)
3. [Data sources](#3-data-sources)
4. [The data model](#4-the-data-model)
5. [Ingestion pipelines](#5-ingestion-pipelines)
6. [Derived / enrichment layers](#6-derived--enrichment-layers)
7. [The scoring system](#7-the-scoring-system)
8. [False-positive elimination](#8-false-positive-elimination)
9. [The API](#9-the-api)
10. [The web app](#10-the-web-app)
11. [Orchestration & operations](#11-orchestration--operations)
12. [Validation & quality](#12-validation--quality)
13. [Code map](#13-code-map)

---

## 1. What the platform does

It ingests ~10 public records feeds for every parcel in Hamilton County,
resolves them all to the county's universal key (the Auditor **parcel_id**),
scores each parcel 0–100 for its potential as a **residential development
opportunity**, and serves the results as a map, a ranked list, and a working CRM.

The throughline: **surface land worth developing — vacant lots, under-built
sites, and adjacent lots that could be combined — before it's listed or
obvious.** Everything downstream serves that one judgment.

Three user-facing surfaces (all one React app):
- **Discover** — the county map + ranked Top-10 + parcel lookup + dossier.
- **Pipeline** — a CRM funnel to work saved leads (Watchlist → Site Visit → Deal → Closed).
- **Audit** — an internal review harness to measure and improve lead quality.

---

## 2. Architecture at a glance

```mermaid
flowchart LR
  subgraph SRC[Public data sources]
    A[CAGIS parcels + Auditor CAMA]
    B[CAGIS zoning / neighborhoods]
    C[FEMA flood / hillside / historic]
    D[Socrata code violations]
    E[Socrata building permits]
    F[Sheriff-sale auctions]
  end
  SRC --> ING[Ingestion\nextract -> normalize -> resolve to parcel_id -> load]
  ING --> DB[(PostGIS\nparcel_master + signals + overlays)]
  DB --> DER[Derived layers\nassemblage / satellites / condo / demand / audit]
  DER --> SCORE[Scoring engine\n5 components + constraints + knockouts]
  SCORE --> DB
  DB --> API[FastAPI]
  API --> WEB[React + MapLibre\nDiscover / Pipeline / Audit]
  ORC[Orchestration\ndaily / weekly / quarterly] --> ING
  ORC --> SCORE
```

**Stack:** Python 3.12 · PostgreSQL 16 + PostGIS 3 (Docker) · SQLAlchemy 2 +
psycopg3 · FastAPI · React 18 + Vite + TypeScript + MapLibre GL JS. Only the
database is containerized in dev; the API and web run natively.

**The universal join key** is the Hamilton County Auditor parcel number
(`parcel_id`). Every source is resolved to it — by direct ID match where a
source carries one, or by spatial point-in-polygon against parcel geometry where
it only has a lat/lon. This is what lets a code violation, a sheriff sale, and a
zoning district all attach to the same parcel.

---

## 3. Data sources

| Source | Provides | Endpoint | Cadence | Lands in | Rows now |
|---|---|---|---|---|---|
| **CAGIS parcels + Auditor CAMA** | Geometry + ownership, land/improvement value, sale history, tax-delinquency & foreclosure flags, DTE class | `services.arcgis.com/…/Open_Data/FeatureServer/51` | Quarterly | `parcel_master` (+ derived tax signals) | 419,814 |
| **CAGIS zoning** | Zoning district per parcel | `cagisonline.hamilton-co.org/…/MapServer` (zoning layer) | Quarterly | `constraint_zones` (layer `zoning`) → `zoning_code` | 4,051 zones |
| **Cincinnati SNA neighborhoods** | Neighborhood boundaries | CAGIS `CINC_PLANNING …/MapServer/0` | Quarterly | `constraint_zones` (`neighborhood`) → `neighborhood` | 50 |
| **FEMA NFHL flood** | Special Flood Hazard Areas + floodway | `hazards.fema.gov/…/NFHL/MapServer/28` | Quarterly | `constraint_zones` (`fema_flood`) → `flood_flag`, `floodway_flag` | 1,713 |
| **Cincinnati hillside** | Steep-slope overlay | CAGIS `Open_Data/FeatureServer/6` | Quarterly | `constraint_zones` (`hillside`) → `slope_flag` | 228 |
| **Cincinnati historic** | Historic districts | CAGIS `Open_Data/FeatureServer/7` | Quarterly | `constraint_zones` (`historic`) → `historic_flag` | 83 |
| **Socrata code violations** | Building/code enforcement cases | `data.cincinnati-oh.gov` (`cncm-znd6`) | Daily | `parcel_signals` (`code_violation`) | 33,112 |
| **Socrata building permits** | New-construction permits | `data.cincinnati-oh.gov/resource/uhjb-xac9` | Daily | `development_permits` | 1,555 |
| **Sheriff-sale auctions** | Foreclosure auction calendar + opening bids | `hamilton.sheriffsaleauction.ohio.gov` | Weekly | `parcel_signals` (`sheriff_sale`) | 39 |
| **Land bank (derived)** | Publicly-held-for-sale inventory | derived from Auditor ownership patterns | Weekly | `parcel_signals` (`landbank_inventory`) | 2,295 |
| **Auditor tax delinquency (derived)** | Delinquency severity ($) | derived from CAGIS parcel attrs | Quarterly | `parcel_signals` (`tax_delinquent`) | 28,810 |

**Notes on sourcing reality:**
- No API tokens are used — all endpoints are public. The sheriff-sale site 403s
  non-browser user agents, so that scraper sends a browser UA and uses
  session-scoped AJAX.
- `foreclosure_filing` is a supported distress type but the Auditor's
  `FORECL_FLAG` is absent countywide, so it currently produces no rows; sheriff
  sales are the live foreclosure signal.
- The `cso` (combined-sewer-overflow) constraint penalty exists in config but no
  CSO overlay is currently ingested, so `cso_flag` is dormant until that feed is
  added.
- Only the City of Cincinnati publishes code violations, permits, zoning, and
  neighborhoods; township/unincorporated parcels therefore have thinner data
  (a known scoring gap — see the lead-audit plan).

---

## 4. The data model

Core tables (PostgreSQL/PostGIS; migrations `db/ddl/001…020`):

| Table | Role |
|---|---|
| `parcel_master` | One row per parcel: geometry, ownership, valuation, DTE class, `zoning_code`, `neighborhood`, constraint flags, and derived booleans (`is_satellite`, `is_subdivision_lot`, `is_condo_unit`, `res_context_pct`, `assemblage_id`). The spine everything joins to. |
| `parcel_signals` | Time-stamped events/facts per parcel (code violations, tax delinquency, sheriff sales, land-bank inventory). Deduped on `(source, raw_ref)`. |
| `parcel_scores` | The output: `opportunity_score`, the 5 component scores, `use_classification`, active `constraints` (JSONB), and `scoring_config_version`. |
| `constraint_zones` | All overlay polygons (zoning, flood, hillside, historic, neighborhood), tagged by `layer`. |
| `development_permits` | New-building permits (the development ground-truth for demand + the "already being built" guard). |
| `assemblages` | Same-owner adjacent clusters (combined footprint, owner, member count). |
| `neighborhood_demand` | Per-neighborhood development-demand metrics. |
| `parcel_audit_flag` | Advisory data-plausibility flags (never change the score). |
| `leads` / `lead_entries` | The agent CRM: saved leads + per-stage notes/photos. |
| `lead_labels` | Ground-truth audit labels (real/fake + reason) for measuring precision. |
| `user_prefs` / `event_log` | Per-agent home region + usage instrumentation. |
| `ingest_runs` | Observability: one row per pipeline step (status, rows, timing) — backs the freshness monitor. |
| `alerts` | Score-change alerts, delivered (re-validated) to Slack/log. |

---

## 5. Ingestion pipelines

Every source runs the same shape (`ingestion/run.py`):

```
discover resources → for each page:
   extract → archive raw → normalize → resolve to parcel_id → upsert
```

- **Streaming, page by page** — a full-county pull never holds more than one page
  in memory; upserts are batched (`executemany`).
- **Parcel resolution** (`ingestion/resolve.py`): tier-1 direct ID match when a
  source has a parcel number (validated against `parcel_master`), otherwise
  spatial point-in-polygon against parcel geometry. CAGIS parcel geometries were
  repaired with `ST_MakeValid` (64 had self-intersections).
- **Idempotency**: master rows upsert on `parcel_id`; event signals dedupe on
  `(source, raw_ref)`; standing flags use partial unique indexes.
- **Isolation**: each source runs independently — one broken feed never blocks
  the others or the re-score.
- **Observability**: every run (and every builder step) writes an `ingest_runs`
  row, which the freshness monitor reads.

Overlays (`ingestion/overlays.py`) load the flood/hillside/historic/zoning/
neighborhood polygons into `constraint_zones` and stamp the per-parcel flags via
centroid containment, in per-statement transactions (so one bad geometry can't
roll back the whole apply).

---

## 6. Derived / enrichment layers

These run before scoring and produce the signals the scorer relies on. They turn
raw records into the structural facts a developer cares about.

| Layer | Module | What it computes |
|---|---|---|
| **Assemblage** | `scoring/assemblage.py` | `ST_ClusterDBSCAN` over same-owner adjacent parcels → `assemblages` + `assemblage_id`. Lets adjacent lots score as one buildable site. |
| **Complex satellites** | `ingestion/derive.py` | Marks `$0`-improvement deeds whose same-owner sibling (same address, or adjacent with a ≥$500k building) holds the real structure — apartment/commercial bookkeeping parcels, not vacant land. |
| **Subdivision inventory** | `ingestion/derive.py` | ≥3 same-owner lots sharing one plat date + land value = a builder's active stock. |
| **Condo units** | `ingestion/derive.py` | Deeds with identical geometry = units on one shared footprint, not N independent lots. |
| **Residential context** | `ingestion/derive.py` | `res_context_pct` = share of neighbors within ~150 ft that are improved single-family — is this actually a housing block? |
| **Neighborhood demand** | `scoring/demand.py` | Development-demand metrics per neighborhood from permit density + trajectory (resale metrics kept as context). |
| **Audit flags** | `scoring/audit.py` | Advisory plausibility checks (bulk sale, no market sale, portfolio owner, incomplete valuation) — surfaced, never scored. |

---

## 7. The scoring system

The opportunity score is a weighted blend of **five components**, each 0–100,
then modified by ownership acquirability, soft constraints, and hard knockouts.
All weights and thresholds live in the versioned `scoring/config/scoring.yaml`
(current **v2026.18**); every score row records the version it ran under.

### The five components and their weights

| Component | Weight | Question it answers | How it's computed |
|---|---|---|---|
| **Underutilization** | **0.30** | Is land value sitting idle? | For improved parcels: how far the improvement-to-land (I/L) ratio sits below the use-class threshold (commercial 1.0, multifamily 1.0, single-family 0.5). For vacant lots: full credit scaled by **lot quality** (value + size ramps) × **residential context**. |
| **Capacity gap** | **0.25** | Does zoning allow much more than what's there? | Allowed units (zoning density by district, `zoning_rules.yaml`) − existing units, saturating: `100·(1−e^(−gap/12))`. Unknown districts are excluded per-parcel, not zeroed. |
| **Distress** | **0.25** | Is the owner motivated to sell? | Weighted, recency-decayed, severity-scaled sum of distress signals, squashed to 0–100: `100·(1−e^(−Σ))`. |
| **Assemblage** | **0.10** | Could adjacent lots combine into a site? | Same-owner cluster: `(0.4 + 0.6·ramp(combined_sqft, 7500→30000)) × mean member underutilization`. Members share the score. |
| **Demand** | **0.10** | Is development actually happening nearby? | Neighborhood development demand = `0.7·build_density + 0.3·trajectory` (new-builds/1k parcels over 5 yrs, ± recent trajectory). Null outside city permit coverage. |

Components are **renormalized per parcel** over whatever is actually computable —
so a parcel with no zoning data ranks on the components it does have, instead of
being dragged down by a missing one.

### Distress signal weights (with recency decay)

Distress is where the "motivated seller" signal lives. Each signal type has a
weight, a half-life (months) for exponential recency decay, and an optional cap:

| Signal | Weight | Half-life | Cap |
|---|---|---|---|
| Foreclosure filing | 1.0 | 12 mo | — |
| Sheriff sale | 1.0 | 12 mo | — |
| Tax delinquent | 0.8 | 24 mo | — |
| Condemnation | 0.9 | 36 mo | 2 events |
| Code violation | 0.4 | 18 mo | 3 events |
| Land-bank inventory | 0.7 | none (standing fact) | — |

**Severity scaling**: a tax delinquency is scaled 0.4×–1.6× by its dollar amount
relative to land value — a lot delinquent for most of its value is a far more
motivated seller than a $50 slip.

### Modifiers applied to the composite

- **Ownership multiplier** (× the blend, capped 1.10): absentee 1.05, LLC 1.05,
  trust 1.03 (more acquirable); **public 0.85** (routes through the land bank).
- **Soft constraints** (× the final score, surfaced as flags): flood 0.7, steep
  slope 0.8, historic 0.85, cso 0.9, operating amenity 0.3, subdivision
  inventory 0.35, **permit issued 0.15** (someone's already building).
- **Hard knockouts** (drop the parcel below the surfacing threshold):
  `regulatory_floodway` (can't build) and `not_acquirable` (public/institutional/
  exempt owners and classes, unless it carries a land-bank signal).

### `use_classification`

Each scored parcel gets a human-readable label used in the UI: `single-family
SF`, `missing-middle`, `mixed-use`, `assemblage`, `non-residential`, or
`hold/monitor` — derived from zoning family + the dominant signal.

---

## 8. False-positive elimination

The score's credibility comes from *what it refuses to rank*. Fifteen versions
of diligence (each triggered by a real bad lead) added rules that demote parcels
that aren't genuine residential opportunities. They live as predicates in
`scoring/classify.py` + config, applied as knockouts or soft penalties (always
with a **waiver** for the case where distress makes it a legit play):

| Class | Trigger example | Treatment |
|---|---|---|
| Public / exempt | Eden Park | knockout |
| Institutional | hospitals, schools, churches, cemeteries | knockout |
| Regulatory floodway | riverfront no-build | knockout |
| Operating amenity | Hyde Park golf course | ×0.3 (waived if distressed) |
| Apartment bookkeeping | 4045 Reading Rd (lawn scored as vacant) | underutilization → 0 |
| Commercial land | Kroger parking lot + gas pad (Paxton) | underutilization → 0 |
| Builder subdivision | Brunsman Wy plat stock | ×0.35 (waived if distressed) |
| Condo regime | Wind St shared footprint | underutilization + capacity → 0 |
| Commercial-strip context | Calvert St "behind Petsmart" | residential-context damping |
| Already being developed | 3917 Paxton (permit pulled) | ×0.15 |

This is now being made **systematic and measured** — see
[lead-audit-plan.md](lead-audit-plan.md): a `lead_labels` ground-truth set, a
precision@N metric, and the in-app **Audit** review harness.

---

## 9. The API

FastAPI, JSON REST, auto-documented at `/docs`. Endpoint groups:

- **Discovery**: `/stats`, `/health`, `/neighborhoods`, `/parcels` (ranked
  search), `/parcels/search` (address/id lookup), `/parcels/{id}` (full dossier),
  `/parcels/{id}/geojson`, `/geojson`, `/geojson_assemblages`, `/export`
  (Excel/CSV call sheet), `/alerts`.
- **Pipeline (CRM)**: `/leads` CRUD, `/leads/{id}/entries` (notes),
  `/leads/{id}/photos` (site-visit photos), `/me`, `/prefs`, `/events`.
- **Audit**: `/audit/precision`, `/audit/queue`, `/audit/search`, `/audit/label`.

**Identity** is the agent's email, read from the `Cf-Access-Authenticated-User-
Email` header (Cloudflare Access in production) with an `X-User-Email` / dev
fallback locally — so per-agent notes, leads, prefs, and audit labels "just work"
once Access fronts the app, with zero auth code written.

---

## 10. The web app

React + Vite + TypeScript + MapLibre GL JS. Three tabs:

- **Discover** — county map (score-colored parcel fills, dashed assemblage
  outlines), region selector, min-score slider, the ranked **Top-10** panel, and
  the **parcel lookup** box (search any address/id → fly to it, outline it, open
  its dossier). The dossier shows the full score breakdown, valuation, zoning,
  market-demand metrics (shown verbatim), signals timeline, and data-check flags.
- **Pipeline** — a kanban board of saved leads moving through **Watchlist → Site
  Visit → Deal → Closed** (+ Passed), each lead a working file with per-stage
  notes, photos, and structured deal fields; the parcel's basics auto-attach.
- **Audit** — the internal review harness: work the un-reviewed leads (paged,
  region/band-filterable, searchable) with aerial + Street View deep-links and
  the dossier, recording real/fake verdicts that drive the precision metric.

---

## 11. Orchestration & operations

Refresh runs as plain Python (`orchestration/pipelines.py`) — no orchestrator
required; the same functions run under cron, Prefect, or by hand.

| Tier | Cadence | Pulls | Then |
|---|---|---|---|
| **daily** | 05:15 | code violations, building permits | rebuild assemblage + demand → re-score |
| **weekly** | Mon 04:30 | sheriff sales, land bank | rebuild derived layers → re-score |
| **quarterly** | 1st of Jan/Apr/Jul/Oct | full CAGIS parcels/CAMA | rebuild everything → re-score |

Every tier ends with a scoring pass (which queues alert diffs) and an audit-flag
pass. Deploy artifacts: `ops/refresh.sh` (single-instance via flock, logged) and
`ops/crontab`.

- **Freshness monitor** (`orchestration/freshness.py`, `GET /health`, header
  pill): each feed has a staleness budget; the UI shows "data current" or "N
  feeds behind." Silent staleness is the fastest way to lose an agent's trust.
- **Alerts** (`scoring/alerts.py`): parcels newly crossing the score threshold
  are queued and delivered (Slack or log). Alerts are **re-validated against the
  live score at delivery** — a lead demoted by a later rule is suppressed rather
  than announced with a stale number.

---

## 12. Validation & quality

- **Back-test** (`scoring/backtest.py`): ground truth = new-building permits.
  Because a developed parcel's score is contaminated (it's no longer
  underutilized), it tests contamination-robust angles — neighborhood demand vs
  future construction (temporal holdout, Spearman **+0.96**) and a discovery-lift
  cohort (**2.69×** the vacant baseline). Composite AUC ≈ **0.887**.
- **Weight tuning** (`scoring/tune.py`): nested cross-validation with an AUC
  objective concluded the **spec default weights generalize best** — a leakage-
  free re-run showed reweighting gained only noise, so defaults were kept.
- **Lead audit** (`scoring/leadaudit/`): the measured program to drive top-of-
  board precision — a ground-truth label set, precision@N, and the Audit UI.
- **Tests**: 93 automated tests (scoring formulas, classification predicates,
  ingestion, alerts, scheduling invariants, API contracts). Every fixed false
  positive becomes a regression test; the back-test is re-run after every scoring
  change.

---

## 13. Code map

```
infill-platform/
  ingestion/
    run.py            # the extract→resolve→load runner
    extractors/       # cagis.py, socrata.py, sheriff.py
    overlays.py       # flood/hillside/historic/zoning/neighborhood polygons
    permits.py        # new-building permits
    landbank.py       # land-bank inventory (derived)
    derive.py         # satellites, subdivision lots, condo units, res context
    resolve.py        # parcel_id resolution (ID + spatial)
    load.py           # DB upserts, raw archive
  scoring/
    score.py          # pure scoring formulas (the 5 components, ramps, blend)
    classify.py       # use classification + false-positive predicates
    capacity.py       # zoning capacity + use_family
    run.py            # the scoring pass (reads DB, writes parcel_scores)
    assemblage.py     # same-owner clustering
    demand.py         # neighborhood development demand
    audit.py          # data-plausibility flags
    alerts.py         # score-change alerting (re-validated delivery)
    backtest.py       # permit-based validation
    tune.py           # nested-CV weight tuning
    config/           # scoring.yaml (weights) + zoning_rules.yaml (density)
    leadaudit/        # labels, seed_from_history, precision (Phase 0)
  orchestration/
    pipelines.py      # daily/weekly/quarterly tier bundles
    freshness.py      # per-feed staleness monitor
  api/main.py         # FastAPI — discovery, pipeline, audit endpoints
  web/src/            # React app: App, MapView, Dossier, ParcelBasics,
                      #   TopList, Pipeline, LeadDetail, Audit
  db/ddl/             # migrations 001–020
  ops/                # refresh.sh + crontab (scheduled refresh)
  docs/               # this file, architecture, pilot-plan, lead-audit-plan, onboarding
```

**Related docs:** [architecture.md](architecture.md) ·
[lead-audit-plan.md](lead-audit-plan.md) · [pilot-plan.md](pilot-plan.md) ·
[onboarding.md](onboarding.md)
