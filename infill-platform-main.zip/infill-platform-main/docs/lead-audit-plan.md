# Lead-Audit & Scoring-Reality Plan

**Status:** proposed · **Owner:** Max · **Created:** 2026-07-29

Goal: move from **reactive, one-at-a-time false-positive fixes** (Eden Park, golf
courses, condos, the Kroger lot, the agent's four Oakley misses) to a
**systematic, measured audit** that grounds every scoring assumption in a real
residential-development decision — so the top of the board is trustworthy in
*every* neighborhood, not just the ones we happened to eyeball.

---

## 1. Why the current approach isn't enough

Every false-positive class we've killed came from a human staring at the top ~10
of **one** neighborhood (almost always Oakley) and saying "that's not a real
lead." That loop works — it found nine distinct fake-lead classes — but it has
three structural holes:

1. **Coverage is accidental.** We've deeply inspected Oakley's top 10. We have
   **never** systematically looked at Colerain, Anderson, Green Twp, Avondale,
   Walnut Hills, or the 40+ other regions that carry leads. A fake class that
   doesn't happen to surface in Oakley is invisible to us.
2. **It's unmeasured.** We can't answer "what % of our top 50 are real?" today.
   Without that number we can't tell whether a fix helped, or whether the board
   is getting more or less trustworthy over time.
3. **It's whack-a-mole.** Each fix is bespoke. There's no durable record of
   *which parcels* are confirmed fake and *why*, so we can't regression-test the
   whole set or train against it.

### What the data says the real problem is (as of 2026-07-29)

The lead inventory is small at the top and the remaining fakes are in
**undetected** categories:

| Score band | Parcels | Note |
|---|---|---|
| ≥ 80 | 6 | the marquee leads |
| 70–80 | 44 | |
| 60–70 | 456 | |
| 50–60 | 1,470 | |
| **≥ 50 total** | **1,976** | the working set to audit |

- **1,907 of those 1,976 carry _zero_ active constraints.** Our existing rules
  already demoted everything they catch below 50. Whatever is fake at the top now
  is fake in a way we **don't yet model**.
- **~40% of the top leads are outside Cincinnati** — 638 of the ≥50 leads (and
  20 of the ~50 leads ≥70) are in townships/unincorporated areas with **no zoning
  rules and no permit-based demand signal**. On an *infill* platform this is the
  single biggest grounding gap.
- **596 leads have no zoning code at all, median lot 1.4 acres.** That's rural
  acreage scoring like urban infill. Even zoned leads run ~1-acre median — far
  above a real Cincinnati infill lot (3–7k sqft), which points at large-tract and
  assemblage over-crediting.
- **Assemblage is the dominant class** (1,080 of the ≥50 leads) — worth a hard
  look at whether it inflates.
- 254,687 parcels are already knocked out — the knockout machinery works; this
  plan is about the *survivors*.

**Conclusion:** the fix is not another Oakley round. It's (a) a measurement
system, (b) exhaustive stratified review, (c) closing the specific structural
gaps the data points to, and (d) a flywheel that keeps it honest.

---

## 2. Definition of done — what "polished" means

We commit to a **precision@N** target and measure it per neighborhood:

> **≥ 90% of the top 25 leads in any neighborhood are judged a plausible real
> residential-development opportunity by a developer/agent rubric.**

Secondary: **≥ 85% of the top 50 countywide.** We track precision before/after
every change and never ship a change that lowers it or lowers back-tested
discovery lift (currently 2.69×).

We state the honest limit up front: at 419k parcels, rules alone will never make
every lead perfect. The realistic, grounded goal is **high precision at the top
(where agents actually look) plus a human-in-the-loop labeling flywheel** that
keeps improving it. That is achievable and measurable.

---

## 3. The grounding rubric — "would a developer actually build housing here?"

Every rule, penalty, and knockout must map to one of three real questions a
residential developer asks. This rubric is the audit's north star; any lead that
fails a hard test is a fake, any that scores high on soft ones is a real signal.

**A. Is it ACQUIRABLE?**
- Not government / institutional / exempt (public parks, schools, churches,
  cemeteries, hospitals, utilities). *(knockout — largely built)*
- Not owned by an entity that won't sell (HOA common area, active operating
  business on its own land, a builder mid-build-out). *(mix of built + gaps)*
- Owner reachable (absentee/LLC/estate = softer, already modeled).

**B. Is it BUILDABLE for housing?**
- Zoning permits residential *(modeled in-city; blind in townships — gap)*.
- Lot is physically developable: adequate size, road frontage/access (not
  landlocked), not a sliver, buildable topo, not floodway/wetland. *(size + slope
  + floodway modeled; frontage/wetland/geometry = gaps)*.
- Residential context: houses actually get built around here. *(modeled in-city)*.

**C. Is it WORTH it?**
- Real development demand nearby *(permit-density modeled in-city; blind in
  townships)*.
- Not already taken (recent build permit). *(modeled)*.
- The "improvement" isn't a real operating building we'd be foolish to demolish
  *(commercial-land & satellite rules; refine)*.

If a scoring assumption can't be traced to one of these, it's not grounded and
comes out.

---

## 4. Phase 0 — Build the measurement (you can't fix what you can't see)

> **✅ BUILT & VERIFIED (2026-07-29).** `lead_labels` table (migration 020),
> seeded from history (**106,644 labels** across the 8 known fake classes +
> the agent's 8 verified Oakley calls), a precision report, and a working review
> harness (Audit tab). **Baseline precision: only ~2% of the top-50 board has
> been reviewed** — the honest starting point this phase existed to expose. It
> already flags that Oakley's top-25 still contains 2 known fakes (the Calvert
> "behind Petsmart" lots, only soft-penalized). The #1 countywide lead (11720
> Snider Rd, Symmes Twp, score 88) is a township parcel — precisely the Tier-1
> gap. Endpoints: `/audit/precision`, `/audit/queue`, `/audit/label`. CLIs:
> `python -m scoring.leadaudit.seed_from_history` / `.precision`.
>
> **Harness usability fix (2026-07-30):** first real use showed a reviewer stuck
> on the top ~10 — Skip re-fetched the same leads (looped) and there was no way
> to reach a specific lot. Fixed: `/audit/queue` now takes `offset` +
> `min_score`/`max_score` (page deeper, target a score band), Skip advances
> forward through the whole ranking, and `/audit/search` + a search box let a
> reviewer jump to any parcel by address or id (already-labelled ones shown with
> their verdict, re-labelable). This makes Phase-1 whole-board review workable.

**Nothing else starts until we can measure precision.** ~1 week.

1. **`lead_labels` table** — the durable ground-truth asset:
   `parcel_id, label (real|fake|maybe), reason_code, source (history|review|agent),
   reviewer, reviewed_at, notes`. One row per human judgment.
2. **Seed it from history.** Every class we've already corrected becomes labeled
   fake with its reason_code: `public_park`, `institutional`, `golf_club`,
   `apartment_satellite`, `commercial_land`, `subdivision_inventory`,
   `condo_unit`, `commercial_strip`, `permit_issued`, plus the agent's four Oakley
   misses. This instantly gives us a regression set.
3. **Precision baseline report** (`scoring/leadaudit/precision.py`): for the
   current top-N per neighborhood and countywide, report % labeled real / fake /
   unknown. Publishes the number we're trying to move.
4. **Review harness** (`scoring/leadaudit/review.py` + a minimal web view):
   pulls a parcel, shows its dossier **plus a deep-link to aerial + Google Street
   View at its lat/lon** (the single biggest accelerator — a reviewer confirms
   "parking lot / park / occupied house / vacant lot" in five seconds, exactly as
   a developer eyeballs a site), and captures a label + reason_code in one click.

Deliverable: a precision number, and a growing labeled set.

---

## 5. Phase 1 — Systematic stratified audit (find every gap, not just Oakley's)

Replace top-10-of-Oakley with **guaranteed coverage**. ~1–2 weeks of review.

Stratify the ≥50 working set across dimensions that each hide different fakes,
and review a sample from **every** cell so no class can hide:

- **Neighborhood / jurisdiction** — every region with ≥1 lead, especially the
  never-reviewed townships (Colerain, Anderson, Green, Miami, Sycamore, Crosby).
- **Score band** — ≥70, 60–70, 50–60 (a fake at 62 matters as much as one at 74).
- **use_classification** — assemblage, single-family, missing-middle, mixed-use,
  non-residential (assemblage is 1,080 leads — sample it hard).
- **Zoning present vs absent** — the 596 no-zoning leads are their own stratum.
- **Lot-size band** — flag the large-acreage tail (median 1.4 ac in no-zoning).

For each reviewed parcel, the reviewer applies the §3 rubric and records
real/fake + reason. **Every new fake reason_code that appears becomes a candidate
rule.** Output: a ranked backlog of fake-lead classes by *how many leads each one
removes* — so we fix the highest-impact gaps first.

---

## 6. Phase 2 — The false-positive taxonomy (close the gaps, worst-first)

A formal, living catalog. Each entry: detector, current coverage, known gap. We
build detectors for the gaps in impact order (Phase 1 ranks them; the data
already points at the top few).

### Already covered (verify, don't rebuild)
| # | Class | Detector | Status |
|---|---|---|---|
| 1 | Public / exempt (parks, gov) | DTE 6xx + owner_type public | knockout ✓ |
| 2 | Institutional (hospital/school/church/cemetery) | owner keyword + class | knockout ✓ |
| 3 | Regulatory floodway | overlay centroid/area | knockout ✓ |
| 4 | Operating amenity (golf/clubs) | class 461–463 + owner kw | ×0.3 ✓ |
| 5 | Apartment-complex bookkeeping | NULL/$0 satellite | under=0 ✓ |
| 6 | Commercial land (parking/gas/outparcel) | class 401–499 + low I/L | under=0 ✓ |
| 7 | Builder subdivision inventory | ≥3 same-owner $0 class-500 | ×0.35 ✓ |
| 8 | Condo regime | identical geometry cluster | under=0 ✓ |
| 9 | Commercial-strip context | res_context_pct + zoning | ramp ✓ |
| 10 | Already being developed | recent build permit | ×0.15 ✓ |

### Prioritized gaps (grounded in the §1 data + the rubric)
**Tier 1 — biggest lead-count impact, do first:**
- **A. Township / out-of-service-area rural.** 638 ≥50 leads with no zoning/
  demand. Ground truth: an *infill* platform shouldn't rank 1.4-acre rural
  parcels like city lots. Fix: encode the **urban service boundary / density
  context**; where we have no zoning rules and no permit demand, either apply
  township zoning (if obtainable) or a "low-info penalty" so we don't over-credit
  a parcel we know little about. Do **not** silently null-favor unknowns.
- **B. Large-acreage non-infill.** Lots far above a plausible residential
  infill/subdivision envelope (e.g. >2–3 acres outside a platted context) are
  land deals or ag, not the product this tool is for. Fix: size-context penalty
  tied to surrounding lot fabric (a 2-acre lot among 5k-sqft lots ≠ a 2-acre lot
  in a rural section).
- **C. Assemblage inflation.** 1,080 ≥50 leads. Audit whether same-owner
  clustering over-credits (e.g. two adjacent side-lots reading as a "site").
  Re-validate the assemblage floor/ramp against real assembled-development comps.

**Tier 2 — known classes not yet modeled:**
- **D. HOA / subdivision common area & "reserve" parcels** — owned by an HOA or
  platted as open space, undevelopable by covenant. Detect via owner keywords
  (HOMEOWNERS, HOA, ASSN, CONDOMINIUM, RESERVE, COMMON) + class + plat naming.
- **E. Utility / infrastructure land** — substations, stormwater detention
  basins, MSD easements, pump stations, ROW remnants. Owner keywords (utility
  co's, MSD, WATER WORKS, DUKE) + tiny-improvement + shape.
- **F. Landlocked / no road frontage** — needs a road-centerline adjacency check
  (CAGIS has the layer). No frontage = not realistically developable.
- **G. Cemeteries / active religious land** not caught by owner keywords (some are
  class-coded but individually owned).
- **H. Occupied, viable commercial/industrial in active use** — a leased
  warehouse or full strip center is not a teardown at these land values.

**Tier 3 — data-dependent, do when the data is in:**
- **I. Wetlands / conservation easement** — needs the National Wetlands
  Inventory overlay.
- **J. Slope beyond the current flag / unbuildable geometry** (extreme
  narrowness, flag lots).

Each detector follows the house pattern: a `classify.py` predicate → either a
knockout (physically/legally impossible) or a soft penalty **with a waiver** for
the case where distress or land-bank status makes it a legit play (as with golf
clubs and subdivisions). We prefer soft penalties over knockouts unless the lead
is truly impossible, to avoid throwing out real opportunities.

---

## 7. Phase 3 — Data enrichment to close the physical-buildability gaps

Some fakes are invisible without more data. Prioritized by lead-count payoff:

| Gap it closes | Data source | Effort |
|---|---|---|
| Township zoning (blind areas) | County/township zoning layers, per jurisdiction | med–high |
| Urban service boundary | OKI / county planning boundary | low |
| Landlocked / frontage | CAGIS road centerlines (already available) | low–med |
| Wetlands | USFWS National Wetlands Inventory | low |
| Utility/stormwater land | MSD easements, owner registries | med |

We only ingest what removes real leads — every feed is justified by a Phase-1
count. Where data can't be had (some townships), the honest answer is a
**low-information penalty**, not a fabricated assumption.

---

## 8. Phase 4 — The flywheel: turn the pilot CRM into a labeling machine

The lead pipeline we just built is the engine that makes this self-sustaining:

- **Structured "Passed" reasons.** Add a small reason-code picker when an agent
  marks a lead **Passed** (`commercial`, `not_buildable`, `not_for_sale`,
  `already_developed`, `wrong_area`, `too_expensive`, `other + note`). Every pass
  writes a `lead_labels` row (source=agent) automatically.
- **Implicit positives.** A lead an agent advances to Site Visit / Deal is a
  strong real-opportunity label.
- **Systematic-miss detector.** Weekly, cluster agent "Passed" reasons; any
  reason_code spiking on high-scoring parcels is a new fake class → new detector.
  This is the Oakley loop, automated and countywide.

This is why precision keeps improving during the pilot instead of plateauing.

---

## 9. Phase 5 — Regression safety & release gates

Non-negotiable for every scoring change (already our practice, formalized):

1. **Every confirmed fake becomes a regression test** (extend
   `test_agent_feedback_round_oakley` into a labeled-set assertion: known fakes
   must score below their band; known reals must stay above).
2. **Re-run `backtest.py` after every change** — discovery lift must hold or rise
   (guardrails should remove noise, not signal; last round 2.23→2.69×).
3. **Precision report must not regress** on the labeled set.
4. Bump `scoring.yaml` version; archive the prior; record the audit finding in
   the version note (our existing audit-trail convention).

A change ships only if: regression tests green **and** lift ≥ prior **and**
precision@25 ≥ prior.

---

## 10. Tooling to build

- `db/ddl/020_lead_labels.sql` — the label store.
- `scoring/leadaudit/precision.py` — precision@N per neighborhood + countywide.
- `scoring/leadaudit/review.py` (+ a small review page or a column in the
  existing app) — stratified queue, dossier + aerial/StreetView deep-links,
  one-click label.
- `scoring/leadaudit/seed_from_history.py` — backfill labels from the nine known
  classes.
- Pipeline "Passed reason" UI + endpoint (Phase 4).
- Extend `scoring/tests/` with a labeled-set regression test.

---

## 11. Phased timeline & acceptance gates

| Phase | Work | Gate to advance |
|---|---|---|
| **0 · Measure** | label store, seed from history, precision baseline, review harness | a precision number exists |
| **1 · Audit** | stratified review across all regions/bands/classes | ranked backlog of fake classes by impact |
| **2 · Rules** | build detectors worst-first (Tier 1 → 3) | precision@25 hits 90%; lift holds |
| **3 · Data** | ingest the feeds that close physical gaps | each feed justified by lead count |
| **4 · Flywheel** | Passed-reason capture + weekly miss detector | agent passes auto-label |
| **5 · Gate** | regression tests + release gates wired in | no change ships that lowers precision or lift |

Phases 0–1 are the foundation and should be done before more rule-writing — they
convert this from "keep finding fakes forever" into "measurably drive precision
to a target and hold it." Phase 4 makes it self-sustaining through the pilot.

---

## 12. Honest limits (grounded, not aspirational)

- **Perfect is not the bar; trustworthy-at-the-top is.** We optimize precision on
  the leads agents actually see, and accept a long imperfect tail.
- **Some townships can't be fully grounded** without zoning data that may not
  exist digitally — there we penalize for low information rather than pretend.
- **Human judgment stays in the loop.** The labeled set and the agent flywheel are
  the product's moat; rules are downstream of them, not a replacement.
- **Never knock out a real opportunity to kill a fake.** Prefer soft penalties +
  waivers; a false *negative* (hiding a real lead) is as damaging to trust as a
  false positive.
