# Build roadmap (Section 15)

| Phase | Scope | Est. |
|---|---|---|
| **0 — Foundations** | Repo skeleton, Postgres+PostGIS+S3, CI, extractor interface, scoring config, DDL. | 1–2 wks |
| **1 — Base layer + MVP score** | Ingest CAGIS parcels + zoning + Auditor ownership/valuation. Underutilization (I/L) score + a simple map. *This alone is usable.* Shortcut: substitute Regrid Parcel API for CAGIS+Auditor to reach this faster. | 2–3 wks |
| **2 — Distress + signals** | Add code violations, VBML, foreclosure / tax-delinquency / sheriff feeds, land-bank scrape. Weekly recompute, distress alerts on new high-score parcels. | 2–3 wks |
| **3 — Use classification + constraints** | Connected Communities overlay + zoning capacity gap → capacity_gap_score. Constraint layers (flood/slope/historic/CSO). Knockouts + penalties. | 1–2 wks |
| **4 — Assemblage, lists, exports** | Spatial assemblage clustering, saved lists, CSV/GeoJSON exports, coverage dashboard, full distress suite + monitors. | 2 wks |
| **5 — Refinement** | ✅ Demand component (2026-07-18): neighborhood sales turnover / price momentum / sale-to-assessed from Auditor sale history, shown verbatim in the dossier. ✅ Data-plausibility auditor (2026-07-23): `scoring/audit.py` standing checks over leads (bulk/portfolio sale price, no arms-length sale, portfolio owner, incomplete valuation) → advisory `parcel_audit_flag` → dossier "Data checks" box; encodes the manual-diligence loop as a permanent guard. ✅ Back-tested against new-building permits (2026-07-24, `scoring/backtest.py`): composite shows 1.93x lift on parcels that get developed; the original resale-based demand was anti-predictive (Spearman -0.37) so demand was **rebuilt as development demand** (permit density + trajectory per neighborhood, v2026.15) → Spearman **+0.96** on a temporal holdout. Remaining: weight tuning, production deploy. | — |

## Current status

**Phase 0 — complete.** Repo layout, canonical DDL, scoring config, extractor
contracts + shared HTTP/normalizers, FastAPI contracts, docker-compose
(PostGIS + MinIO + API), CI-ready test suite.

**Phase 1 — MVP working (verified against live + frozen real data).**
- CAGIS extractor resolves the live FeatureServer, pages, reprojects to 4326;
  **smoke-tested against production: 2,000 real parcels, 100% parcel_id match.**
- Entity resolution to canonical Auditor Property Number.
- Raw archive (immutable, timestamped; S3/MinIO or local-fs fallback).
- Loader upserts `parcel_master` + appends `parcel_signals` (PostGIS).
- Use classification (Ohio DTE class → il-threshold group) + **underutilization
  score**; **distress score** already live from CAGIS's own delinquency/foreclosure
  flags. Composite renormalizes over computed components.
- `dbt` model for the SQL-expressible underutilization metric.
- API wired to PostGIS: ranked `/parcels`, `/parcels/{id}` dossier, `/geojson`,
  `/stats`.
- End-to-end pipeline test on a **frozen real 20-parcel sample** proves ranking:
  distressed-vacant > vacant > below-threshold > well-improved. 10/10 tests green.

**Phase 1 — closed.** Full county live: 420,225 parcels ingested (100% match),
419,814 scored, React+MapLibre explorer verified in browser. Scoring iterated
to v2026.3 (vacant-lot quality scaling, severity-scaled distress, ownership
modifier, per-type contribution caps); prior configs under scoring/config/versions/.

**Phase 2 — in progress.**
- ✅ Code violations (Socrata cncm-znd6): watermark-incremental extractor,
  spatial (point-in-polygon) resolution — 32,119 events on 15,076 parcels at
  96.0% match; event upsert on (source, raw_ref) so status changes flow through.
- ✅ Sheriff sales (RealAuction scrape): walks upcoming auction Wednesdays,
  parses case/parcel/opening-bid from the session-scoped AJAX loader — 66 sales
  across 8 upcoming dates, 100% direct parcel-ID resolution (book-page-parcel
  zero-pad mapping verified against parcel_master).
- ✅ Orchestration + alerting: cadence tiers (daily violations / weekly sheriff /
  quarterly CAGIS) as plain pipelines, wrapped by Prefect flows (`make
  serve-flows`) with a stdlib fallback scheduler. Scoring diffs against prior
  scores → alerts table (004) → Slack webhook or log; /alerts API. Verified
  live: daily tier pulled 692 new events and fired 5 real new-high alerts.
- ✅ Land bank inventory (`ingestion/landbank.py`): standing
  `landbank_inventory` signal derived from Auditor ownership (HCLRC, land-bank,
  and Port authority names) — 2,295 parcels, which waives the not_acquirable
  knockout so land-bank stock competes on merit. Deliberately not scraped: the
  Port's listing portal is a third-party Tolemi SPA whose data API needs
  session context (public GraphQL at cg.tolemi.com/q, header
  `city-alias: the-port-oh`, city id 310 — documented for a future attempt).
  `import_listing_csv()` ingests the portal's own "Export spreadsheet" download
  to enrich signals with asking price / program when someone drops the file in.
- ☐ VBML / vacant-building signal.
- ☐ Phase 1b (deferred): dedicated Auditor extractor for valuation source-of-truth.

**Phase 3a — constraint overlays: complete (verified in browser).**
- FEMA NFHL SFHA + Cincinnati hillside + historic districts loaded to
  constraint_zones; flags: flood 22,268 / slope 39,430 / historic 8,713 /
  **floodway 4,527 (hard knockout: centroid-in or >30% overlap)**.
- 64 invalid CAGIS parcel geometries repaired in place (ST_MakeValid).
- Constraint-aware re-score: 70+ leads 1,196 → 863 (28% carried entitlement
  risk); knockouts zeroed (e.g. downtown riverfront on W Mehring Way);
  1101 Vine St correctly discounted 98.1 → 83.4 with a visible historic chip.
- Map dossier shows constraint chips (knockouts in red).

**Phase 3b — zoning capacity gap: complete (verified in browser).**
- CAGIS Countywide Zoning (layer 21, 4,051 polys, all jurisdictions) loaded;
  zoning_code assigned to 321,124 parcels by centroid containment.
- zoning_rules.yaml encodes Cincinnati districts (SF-x min lots, RM-x sqft/unit,
  transect T3-T5, DD, commercial mixed-use approximations); suffixed variants
  (RM-1.2-T) resolve to base districts. Townships not yet encoded (conservative
  null — component excluded per-parcel, never guessed).
- capacity_gap_score = saturating scale of (allowed - existing) units; existing
  from NUM_UNITS (next CAGIS ingest) or DTE-class estimate. 170,729 parcels
  scored; composite now blends 3 of 5 components.
- Connected Communities: no published layer (spec [VERIFY] confirmed absent);
  cc_overrides hooks in zoning_rules.yaml are dormant until boundaries are
  reconstructed from the ordinance maps.
- Top finds: 4045 Reading Rd (73k sqft vacant RM-1.2, ~60 units by right,
  97.55), 7631 Daly Rd (5.8-acre SF-6 subdivision play, 93.5).

**Phase 4a — same-owner assemblage: complete (verified in browser).**
- ST_ClusterDBSCAN (~1m eps) partitioned by owner_name_norm; public/
  institutional owners excluded. 39,588 clusters / 120,366 member parcels;
  qualifying = >=2 lots and combined >= 7,500 sqft (scoring.yaml).
- assemblage_score = combined-footprint ramp x cluster mean underutilization
  (built-out multi-deed holdings read ~0); members share the score and carry
  assemblage_id; non-members score 0. Fourth composite component (v2026.7).
- Clarity UX: dashed purple union outline on the map (distinct layer + legend
  entry); dossier "N lots as one site" box with combined sqft / land value /
  owner and a clickable list of every underlying lot (click-through verified).
- Fix en route: public-owner keyword check now precedes the llc check
  ("...LAND REUTILIZATION CORPORATION" was reading as llc; 1,834 backfilled).
- Top find: 4045 Reading Rd is actually a 3-lot 129,900 sqft same-owner
  assemblage (94.85). Multi-owner adjacency (e.g. Glenwood: TARJA 2 lots +
  PACO 1 lot) deferred to Phase 4b.

**Phase 4b — region browsing + exports: complete (verified in browser).**
- Every parcel carries a region: Cincinnati SNA neighborhood (2020 boundaries)
  in-city, zoning jurisdiction elsewhere (312,879 assigned; migration 008).
- /neighborhoods ranked picker; region filter on parcels/geojson/assemblages;
  UI dropdown with fit-to-region.
- /export?fmt=xlsx|csv: ranked call sheet for the current filter — score
  breakdown, owner + mailing address, valuation, zoning, next sheriff sale.
  Green Excel button in the topbar.
- Root-cause fix: MapLibre mutates the style spec object — StrictMode's double
  mount corrupted the shared BASE_STYLE and silently hung the second map's
  style load (all prior "map won't render" mysteries). structuredClone per map.
