-- Underutilization metric (Section 9.1) as a SQL-expressible dbt model. The
-- Python scorer (scoring/run.py) can consume this directly, or recompute in
-- Python for the MVP; both must agree. Thresholds mirror scoring.yaml il_thresholds.
--
-- I/L ratio = improvement_value / land_value. Vacant land = max signal (100).
-- Otherwise score ramps toward 100 as I/L falls below the use-group threshold.

with p as (
    select
        parcel_id,
        land_use_code,
        improvement_value,
        land_value,
        has_structure,
        improvement_value / nullif(land_value, 0) as il_ratio,
        case
            when land_use_code::int in (510, 550, 500) then 'single_family'
            when land_use_code::int between 500 and 599 then 'multifamily'
            else 'commercial'
        end as use_group,
        (
            coalesce(has_structure, false) = false
            or coalesce(improvement_value, 0) <= 0
            or land_use_code::int in (300, 400, 500)
        ) as is_vacant_land
    from {{ ref('int_parcel_master') }}
),
thresholds as (
    select 'single_family' as use_group, 0.5 as il_threshold
    union all select 'multifamily', 1.0
    union all select 'commercial', 1.0
)
select
    p.parcel_id,
    p.il_ratio,
    p.use_group,
    p.is_vacant_land,
    case
        when p.is_vacant_land then 100.0
        when p.il_ratio is null then 0.0
        else round(100.0 * greatest(0.0, (t.il_threshold - p.il_ratio) / t.il_threshold), 2)
    end as underutilization_score
from p
join thresholds t using (use_group)
