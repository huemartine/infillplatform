-- Canonical parcel assembly (Section 6.3). In the MVP the CAGIS Open Data layer
-- already carries Auditor valuation, so this is a passthrough of the loaded
-- parcel_master; in Phase 1b it becomes the join of stg_cagis + stg_auditor on
-- the canonical parcel_id (Auditor source-of-truth for valuation).
select
    parcel_id,
    land_use_code,
    land_value,
    improvement_value,
    total_value,
    has_structure
from {{ source('canonical', 'parcel_master') }}
