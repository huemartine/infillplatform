-- Assemblies v2: multi-parcel large-tract opportunities.
--
-- The original model (migration 007) qualified any same-owner adjacent cluster
-- over 7,500 sqft — 0.17 acres — so a house plus its side lot counted, and 83%
-- of clusters came back under 2 acres. It also let apartment-complex bookkeeping
-- deeds, condo regimes and builder inventory through, and it fed the opportunity
-- score. This version keeps the table and the union outline, and adds what the
-- rebuild needs to tell the two tiers apart:
--
--   kind          'same_owner'  one owner holds every parcel — one negotiation
--                 'multi_owner' adjacent parcels under different owners — a real
--                               assembly play, but it needs N sellers to agree
--   owner_count   distinct owners in the cluster (1 for same_owner)
--   neighborhood  the cluster's region, so the view can scope to target markets
--   combined_acres  combined_sqft in acres, stored so sorting/filtering is cheap
ALTER TABLE assemblages ADD COLUMN IF NOT EXISTS kind text NOT NULL DEFAULT 'same_owner';
ALTER TABLE assemblages ADD COLUMN IF NOT EXISTS owner_count int;
ALTER TABLE assemblages ADD COLUMN IF NOT EXISTS neighborhood text;
ALTER TABLE assemblages ADD COLUMN IF NOT EXISTS combined_acres numeric;

CREATE INDEX IF NOT EXISTS assemblages_kind_idx ON assemblages (kind);
CREATE INDEX IF NOT EXISTS assemblages_acres_idx ON assemblages (combined_acres DESC);
CREATE INDEX IF NOT EXISTS assemblages_nb_idx ON assemblages (neighborhood);
