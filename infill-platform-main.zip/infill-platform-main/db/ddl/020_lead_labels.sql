-- Ground-truth labels for the lead audit (Phase 0 of the lead-audit plan).
-- One row per human (or heuristic) judgment that a parcel is a real residential
-- development opportunity, a fake, or uncertain. This is the durable asset the
-- whole audit turns on: it lets us MEASURE precision at the top of the board and
-- REGRESSION-test that known fakes stay demoted and known reals stay surfaced.
--
-- Multiple rows per parcel are allowed on purpose (an audit trail): a heuristic
-- 'history' seed can later be overridden by a human 'review' or an 'agent' pass.
-- The "effective" label is the highest-precedence, most-recent row
-- (review > agent > history); see scoring/leadaudit/labels.py.
CREATE TABLE IF NOT EXISTS lead_labels (
    id           bigserial PRIMARY KEY,
    parcel_id    text NOT NULL REFERENCES parcel_master (parcel_id),
    label        text NOT NULL,          -- real | fake | maybe
    reason_code  text,                   -- taxonomy code (mainly for fakes)
    source       text NOT NULL,          -- history | review | agent
    reviewer     text,                   -- email, 'system', or a seed tag
    notes        text,
    reviewed_at  timestamptz DEFAULT now(),
    created_at   timestamptz DEFAULT now()
);
CREATE INDEX IF NOT EXISTS lead_labels_parcel_idx ON lead_labels (parcel_id);
CREATE INDEX IF NOT EXISTS lead_labels_reason_idx ON lead_labels (reason_code);
CREATE INDEX IF NOT EXISTS lead_labels_source_idx ON lead_labels (source, reviewed_at DESC);
