-- Pipeline v2: reshape the funnel around the team's real outreach workflow —
-- find -> vet (diligence) -> outreach -> response -> hand off to another CRM.
-- New stages: prospect -> diligence -> outreach -> responded -> handed_off, plus
-- passed (archive from anywhere). Response OUTCOME (positive/negative) is a field,
-- not a stage. Old stages are remapped so no pilot data is lost.

-- lead fields for response tracking + a human-in-the-loop diligence checklist
ALTER TABLE leads ADD COLUMN IF NOT EXISTS response_outcome text;  -- positive | negative | null
ALTER TABLE leads ADD COLUMN IF NOT EXISTS responded_at date;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS diligence jsonb;        -- {key: bool} checklist the agent confirms

-- remap existing stages (leads + their per-stage timeline entries)
UPDATE leads SET stage = CASE stage
    WHEN 'watchlist'  THEN 'prospect'
    WHEN 'site_visit' THEN 'diligence'
    WHEN 'deal'       THEN 'responded'
    WHEN 'closed'     THEN 'handed_off'
    ELSE stage END
WHERE stage IN ('watchlist', 'site_visit', 'deal', 'closed');

UPDATE lead_entries SET stage = CASE stage
    WHEN 'watchlist'  THEN 'prospect'
    WHEN 'site_visit' THEN 'diligence'
    WHEN 'deal'       THEN 'responded'
    WHEN 'closed'     THEN 'handed_off'
    ELSE stage END
WHERE stage IN ('watchlist', 'site_visit', 'deal', 'closed');

ALTER TABLE leads ALTER COLUMN stage SET DEFAULT 'prospect';
