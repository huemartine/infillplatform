-- The "is this a valuable area" number that folds into the condition-gap search:
-- the median LAND value of the nearby same-class houses used as a parcel's
-- condition-gap peer set. Lets a search ask for a run-down house (high
-- condition_gap) specifically in a GREAT area (high area_land_value) — the
-- diamond-in-the-rough, not just any low house on any block.
ALTER TABLE parcel_master ADD COLUMN IF NOT EXISTS area_land_value numeric;
