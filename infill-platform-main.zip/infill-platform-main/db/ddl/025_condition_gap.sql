-- "Worse than its block" signal: how far a house's assessed building value per
-- finished sqft sits BELOW the local median of nearby same-class houses. The
-- assessor's improvement value already encodes age/condition/quality, so a home
-- valued at a fraction of its neighbors' per-foot is the run-down-house-on-a-nice
-- -street a teardown team drives around to find. 0 = at/above local median,
-- 100 = far below. NULL until computed (needs home_sqft + enough local peers).
ALTER TABLE parcel_master ADD COLUMN IF NOT EXISTS condition_gap numeric;
