-- New-construction building permits (Cincinnati Socrata uhjb-xac9), used as the
-- ground-truth "development actually happened here" outcome for back-testing the
-- opportunity score. Also usable later as a forward signal (a parcel that just
-- pulled a build permit is being developed now).
CREATE TABLE IF NOT EXISTS development_permits (
    permit_num    text PRIMARY KEY,
    parcel_id     text,
    work_class    text,
    permit_type   text,
    proposed_use  text,
    issued_date   date,
    est_cost      numeric,
    units         numeric,
    address       text,
    neighborhood  text,
    loaded_at     timestamptz DEFAULT now()
);
CREATE INDEX IF NOT EXISTS development_permits_parcel_idx ON development_permits (parcel_id);
CREATE INDEX IF NOT EXISTS development_permits_issued_idx ON development_permits (issued_date);
