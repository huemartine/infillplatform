-- Phase 4: assemblage detection. One row per same-owner cluster of adjacent
-- parcels whose combined footprint clears the developable threshold. The union
-- outline (geom) renders on the map as one opportunity; members point back via
-- parcel_master.assemblage_id so the underlying lots stay individually visible.
CREATE TABLE IF NOT EXISTS assemblages (
    id                  bigserial PRIMARY KEY,
    owner_name_norm     text,
    parcel_count        int,
    combined_sqft       numeric,
    combined_land_value numeric,
    geom                geometry(MultiPolygon, 4326),
    build_key           text,        -- owner|cluster key, transient join aid during rebuild
    computed_at         timestamptz DEFAULT now()
);
CREATE INDEX IF NOT EXISTS assemblages_gix ON assemblages USING gist (geom);

ALTER TABLE parcel_master ADD COLUMN IF NOT EXISTS assemblage_id bigint;
CREATE INDEX IF NOT EXISTS parcel_master_assemblage_idx
    ON parcel_master (assemblage_id) WHERE assemblage_id IS NOT NULL;
