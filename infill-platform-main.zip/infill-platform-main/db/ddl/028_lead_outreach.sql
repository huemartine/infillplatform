-- Outreach log: one row per letter generated for a lead. Supports repeat rounds
-- and carries the digital response token (the QR / short link on the printed
-- letter). When an owner responds via that link, this row records the outcome and
-- the lead advances to 'responded'.
CREATE TABLE IF NOT EXISTS lead_outreach (
    id             bigserial PRIMARY KEY,
    lead_id        bigint NOT NULL REFERENCES leads (id) ON DELETE CASCADE,
    channel        text NOT NULL DEFAULT 'letter',
    status         text NOT NULL DEFAULT 'generated',   -- generated | sent | responded
    response_token uuid NOT NULL DEFAULT gen_random_uuid() UNIQUE,
    generated_at   timestamptz DEFAULT now(),
    sent_at        timestamptz,
    responded_at   timestamptz,
    outcome        text,                                 -- positive | negative | no_response
    notes          text
);
CREATE INDEX IF NOT EXISTS lead_outreach_lead_idx ON lead_outreach (lead_id, generated_at);
