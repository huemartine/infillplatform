-- Ohio Homestead Exemption flag (Auditor HMSD_FLAG). By statute the reduction
-- applies only to owners 65+ or permanently & totally disabled (income-tested for
-- grants since 2014) — a public, exact-data proxy for a senior / likely-to-sell
-- owner. Not an age value; a qualifying status.
ALTER TABLE parcel_master ADD COLUMN IF NOT EXISTS homestead boolean;
