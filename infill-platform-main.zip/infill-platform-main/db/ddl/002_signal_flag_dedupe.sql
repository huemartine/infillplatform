-- Standing flags (status='flag': CAGIS delinquency/foreclosure, landbank
-- inventory) are facts about current state, not dated events — one row per
-- (parcel, type, source), refreshed each ingest. Dated filings from the Phase 2
-- feeds keep other status values and remain append-only.

-- 1. Dedupe existing flag rows, keeping the most recent ingest.
DELETE FROM parcel_signals s
USING parcel_signals newer
WHERE s.status = 'flag'
  AND newer.status = 'flag'
  AND s.parcel_id = newer.parcel_id
  AND s.signal_type = newer.signal_type
  AND s.source = newer.source
  AND s.id < newer.id;

-- 2. Enforce uniqueness for flags so ingest can upsert.
CREATE UNIQUE INDEX IF NOT EXISTS parcel_signals_flag_uniq
    ON parcel_signals (parcel_id, signal_type, source)
    WHERE status = 'flag';
