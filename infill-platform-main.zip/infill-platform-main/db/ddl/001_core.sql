-- Canonical data model for the Infill & Development Land Discovery Platform.
-- Three master tables (Appendix D). parcel_id = Hamilton County Property Number,
-- the universal join key. Geometry stored as MultiPolygon in EPSG:4326 (reprojected
-- on load from the county's State Plane SRID). Run after CREATE DATABASE.

CREATE EXTENSION IF NOT EXISTS postgis;

-- ---------------------------------------------------------------------------
-- parcel_master: one row per parcel. Current state, derived columns included.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS parcel_master (
    parcel_id          text PRIMARY KEY,                 -- Hamilton County Property Number
    geom               geometry(MultiPolygon, 4326),
    centroid           geometry(Point, 4326),
    area_sqft          numeric,
    address            text,
    owner_name_raw     text,
    owner_name_norm    text,
    owner_mailing_addr text,
    is_absentee        boolean,                          -- owner mailing ZIP != site ZIP
    owner_type         text,                             -- individual | llc | trust | public | other
    land_value         numeric,
    improvement_value  numeric,
    total_value        numeric,
    il_ratio           numeric,                          -- improvement_value / land_value
    land_use_code      text,
    zoning_code        text,
    last_sale_date     date,
    last_sale_price    numeric,
    has_structure      boolean,
    cc_zone            text,                             -- Connected Communities: nbd | corridor | brt | none
    flood_flag         boolean,
    slope_flag         boolean,
    historic_flag      boolean,
    cso_flag           boolean,
    updated_at         timestamptz DEFAULT now()
);
CREATE INDEX IF NOT EXISTS parcel_master_geom_gix     ON parcel_master USING gist (geom);
CREATE INDEX IF NOT EXISTS parcel_master_centroid_gix ON parcel_master USING gist (centroid);
CREATE INDEX IF NOT EXISTS parcel_master_zoning_idx   ON parcel_master (zoning_code);
CREATE INDEX IF NOT EXISTS parcel_master_landuse_idx  ON parcel_master (land_use_code);

-- ---------------------------------------------------------------------------
-- parcel_signals: append-only event stream (distress, permits, listings...).
-- Many rows per parcel; recency drives distress scoring with per-signal decay.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS parcel_signals (
    id            bigserial PRIMARY KEY,
    parcel_id     text NOT NULL REFERENCES parcel_master (parcel_id),
    signal_type   text NOT NULL,                         -- foreclosure_filing | sheriff_sale | tax_delinquent | condemnation | code_violation | landbank_inventory | permit | listing
    event_date    date,
    status        text,
    severity      numeric,
    source        text,
    raw_ref       text,                                  -- pointer to S3 raw record
    ingested_at   timestamptz DEFAULT now()
);
CREATE INDEX IF NOT EXISTS parcel_signals_parcel_idx ON parcel_signals (parcel_id);
CREATE INDEX IF NOT EXISTS parcel_signals_type_date_idx ON parcel_signals (signal_type, event_date);

-- ---------------------------------------------------------------------------
-- parcel_scores: latest computed scores. Versioned by scoring_config_version
-- for reproducibility and A/B comparison of weightings.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS parcel_scores (
    parcel_id              text PRIMARY KEY REFERENCES parcel_master (parcel_id),
    opportunity_score      numeric,                       -- 0..100 weighted composite * constraint penalties
    underutilization_score numeric,
    capacity_gap_score     numeric,
    distress_score         numeric,
    assemblage_score       numeric,
    demand_score           numeric,
    use_classification     text,                          -- missing-middle | rowhome | mixed-use | LIHTC | single-family SF | assemblage | hold/monitor
    constraints            jsonb,                          -- active flags: flood, slope, historic, brownfield...
    scoring_config_version text,
    scored_at              timestamptz DEFAULT now()
);
CREATE INDEX IF NOT EXISTS parcel_scores_opportunity_idx ON parcel_scores (opportunity_score DESC);
CREATE INDEX IF NOT EXISTS parcel_scores_useclass_idx    ON parcel_scores (use_classification);

-- ---------------------------------------------------------------------------
-- ingest_runs: observability for the ingestion layer. One row per extractor run.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS ingest_runs (
    id                bigserial PRIMARY KEY,
    source            text NOT NULL,
    started_at        timestamptz,
    finished_at       timestamptz,
    row_count         int,
    match_rate        numeric,                            -- share resolved to a parcel_id
    status            text,                               -- running | success | failed
    s3_path           text,
    error             text
);
CREATE INDEX IF NOT EXISTS ingest_runs_source_started_idx ON ingest_runs (source, started_at DESC);
