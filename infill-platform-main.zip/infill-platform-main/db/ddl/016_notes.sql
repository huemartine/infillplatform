-- Per-realtor notes on parcels. A working-notebook feature (an agent's private
-- notes on a lead, kept in their account) that doubles as rich pilot metadata:
-- which parcels agents actually engage, in their own words. Identity is the
-- agent's email (from Cloudflare Access in prod; a dev fallback locally) - no
-- passwords stored here.
CREATE TABLE IF NOT EXISTS parcel_notes (
    id          bigserial PRIMARY KEY,
    user_email  text NOT NULL,
    parcel_id   text NOT NULL REFERENCES parcel_master (parcel_id),
    body        text NOT NULL,
    created_at  timestamptz DEFAULT now()
);
CREATE INDEX IF NOT EXISTS parcel_notes_user_parcel_idx ON parcel_notes (user_email, parcel_id);
CREATE INDEX IF NOT EXISTS parcel_notes_user_recent_idx ON parcel_notes (user_email, created_at DESC);
