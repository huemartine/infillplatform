-- Utility infrastructure: can you actually build here, or does the lot need a
-- septic system / a water-main extension? Critical for fringe parcels, and it
-- already matters in-market (about a third of Indian Hill is on private septic).
--
-- on_septic   TRUE when the parcel appears in Hamilton County Public Health's
--             private sewage-treatment-system inventory = it is NOT on sanitary
--             sewer. NULL/false means "not in the septic inventory" — strong
--             evidence of sewer in built-up areas, but not proof out in the
--             townships (an unrecorded system wouldn't appear). MSD does not
--             publish its sewer main network publicly, so this inventory is the
--             authoritative public signal.
-- water_main_ft  feet to the nearest fire hydrant — a proxy for a water main in
--             the street (hydrants tap mains).
ALTER TABLE parcel_master ADD COLUMN IF NOT EXISTS on_septic boolean;
ALTER TABLE parcel_master ADD COLUMN IF NOT EXISTS water_main_ft numeric;

-- Point infrastructure we measure distance to (fire hydrants).
CREATE TABLE IF NOT EXISTS infra_points (
    id    bigserial PRIMARY KEY,
    kind  text NOT NULL,               -- hydrant
    geom  geometry(Point, 4326)
);
CREATE INDEX IF NOT EXISTS infra_points_gix ON infra_points USING gist (geom);
CREATE INDEX IF NOT EXISTS infra_points_kind_idx ON infra_points (kind);
