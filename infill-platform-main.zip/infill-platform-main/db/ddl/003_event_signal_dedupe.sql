-- Dated event signals (code violations, foreclosure filings...) carry the source
-- system's natural key in raw_ref (e.g. Socrata number_key). One row per source
-- record: re-ingests and status changes upsert instead of duplicating. Standing
-- flags (raw_ref IS NULL, status='flag') are governed by 002.
CREATE UNIQUE INDEX IF NOT EXISTS parcel_signals_event_uniq
    ON parcel_signals (source, raw_ref)
    WHERE raw_ref IS NOT NULL;
