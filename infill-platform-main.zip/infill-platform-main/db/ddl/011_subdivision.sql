-- Builder subdivision inventory: platted lots held by the developer who is
-- building them out (uniform land values, one plat transfer date, same owner,
-- >= min_lots together). They read as pristine vacant land but are an active
-- project's stock, not acquirable sites. Soft-flagged, not knocked out — a
-- stalled/distressed subdivision is a legitimate play (distress waiver).
ALTER TABLE parcel_master ADD COLUMN IF NOT EXISTS is_subdivision_lot boolean;
CREATE INDEX IF NOT EXISTS parcel_master_subdivision_idx
    ON parcel_master (is_subdivision_lot) WHERE is_subdivision_lot;
