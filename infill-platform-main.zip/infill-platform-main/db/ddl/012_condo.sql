-- Condominium regime: multiple deeds sharing one physical footprint (a
-- horizontal-property-regime condo/townhouse development). Each unit deed
-- legally carries the full footprint's area and land value, so scoring them as
-- N independent lots multiplies one site's development potential by the unit
-- count. Found on Wind St, Columbia Twp: 6 unbuilt Blue Ocean Development units
-- + 1 sold $1.1M townhouse, all on one ~1-acre footprint, each scoring 80.75.
ALTER TABLE parcel_master ADD COLUMN IF NOT EXISTS is_condo_unit boolean;
CREATE INDEX IF NOT EXISTS parcel_master_condo_idx
    ON parcel_master (is_condo_unit) WHERE is_condo_unit;
