-- Residential context (the spec's dormant `infill` concept, finally wired):
-- share of a parcel's neighbors that are improved residential. A vacant lot on
-- a residential street is infill; the same lot in a commercial strip is not a
-- housing play (Oakley's Calvert St leads: 0-19% residential neighbors, scored
-- as if they were single-family teardown streets). Computed for vacant-thesis
-- candidates only; NULL = unknown/not-applicable (never punished).
ALTER TABLE parcel_master ADD COLUMN IF NOT EXISTS res_context_pct numeric;
