-- Alerting (Section 2, component 7): each scoring run diffs against the prior
-- scores and records parcels that newly crossed the high-score threshold or
-- jumped sharply. Notification state lives here so delivery is at-least-once
-- and replayable.
CREATE TABLE IF NOT EXISTS alerts (
    id           bigserial PRIMARY KEY,
    parcel_id    text NOT NULL REFERENCES parcel_master (parcel_id),
    alert_type   text NOT NULL,           -- new_high | score_jump
    old_score    numeric,
    new_score    numeric NOT NULL,
    details      jsonb,
    created_at   timestamptz DEFAULT now(),
    notified_at  timestamptz
);
CREATE INDEX IF NOT EXISTS alerts_unnotified_idx ON alerts (created_at) WHERE notified_at IS NULL;
CREATE INDEX IF NOT EXISTS alerts_parcel_idx ON alerts (parcel_id);
