-- Municipality / political jurisdiction per parcel (Phase 1 of the Oyler Hines
-- master plan). Sourced from CAGIS "Hamilton County Address Jurisdictions"
-- (CagisCoreLayers/MapServer/17) — the authoritative 50-jurisdiction layer that
-- covers the WHOLE county, unlike the SNA neighborhoods (Cincinnati only) and
-- the countywide-zoning JURISDICTION field (missing the villages/cities that run
-- their own zoning, e.g. Madeira, Indian Hill, Blue Ash).
--
-- With this, `neighborhood` becomes the app's region key = the SNA name inside
-- Cincinnati, else the municipality — so the team's target markets (Madeira,
-- Montgomery, Indian Hill, Blue Ash, Symmes Twp) are finally filterable.
ALTER TABLE parcel_master ADD COLUMN IF NOT EXISTS municipality text;
CREATE INDEX IF NOT EXISTS parcel_master_municipality_idx ON parcel_master (municipality);
