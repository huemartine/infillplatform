-- Region browsing: every parcel gets a human region name — Cincinnati SNA
-- neighborhood (2020 boundaries) inside the city, else the zoning layer's
-- jurisdiction (municipality/township). Drives the realtor-facing region
-- picker, ranked neighborhood lists, and exports.
ALTER TABLE parcel_master ADD COLUMN IF NOT EXISTS neighborhood text;
CREATE INDEX IF NOT EXISTS parcel_master_neighborhood_idx ON parcel_master (neighborhood);
