-- Real per-parcel topography, derived from the county's 2-ft elevation model.
-- Slope decides how much of a lot you can actually build on: a steep lot needs
-- retaining walls, walk-out foundations, or simply loses buildable area. Until
-- now the only topography signal was Cincinnati's hillside overlay flag, which
-- is zero everywhere outside the city — so Blue Ash, Montgomery, Symmes and the
-- fringe parcels had no topography read at all.
--
-- avg_slope_pct    mean grade across the parcel, in percent (rise/run * 100)
-- max_slope_pct    steepest sustained grade found on the parcel
-- buildable_pct    share of the parcel at or under the buildable grade (15%)
-- buildable_sqft   lot area * buildable_pct — the practical building envelope
--                  before zoning setbacks are applied
ALTER TABLE parcel_master ADD COLUMN IF NOT EXISTS avg_slope_pct numeric;
ALTER TABLE parcel_master ADD COLUMN IF NOT EXISTS max_slope_pct numeric;
ALTER TABLE parcel_master ADD COLUMN IF NOT EXISTS buildable_pct numeric;
ALTER TABLE parcel_master ADD COLUMN IF NOT EXISTS buildable_sqft numeric;
