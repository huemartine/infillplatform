-- Per-parcel home size, for the teardown model (Oyler Hines Mode A). Sourced from
-- CAGIS "Hamilton County Building Footprints" (Open_Data_Feature_Collection/58),
-- which carries SQFT + stories for 227,527 residential buildings (100% populated).
-- A SMALL house on a valuable lot is a prime teardown, so home size sharpens the
-- land-share signal. (Year-built would help more but isn't published in bulk —
-- the field is null in the open-data layer; it lives only on the Auditor's
-- per-parcel site.)
--
-- home_sqft = estimated finished area of the main structure = footprint SQFT x
-- stories, taken as the MAX over a parcel's footprints (the primary house, not a
-- shed/garage).
ALTER TABLE parcel_master ADD COLUMN IF NOT EXISTS home_sqft numeric;

-- staging for the footprint centroids (points, not polygons — far lighter)
CREATE TABLE IF NOT EXISTS building_pts (
    id       bigserial PRIMARY KEY,
    sqft     numeric,
    stories  numeric,
    geom     geometry(Point, 4326)
);
CREATE INDEX IF NOT EXISTS building_pts_geom_idx ON building_pts USING gist (geom);
