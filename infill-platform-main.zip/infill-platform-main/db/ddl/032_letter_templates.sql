-- Uploaded LOI / GL letter templates for the bulk address-submission tab.
-- Merge fields are literal {curly} placeholders in the .docx text:
-- {owner_name} {property_address} {mailing_address} {today}. GL has a
-- built-in fallback (api/letter_template.py) when nothing's been uploaded;
-- LOI has none, so at least one LOI template must be uploaded before use.
CREATE TABLE IF NOT EXISTS letter_templates (
    id          bigserial PRIMARY KEY,
    kind        text NOT NULL CHECK (kind IN ('loi', 'gl')),
    name        text NOT NULL,
    file_path   text NOT NULL,
    uploaded_by text NOT NULL,
    is_default  boolean NOT NULL DEFAULT false,
    created_at  timestamptz DEFAULT now()
);
CREATE INDEX IF NOT EXISTS letter_templates_kind_idx ON letter_templates (kind);
