-- "Complex satellite" deeds: a parcel carrying no improvement value whose
-- same-address, same-owner sibling holds the buildings. These are the parking
-- lots, lawns, and courtyards of properties platted across several deeds —
-- they read as prime vacant land but cannot be developed independently.
-- Found by inspecting real #1-ranked leads (4045 Reading Rd, Williamsburg apts).
ALTER TABLE parcel_master ADD COLUMN IF NOT EXISTS is_satellite boolean;
CREATE INDEX IF NOT EXISTS parcel_master_satellite_idx
    ON parcel_master (is_satellite) WHERE is_satellite;
