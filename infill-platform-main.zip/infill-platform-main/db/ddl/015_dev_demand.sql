-- Demand v2: development demand from new-building permits (back-test showed
-- resale turnover is anti-correlated with actual construction). Resale columns
-- are kept as dossier context; demand_score now derives from these dev columns.
ALTER TABLE neighborhood_demand ADD COLUMN IF NOT EXISTS builds_trailing int;
ALTER TABLE neighborhood_demand ADD COLUMN IF NOT EXISTS builds_per_1k numeric;
ALTER TABLE neighborhood_demand ADD COLUMN IF NOT EXISTS builds_recent int;
ALTER TABLE neighborhood_demand ADD COLUMN IF NOT EXISTS builds_prior int;
ALTER TABLE neighborhood_demand ADD COLUMN IF NOT EXISTS dev_trajectory_pct numeric;
ALTER TABLE neighborhood_demand ADD COLUMN IF NOT EXISTS permit_covered boolean;
