-- Constraint overlays (Section 5.7): flood, hillside, historic zone polygons
-- loaded verbatim, then flags applied to parcel_master by spatial join.
-- floodway is tracked separately from general flood risk: it is the hard
-- knockout (unbuildable by regulation), while flood_flag is a soft penalty.
ALTER TABLE parcel_master ADD COLUMN IF NOT EXISTS floodway_flag boolean;

CREATE TABLE IF NOT EXISTS constraint_zones (
    id         bigserial PRIMARY KEY,
    layer      text NOT NULL,            -- fema_flood | hillside | historic
    zone       text,
    subtype    text,
    geom       geometry(MultiPolygon, 4326),
    loaded_at  timestamptz DEFAULT now()
);
CREATE INDEX IF NOT EXISTS constraint_zones_gix ON constraint_zones USING gist (geom);
CREATE INDEX IF NOT EXISTS constraint_zones_layer_idx ON constraint_zones (layer);
