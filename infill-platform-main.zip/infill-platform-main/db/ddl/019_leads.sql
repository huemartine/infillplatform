-- Lead pipeline: an agent's saved development leads moving through a diligence
-- funnel. This supersedes the flat parcel_notes model with a proper CRM: a lead
-- is added explicitly, then walked through Watchlist -> Site Visit -> Deal ->
-- Closed (with Passed as an archive for dead leads). Notes and photos are a
-- per-stage timeline, so an agent's online research, site-visit findings, and
-- deal details each live in their own section. Identity is the agent's email
-- (Cloudflare Access in prod, dev fallback locally) - private per agent.

CREATE TABLE IF NOT EXISTS leads (
    id            bigserial PRIMARY KEY,
    user_email    text NOT NULL,
    parcel_id     text NOT NULL REFERENCES parcel_master (parcel_id),
    stage         text NOT NULL DEFAULT 'watchlist',
                  -- watchlist | site_visit | deal | closed | passed
    added_score   numeric,          -- opportunity_score snapshot at add time
    -- structured deal fields, filled at the Deal / Closed stages
    offer_amount  numeric,
    offer_date    date,
    deal_terms    text,
    close_price   numeric,
    close_date    date,
    created_at    timestamptz DEFAULT now(),
    updated_at    timestamptz DEFAULT now(),
    UNIQUE (user_email, parcel_id)     -- one pipeline card per parcel per agent
);
CREATE INDEX IF NOT EXISTS leads_user_stage_idx ON leads (user_email, stage);

-- Timeline of notes + photos per lead, tagged with the funnel stage they belong
-- to. kind='note' uses body; kind='photo' stores a filesystem path + metadata
-- (body doubles as an optional caption).
CREATE TABLE IF NOT EXISTS lead_entries (
    id          bigserial PRIMARY KEY,
    lead_id     bigint NOT NULL REFERENCES leads (id) ON DELETE CASCADE,
    stage       text NOT NULL,
    kind        text NOT NULL DEFAULT 'note',   -- note | photo
    body        text,
    photo_path  text,
    photo_name  text,
    photo_mime  text,
    created_at  timestamptz DEFAULT now()
);
CREATE INDEX IF NOT EXISTS lead_entries_lead_idx ON lead_entries (lead_id, created_at);

-- ---------------------------------------------------------------------------
-- Backfill: fold existing flat parcel_notes into the pipeline so no pilot data
-- is lost. Every previously-noted parcel becomes a Watchlist lead, and each of
-- its notes becomes a Watchlist timeline entry. Idempotent: re-running skips
-- leads that already exist and only migrates notes not yet carried over.
-- ---------------------------------------------------------------------------
INSERT INTO leads (user_email, parcel_id, stage, added_score, created_at, updated_at)
SELECT n.user_email, n.parcel_id, 'watchlist',
       max(s.opportunity_score), min(n.created_at), max(n.created_at)
FROM parcel_notes n
LEFT JOIN parcel_scores s USING (parcel_id)
GROUP BY n.user_email, n.parcel_id
ON CONFLICT (user_email, parcel_id) DO NOTHING;

INSERT INTO lead_entries (lead_id, stage, kind, body, created_at)
SELECT l.id, 'watchlist', 'note', n.body, n.created_at
FROM parcel_notes n
JOIN leads l ON l.user_email = n.user_email AND l.parcel_id = n.parcel_id
WHERE NOT EXISTS (
    SELECT 1 FROM lead_entries e
    WHERE e.lead_id = l.id AND e.kind = 'note'
      AND e.body = n.body AND e.created_at = n.created_at
);
