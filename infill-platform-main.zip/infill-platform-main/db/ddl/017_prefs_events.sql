-- Per-agent preferences (home/farm region, so the app opens scoped to their
-- area instead of the whole county - which also keeps the map under its 5k cap
-- without needing MVT tiles yet) and lightweight usage instrumentation (which
-- workflows agents actually use - answers pilot learning goal L3 without asking).
CREATE TABLE IF NOT EXISTS user_prefs (
    user_email  text PRIMARY KEY,
    home_region text,
    updated_at  timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS event_log (
    id          bigserial PRIMARY KEY,
    user_email  text NOT NULL,
    event       text NOT NULL,   -- view_parcel | select_region | export | open_my_leads | session
    detail      jsonb,
    created_at  timestamptz DEFAULT now()
);
CREATE INDEX IF NOT EXISTS event_log_user_time_idx ON event_log (user_email, created_at DESC);
CREATE INDEX IF NOT EXISTS event_log_event_idx ON event_log (event);
