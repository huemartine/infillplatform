-- Phase 3b: zoning capacity gap. zoning_code/cc_zone columns exist since 001;
-- num_units (existing dwelling units, from the Auditor's NUM_UNITS) is new —
-- populated on the next CAGIS ingest, estimated from the DTE class meanwhile.
ALTER TABLE parcel_master ADD COLUMN IF NOT EXISTS num_units numeric;
CREATE INDEX IF NOT EXISTS parcel_master_zoning_code_idx ON parcel_master (zoning_code);
