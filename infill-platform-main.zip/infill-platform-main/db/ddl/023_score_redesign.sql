-- Scoring redesign (v2026.23): the opaque underutilization/capacity/assemblage
-- components are replaced by two tangible pillars an agent can read off the
-- dossier. Distress and demand are kept. The four pillars:
--   development_score      — vacant lot OR teardown (small house vs lot value)
--   owner_motivation_score — long tenure / absentee / trust / bank / CMHA / Port
--   distress_score         — tax lien / sheriff / code violations   (kept)
--   demand_score           — new-construction demand                (kept)
-- Old columns (underutilization_score, capacity_gap_score, assemblage_score)
-- are left nullable and simply stop being written.
ALTER TABLE parcel_scores ADD COLUMN IF NOT EXISTS development_score numeric;
ALTER TABLE parcel_scores ADD COLUMN IF NOT EXISTS owner_motivation_score numeric;
