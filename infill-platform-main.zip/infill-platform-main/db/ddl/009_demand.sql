-- Phase 5: neighborhood demand metrics. One row per region, recomputed with
-- each scoring pass from parcel_master sale history. The METRICS are the
-- product (shown verbatim in the dossier so a realtor draws their own
-- conclusion); demand_score is their documented weighted summary.
CREATE TABLE IF NOT EXISTS neighborhood_demand (
    neighborhood       text PRIMARY KEY,
    parcel_count       int,
    sales_24mo         int,          -- market sales (>= price floor) in last 24 months
    turnover_pct       numeric,      -- sales_24mo / parcel_count * 100
    median_price_24mo  numeric,
    median_price_prior numeric,      -- months 24-48 back
    momentum_pct       numeric,      -- median price change recent vs prior, %
    sale_to_value      numeric,      -- median(sale price / county total value), recent
    demand_score       numeric,      -- 0-100 weighted summary (formula in scoring.yaml)
    computed_at        timestamptz DEFAULT now()
);
