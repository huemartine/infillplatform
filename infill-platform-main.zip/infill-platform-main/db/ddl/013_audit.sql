-- Data-plausibility audit flags. Advisory (not score-changing): each flag warns
-- that a lead's ranking may rest on questionable data, so a realtor sees "3 data
-- flags" instead of silently trusting the number. One row per (parcel, check);
-- rebuilt each scoring pass over the scored leads.
CREATE TABLE IF NOT EXISTS parcel_audit_flag (
    id          bigserial PRIMARY KEY,
    parcel_id   text NOT NULL REFERENCES parcel_master (parcel_id),
    code        text NOT NULL,       -- bulk_sale | no_market_sale | portfolio_owner | incomplete_valuation
    severity    text NOT NULL,       -- caution | review
    detail      text,
    computed_at timestamptz DEFAULT now()
);
CREATE INDEX IF NOT EXISTS parcel_audit_flag_parcel_idx ON parcel_audit_flag (parcel_id);
CREATE INDEX IF NOT EXISTS parcel_audit_flag_code_idx ON parcel_audit_flag (code);
