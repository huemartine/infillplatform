# Post-reboot one-shot: start Docker, bring up PostGIS, apply schema, ingest live
# CAGIS, score, and show the top opportunities. Idempotent; safe to re-run.
#
#   powershell -ExecutionPolicy Bypass -File infra\bringup.ps1
#
$ErrorActionPreference = "Stop"
$repo = Split-Path $PSScriptRoot -Parent
Set-Location $repo

function Get-Docker {
    $c = (Get-Command docker -ErrorAction SilentlyContinue).Source
    if ($c) { return $c }
    $fallback = "C:\Program Files\Docker\Docker\resources\bin\docker.exe"
    if (Test-Path $fallback) { return $fallback }
    throw "docker CLI not found"
}
$docker = Get-Docker

# 1. Ensure Docker Desktop / engine is running.
Write-Output "Checking Docker engine..."
& $docker info *> $null
if ($LASTEXITCODE -ne 0) {
    Write-Output "Engine not up; launching Docker Desktop..."
    $dd = "C:\Program Files\Docker\Docker\Docker Desktop.exe"
    if (Test-Path $dd) { Start-Process $dd }
    $deadline = (Get-Date).AddMinutes(4)
    do {
        Start-Sleep -Seconds 5
        & $docker info *> $null
        $ready = $LASTEXITCODE -eq 0
        Write-Output "  waiting for engine... ($([int]((Get-Date) - $deadline).TotalSeconds * -1)s left)"
    } until ($ready -or (Get-Date) -gt $deadline)
    if (-not $ready) {
        throw "Docker engine did not start. Open Docker Desktop once and accept the service agreement, then re-run this script."
    }
}
Write-Output "Docker engine is up."

# 2. Bring up the PostGIS container (skip building the API image; we run API/ingest natively).
Write-Output "Starting PostGIS container..."
& $docker compose -f infra/docker-compose.yml up -d db
if ($LASTEXITCODE -ne 0) { throw "docker compose up db failed" }

# 3. Wait for the DB healthcheck.
Write-Output "Waiting for Postgres to accept connections..."
$deadline = (Get-Date).AddMinutes(2)
do {
    Start-Sleep -Seconds 3
    & $docker compose -f infra/docker-compose.yml exec -T db pg_isready -U infill *> $null
    $ok = $LASTEXITCODE -eq 0
} until ($ok -or (Get-Date) -gt $deadline)
if (-not $ok) { throw "Postgres did not become ready" }
Write-Output "Postgres ready."

# 4. Apply schema (idempotent; also auto-applied on first container init).
Write-Output "Applying schema..."
& $docker compose -f infra/docker-compose.yml exec -T db psql -U infill -d infill -f /docker-entrypoint-initdb.d/001_core.sql
if ($LASTEXITCODE -ne 0) { throw "schema apply failed" }

# 5. Ingest live CAGIS into parcel_master + parcel_signals.
Write-Output "Ingesting live CAGIS (this pulls real parcels; a few minutes for full county)..."
python -m ingestion.run --source cagis --limit-pages 3   # ~6k parcels for a quick first load; drop --limit-pages for full county
if ($LASTEXITCODE -ne 0) { throw "ingest failed" }

# 6. Score.
Write-Output "Scoring..."
python -m scoring.run
if ($LASTEXITCODE -ne 0) { throw "scoring failed" }

# 7. Show the result straight from the database.
Write-Output "`n=== Top 10 opportunities (from PostGIS) ==="
& $docker compose -f infra/docker-compose.yml exec -T db psql -U infill -d infill -c @"
SELECT s.parcel_id, m.address, s.opportunity_score, s.underutilization_score,
       s.distress_score, s.use_classification
FROM parcel_scores s JOIN parcel_master m USING (parcel_id)
ORDER BY s.opportunity_score DESC LIMIT 10;
"@
# 8. Start the API if nothing is listening yet.
$listening = Test-NetConnection -ComputerName 127.0.0.1 -Port 8000 -InformationLevel Quiet -WarningAction SilentlyContinue
if (-not $listening) {
    Write-Output "Starting API on http://localhost:8000 ..."
    Start-Process -WindowStyle Hidden python -ArgumentList "-m","uvicorn","api.main:app","--host","127.0.0.1","--port","8000" -WorkingDirectory $repo
} else {
    Write-Output "API already listening on :8000."
}
Write-Output "`nDone. Map: cd web; npm run dev   (http://localhost:5173) | API docs: http://localhost:8000/docs"
