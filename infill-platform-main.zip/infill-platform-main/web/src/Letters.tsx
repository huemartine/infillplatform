import { useEffect, useState } from "react";
import {
  deleteLetterTemplate, fetchLetterTemplates, generateLetters, LetterKind,
  LetterTemplate, resolveLetterAddresses, ResolvedAddress, uploadLetterTemplate,
} from "./api";

/** The bulk LOI / GL tab: paste a list of addresses, resolve each against the
 * county data, pick (or upload) a template, and download a zip of merged
 * letters — one per address. Independent of the lead pipeline: nothing here
 * needs to already be a saved lead. */
export default function Letters() {
  const [kind, setKind] = useState<LetterKind>("gl");
  const [templates, setTemplates] = useState<LetterTemplate[]>([]);
  const [templateId, setTemplateId] = useState<number | "">("");
  const [raw, setRaw] = useState("");
  const [rows, setRows] = useState<ResolvedAddress[] | null>(null);
  const [excluded, setExcluded] = useState<Set<string>>(new Set());
  const [resolving, setResolving] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [uploading, setUploading] = useState(false);

  const loadTemplates = () => void fetchLetterTemplates(kind).then(setTemplates).catch(() => {});
  useEffect(() => { loadTemplates(); setTemplateId(""); /* eslint-disable-next-line */ }, [kind]);

  const resolve = async () => {
    const lines = raw.split("\n").map((l) => l.trim()).filter(Boolean);
    if (!lines.length) return;
    setResolving(true);
    try {
      setRows(await resolveLetterAddresses(lines));
      setExcluded(new Set());
    } finally {
      setResolving(false);
    }
  };

  const toggle = (input: string) => {
    setExcluded((s) => {
      const next = new Set(s);
      if (next.has(input)) next.delete(input); else next.add(input);
      return next;
    });
  };

  const matched = (rows ?? []).filter((r) => r.parcel_id && !excluded.has(r.input));
  const unmatched = (rows ?? []).filter((r) => !r.parcel_id);

  const generate = async () => {
    if (!matched.length) return;
    setGenerating(true);
    try {
      await generateLetters(matched.map((r) => r.parcel_id!), kind, templateId || null);
    } finally {
      setGenerating(false);
    }
  };

  const upload = async (file: File) => {
    const name = prompt("Name this template (e.g. \"2026 LOI\")", file.name.replace(/\.docx$/i, ""));
    if (name == null) return;
    setUploading(true);
    try {
      const t = await uploadLetterTemplate(kind, name, file, templates.length === 0);
      setTemplates((ts) => [t, ...ts]);
      setTemplateId(t.id);
    } finally {
      setUploading(false);
    }
  };

  const removeTemplate = async (id: number) => {
    if (!confirm("Delete this template? This can't be undone.")) return;
    await deleteLetterTemplate(id);
    setTemplates((ts) => ts.filter((t) => t.id !== id));
    if (templateId === id) setTemplateId("");
  };

  return (
    <div className="letters-tab">
      <div className="letters-head">
        <div className="kind-toggle">
          <button className={kind === "loi" ? "active" : ""} onClick={() => setKind("loi")}>LOIs</button>
          <button className={kind === "gl" ? "active" : ""} onClick={() => setKind("gl")}>GLs</button>
        </div>
        <div className="muted">
          Submit addresses, pick a template, and download merged, ready-to-mail letters —
          same letters as before, just in bulk.
        </div>
      </div>

      <div className="letters-body">
        <div className="letters-col">
          <div className="section-title">1. Addresses</div>
          <label className="f-field full">
            One address per line
            <textarea rows={10} value={raw} onChange={(e) => setRaw(e.target.value)}
              placeholder={"8975 Indian Ridge Rd\n1039 E Rookwood Dr\n..."} />
          </label>
          <button className="apply-btn" onClick={() => void resolve()} disabled={resolving || !raw.trim()}>
            {resolving ? "Matching…" : "Match addresses"}
          </button>

          {rows && (
            <div className="resolve-results">
              <div className="muted" style={{ marginTop: 10 }}>
                <b>{matched.length}</b> ready{unmatched.length
                  ? ` · ${unmatched.length} not found` : ""}
              </div>
              {rows.map((r) => (
                <label key={r.input}
                  className={`resolve-row ${r.parcel_id ? "" : "unmatched"}`}>
                  {r.parcel_id ? (
                    <input type="checkbox" checked={!excluded.has(r.input)}
                      onChange={() => toggle(r.input)} />
                  ) : <span className="resolve-x">✕</span>}
                  <span>
                    <div>{r.address ?? r.input}</div>
                    {r.owner_name && <div className="muted">{r.owner_name}</div>}
                    {!r.parcel_id && <div className="muted">no county match — check spelling</div>}
                  </span>
                </label>
              ))}
            </div>
          )}
        </div>

        <div className="letters-col">
          <div className="section-title">2. Template</div>
          <div className="muted" style={{ marginBottom: 6 }}>
            Upload a .docx with merge fields: <code>{"{owner_name}"}</code> <code>{"{property_address}"}</code>{" "}
            <code>{"{mailing_address}"}</code> <code>{"{today}"}</code>.
            {kind === "gl" && " Leave none selected to use the built-in Oyler Hines letter."}
          </div>

          {kind === "loi" && templates.length === 0 && (
            <div className="f-hint">No LOI template uploaded yet — upload one below before generating.</div>
          )}

          <div className="template-list">
            <label className={`template-row ${templateId === "" ? "picked" : ""}`}>
              <input type="radio" name="tpl" checked={templateId === ""}
                onChange={() => setTemplateId("")} disabled={kind === "loi"} />
              {kind === "gl" ? "Built-in Oyler Hines letter" : "— none —"}
            </label>
            {templates.map((t) => (
              <label key={t.id} className={`template-row ${templateId === t.id ? "picked" : ""}`}>
                <input type="radio" name="tpl" checked={templateId === t.id}
                  onChange={() => setTemplateId(t.id)} />
                {t.name}{t.is_default ? <span className="muted"> · default</span> : ""}
                <button type="button" className="ghost-btn danger tpl-del"
                  onClick={(e) => { e.preventDefault(); void removeTemplate(t.id); }}>×</button>
              </label>
            ))}
          </div>

          <label className="ghost-btn upload-tpl">
            {uploading ? "Uploading…" : `＋ Upload a ${kind.toUpperCase()} template (.docx)`}
            <input type="file" accept=".docx" hidden disabled={uploading}
              onChange={(e) => { const f = e.target.files?.[0]; if (f) void upload(f); e.target.value = ""; }} />
          </label>

          <div className="section-title" style={{ marginTop: 18 }}>3. Generate</div>
          <button className="apply-btn" disabled={!matched.length || generating
              || (kind === "loi" && templateId === "")}
            onClick={() => void generate()}>
            {generating ? "Generating…" : `Download ${matched.length || ""} ${kind.toUpperCase()} letter${matched.length === 1 ? "" : "s"}`}
          </button>
        </div>
      </div>
    </div>
  );
}
