# Infill & Development Land Discovery Platform

Scores every parcel in **Hamilton County, OH** for development opportunity and exposes
the result as a filterable map + API. Answers one question at scale:

> *Which parcels could profitably be built that aren't being built today — and where?*

Architecture is a **modular monolith** (Python 3.12) over **PostgreSQL 16 + PostGIS 3**,
with an immutable **S3** raw archive, a **dbt + Python** scoring engine, a **FastAPI**
layer, and a **React + MapLibre** explorer. See [`docs/architecture.md`](docs/architecture.md).

## Universal join key

Every dataset reconciles to the Hamilton County **Property Number** (`parcel_id`).
Address matching is a fallback only. Raw extracts are archived to S3 verbatim
(timestamped) before any transformation, so every score is reproducible from raw.

## Layout

```
infill-platform/
├── ingestion/        # one extractor module per source (arcgis, socrata, regrid, scraper...)
│   ├── base.py       # Extractor protocol + Resource/IngestRun contracts
│   ├── common.py     # shared HTTP client: retry, rate-limit, pagination, normalizers
│   ├── registry.py   # source catalog: id, type, schedule, endpoint resolver
│   └── extractors/   # cagis.py, auditor.py, socrata.py, ...
├── dbt/              # staging (cleaned source views) → intermediate → marts
├── scoring/          # use-classification + opportunity scoring
│   └── config/scoring.yaml   # versioned thresholds + weights (Appendix C)
├── db/ddl/           # canonical schema (parcel_master, parcel_signals, parcel_scores)
├── api/              # FastAPI app
├── orchestration/    # Prefect flows on cadences
├── web/              # React + MapLibre explorer
├── infra/            # Terraform + docker-compose
└── docs/
```

## Quick start (local dev)

```bash
cp .env.example .env            # fill in tokens; defaults work for local docker
powershell -File infra/bringup.ps1   # docker up + schema + live ingest + score (one-shot)
uvicorn api.main:app --port 8000     # API at http://localhost:8000/docs
cd web && npm install && npm run dev # map at http://localhost:5173
```

Or piecewise: `make up` / `make migrate` / `make ingest SOURCE=cagis` / `make score`.

## Setting up as a new contributor

Prerequisites: **Docker Desktop**, **Python 3.12**, **Node 18+**. On Windows run
`infra/bringup.ps1`; on macOS/Linux use the `make` targets, which do the same work.

```bash
cp .env.example .env     # defaults are correct for a local docker stack
make up && make migrate  # PostGIS container + schema
make ingest SOURCE=cagis # ~420k parcels from the county's public API
make score               # build the derived tables and score every parcel
make test                # should be all green before you change anything
```

**You do not need any credentials from the project owner.** Every feed is a
public endpoint — the county's CAGIS ArcGIS services, Cincinnati's Socrata
datasets, and the sheriff-sale site — so the whole database rebuilds from
scratch. The full ingest takes a while (it is paging hundreds of thousands of
parcels); leave it running. `SOCRATA_APP_TOKEN` is optional and only raises rate
limits.

Two settings worth knowing before you run it:

- **`DEV_AUTH=true`** — required for local work. Identity normally comes from the
  `Cf-Access-Authenticated-User-Email` header that Cloudflare Access injects in
  production; `DEV_AUTH` accepts an `X-User-Email` header (or falls back to
  `DEV_USER_EMAIL`) instead. It defaults to **false** so an unconfigured deploy
  returns 401 rather than signing every visitor in as one shared user — never set
  it on anything reachable from the internet. See `api/main.py: current_user`.
- **`GOOGLE_MAPS_KEY`** — optional. Without it the dossier still deep-links to
  Street View and aerial imagery; with it, the curb-view image renders inline.

Where things live: `ingestion/` pulls and resolves sources onto the Auditor
parcel id, `scoring/` turns that into the opportunity score (read
`scoring/config/scoring.yaml` first — the weights and thresholds are all there),
`api/` serves it, `web/` is the React/MapLibre client. `docs/architecture.md` and
`docs/system-overview.md` are the orientation reads.

A caution learned the hard way: most of the scoring rules exist because a real
agent looked at a lead and said it was wrong (a Kroger parking lot, a coffee
shop, a food-truck lot). The tests encode those calls — if one starts failing,
that is a signal you have reintroduced a false-positive class, not that the test
is stale.

The map explorer (React + MapLibre) colors parcels by opportunity score, filters
by minimum score, and opens a per-parcel dossier (score components, ownership,
valuation, distress signals) on click. In dev, Vite proxies `/api` to FastAPI.

## Starting from a database dump

Rebuilding from the public feeds takes hours. If you were handed an `infill_*.dump`
alongside the repo, restore it instead and you are running in minutes:

```bash
cp .env.example .env
echo "DEV_AUTH=true" >> .env       # required for local work; see the section above
./ops/restore_dump.sh ~/Downloads/infill_YYYYMMDD.dump
uvicorn api.main:app --port 8000
cd web && npm install && npm run dev      # http://localhost:5173
```

The script drops and recreates an empty `infill` database before restoring,
because the container's first boot already applies `db/ddl` and layering a dump
on a populated schema produces a half-merged database. It prints parcel and
score counts at the end so you can confirm the restore landed.

**On Apple Silicon**, `postgis/postgis` publishes amd64 images only, so it runs
under emulation and Compose may refuse it outright. Use the arm64-native build of
the same PostgreSQL 16 + PostGIS 3.4 instead:

```bash
export POSTGIS_IMAGE=imresamu/postgis:16-3.4
```

Put that in your shell profile, or prefix the `make up` / restore commands with
it. The dump is version-matched to PostgreSQL 16.4 and PostGIS 3.4.3, so it
restores into either image.

**What the dump contains:** the full county dataset plus everything derived from
it, and also the team's own working data - saved leads, pipeline stages, notes
and outreach history. Treat it as confidential business data, not a public
dataset. If you only need the parcels and scores, re-ingesting from the public
feeds (the section above) gives you those without any of it.

## Build status

Feature-complete for the design-partner pilot; **160 tests** green. All five
scoring components are live, back-tested (AUC ≈ 0.887, 2.69× discovery lift on a
temporal holdout) and hardened through ~24 diligence-driven revisions. Also
built: the lead pipeline / CRM funnel, printed + digital outreach with QR
response tracking, Excel export, multi-parcel assembly finder, and plain-English
zoning rules transcribed from four official municipal codes.

Deployment is the open item — see [`docs/pilot-plan.md`](docs/pilot-plan.md)
§11. Longer history in [`docs/roadmap.md`](docs/roadmap.md).
