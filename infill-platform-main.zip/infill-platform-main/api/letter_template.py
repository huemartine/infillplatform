"""The Oyler Hines general outreach letter (from the team's real template).

The layout engine (`api/outreach.py`) depends only on the merge-field names, so
editing the prose below is all it takes to change the letter. Merge fields
(Python str.format): {owner_name} {property_address}. The QR next to Bill's bio is
added by the renderer and points at settings.outreach_link_url.
"""

SENDER = {
    "team": "Oyler Hines of Coldwell Banker Realty",
    "signer": "Bill Hines",
    "title": "Director of Land Acquisition",
    "phone": "513-313-7749",
    "email": "bill@oylerhines.com",
    "website": "www.oylerhines.com",
    "address": "7813 Ted Gregory Lane, Cincinnati, OH 45242",
}

GREETING = "Hi {owner_name},"

# paragraphs before the bulleted options
BODY_BEFORE = [
    "I hope this message finds you well! My name is Bill Hines with Oyler Hines, a real "
    "estate team with Coldwell Banker Realty. You may have seen some of our signs in your "
    "neighbors' yards over the years, as we specialize in your neighborhood and have been on "
    "the buy &amp; sell side of dozens of transactions right around your property.",
    "Today, I am reaching out because we noticed your home located at {property_address}, and "
    "wondered if you have considered selling? We represent a variety of buyers, top builders "
    "and developers in the area looking for new properties. We don't want to be presumptuous "
    "and say that your home would only be a good building candidate for a new home, so we "
    "wanted to offer a few options for you.",
]

BULLETS = [
    "As-Is, Quick Sale Offer (for New Home or Rehab) — for a potential purchase by a new "
    "home buyer, builder or developer",
    "Valuation as an Existing Home Sale by our Resale Team",
    "Discuss any renovation opportunities and the Coldwell Banker RealVitalize Program",
]

# paragraphs after the bullets
BODY_AFTER = [
    "Given our team's scope and resources, we are uniquely qualified to look at your property "
    "in a variety of ways to give you options. That said, would you be open to having a "
    "discussion? We'd welcome a chance to come by and introduce ourselves.",
    "To learn more about us and our programs, please visit www.oylerhines.com/sell-as-is.",
    "Thanks for your time and I look forward to connecting!",
]

# small print at the foot of the letter
DISCLOSURES = [
    "Wire Fraud is Real. Before wiring any money, call the intended recipient at a number you "
    "know is valid to confirm the instructions. Additionally, please note that the sender does "
    "not have authority to bind a party to a real estate contract via written or verbal "
    "communication.",
    "Disclosure: The above is a nonbinding letter of intent. We welcome a chance to discuss a "
    "legally binding written agreement to be signed by both parties. If your property is listed "
    "with a real estate broker, please disregard or forward this letter of intent to your "
    "agent. It is not our intention to solicit the offerings marketed by another real estate "
    "broker. We would be happy to work cooperatively with your broker/agent.",
    "Oyler &amp; Hines Real Estate LLC. ©2023 Coldwell Banker. All Rights Reserved. Coldwell "
    "Banker and the Coldwell Banker logos are trademarks of Coldwell Banker Real Estate LLC. "
    "The Coldwell Banker® System is comprised of company owned offices which are owned by a "
    "subsidiary of Realogy Brokerage Group LLC and franchised offices which are independently "
    "owned and operated. The Coldwell Banker System fully supports the principles of the Fair "
    "Housing Act and the Equal Opportunity Act.",
]
