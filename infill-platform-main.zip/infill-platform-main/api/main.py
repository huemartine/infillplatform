"""FastAPI layer (Section 10). JSON REST, OpenAPI auto-documented, auth-gated.
Phase-1 wires the ranked search, parcel dossier, and coverage/health endpoints to
PostGIS. Heavy map data goes through MVT tiles (/tiles), not /parcels, to keep
payloads small. Endpoints degrade gracefully (503) when the DB isn't reachable.
"""
from __future__ import annotations

from typing import Optional

from fastapi import Depends, FastAPI, File, Form, HTTPException, Query, Request, UploadFile
from fastapi.responses import FileResponse
from pydantic import BaseModel

app = FastAPI(
    title="Infill & Development Land Discovery Platform",
    version="0.1.0",
    summary="Parcel-level development opportunity scoring for Hamilton County, OH.",
)

# lazy engine so importing the app (docs, tests) never requires a live DB
_engine = None


def _db():
    global _engine
    from sqlalchemy import create_engine

    from config import settings
    if _engine is None:
        _engine = create_engine(settings.database_url, future=True, pool_pre_ping=True)
    return _engine


def _query(sql: str, params: dict) -> list[dict]:
    from sqlalchemy import text
    from sqlalchemy.exc import SQLAlchemyError
    try:
        with _db().connect() as conn:
            return [dict(r) for r in conn.execute(text(sql), params).mappings()]
    except SQLAlchemyError as e:
        raise HTTPException(status_code=503, detail=f"database unavailable: {e.__class__.__name__}")


def _execute(sql: str, params: dict) -> list[dict]:
    """Write query inside a transaction; returns RETURNING rows if any."""
    from sqlalchemy import text
    from sqlalchemy.exc import SQLAlchemyError
    try:
        with _db().begin() as conn:
            res = conn.execute(text(sql), params)
            return [dict(r) for r in res.mappings()] if res.returns_rows else []
    except SQLAlchemyError as e:
        raise HTTPException(status_code=503, detail=f"database unavailable: {e.__class__.__name__}")


def current_user(request: Request) -> str:
    """The signed-in agent's email.

    Cloudflare Access injects Cf-Access-Authenticated-User-Email after it has
    authenticated the visitor against the allow-list, and that is the ONLY header
    trusted by default. X-User-Email and the dev identity are both forgeable by
    anyone who can reach the API — a visitor could read and write any agent's
    leads, notes and photos by naming them — so they are honoured only when
    DEV_AUTH is explicitly on.

    With DEV_AUTH off and no Access header this raises 401 rather than inventing
    an identity: an unprotected deployment must fail closed.

    NOTE: trusting the header assumes nothing can reach the API except through
    Access. That holds behind a Cloudflare Tunnel (the origin has no public
    inbound port). If the API is ever exposed directly, verify the signed
    Cf-Access-Jwt-Assertion JWT instead of trusting the email header.
    """
    from config import settings
    email = request.headers.get("cf-access-authenticated-user-email")
    if email:
        return email
    if settings.dev_auth:
        return request.headers.get("x-user-email") or settings.dev_user_email
    raise HTTPException(status_code=401, detail="not authenticated")


@app.get("/me")
def me(request: Request) -> dict:
    """Who the API thinks you are (drives the 'My Leads' view)."""
    return {"email": current_user(request)}


class PrefsIn(BaseModel):
    home_region: Optional[str] = None


@app.get("/prefs")
def get_prefs(request: Request) -> dict:
    """The agent's saved preferences - notably their home/farm region, which the
    app opens into so they land in their working area, not the whole county."""
    rows = _query("SELECT home_region FROM user_prefs WHERE user_email = :u",
                  {"u": current_user(request)})
    return {"home_region": rows[0]["home_region"] if rows else None}


@app.put("/prefs")
def put_prefs(prefs: PrefsIn, request: Request) -> dict:
    _execute("""
        INSERT INTO user_prefs (user_email, home_region, updated_at)
        VALUES (:u, :r, now())
        ON CONFLICT (user_email) DO UPDATE SET home_region = EXCLUDED.home_region,
                                               updated_at = now()
    """, {"u": current_user(request), "r": prefs.home_region})
    return {"home_region": prefs.home_region}


class EventIn(BaseModel):
    event: str
    detail: Optional[dict] = None


@app.post("/events", status_code=204)
def log_event(ev: EventIn, request: Request) -> None:
    """Fire-and-forget usage instrumentation. Never fails the caller."""
    import json
    try:
        _execute("""
            INSERT INTO event_log (user_email, event, detail)
            VALUES (:u, :e, CAST(:d AS jsonb))
        """, {"u": current_user(request), "e": ev.event[:40],
              "d": json.dumps(ev.detail or {})})
    except HTTPException:
        pass  # instrumentation must never break the app


@app.get("/stats")
def stats() -> dict:
    """Coverage / health: parcel counts, scored share, per-source freshness,
    score distribution. Backs the frontend health dashboard."""
    rows = _query("""
        SELECT
            (SELECT count(*) FROM parcel_master)                        AS parcels,
            (SELECT count(*) FROM parcel_scores)                        AS scored,
            (SELECT count(*) FROM parcel_signals)                       AS signals,
            (SELECT round(avg(opportunity_score), 2) FROM parcel_scores) AS avg_score,
            (SELECT max(scored_at) FROM parcel_scores)                  AS last_scored
    """, {})
    return rows[0] if rows else {}


@app.get("/health")
def health() -> dict:
    """Per-feed data freshness. Surfaced in the UI so an agent never acts on a
    sheriff-sale date that has already passed without knowing the feed is
    stale — silent staleness is the fastest way to lose their trust."""
    from orchestration.freshness import summary
    try:
        return summary()
    except Exception as exc:
        return {"status": "unknown", "stale": [], "sources": [], "error": str(exc)}


# Owner-class patterns for the team's acquisition-source filters (grounded in the
# real owner_name_raw values). Curated to hit lenders/authorities, not surnames
# (e.g. "\yBANK\y" would catch "BANK DANNY W"; these require institution markers).
_BANK_RE = (r"(BANK (OF|ONE|NA|CO|COMPANY|USA)|SAVINGS BANK|NATIONAL ASSOCIATION|"
            r"\yFSB\y| NA$|FANNIE MAE|FREDDIE MAC|FEDERAL (NATIONAL|HOME LOAN)|"
            r"MORTGAGE (CO|CORP|LLC|INC|ASSN|SERVICING)|FIFTH THIRD|US BANK|U S BANK|"
            r"WELLS FARGO|HUNTINGTON|PNC BANK|JPMORGAN|CHASE|KEYBANK|CITIZENS BANK|"
            r"SECRETARY OF (HOUSING|VETERAN))")
_CMHA_RE = r"(METROPOLIT\w* HOUSING|HOUSING AUTHORITY|\yCMHA\y)"
_PORT_RE = r"(PORT OF GREATER|PORT AUTHORITY|GREATER CINCINNATI.*PORT)"

# Parcel classes the filter view always hides — even with scoring off — because
# they aren't a normal, independently-acquirable lot. Read off the stored scoring
# constraints so the exclusion holds whether or not the score is being shown.
_HIDDEN_CLASSES = ["not_acquirable", "regulatory_floodway", "condo_unit",
                   "complex_satellite", "commercial_land", "operating_amenity"]

# Realtor land-use buckets -> Ohio DTE class-code ranges (inclusive). Kept coarse
# and readable; a realtor thinks "single-family / 2-4 family / vacant", not "510".
_LAND_USE_RANGES = {
    "vacant": [(300, 300), (400, 400), (500, 500)],
    "single_family": [(510, 519)],
    "two_to_four_family": [(520, 549)],
    "multifamily": [(401, 403), (550, 599)],
    "commercial": [(404, 499)],
}

# Whitelisted sort fields -> SQL expression. The realtor sorts the filtered list
# by any of these; the frontend picks "opportunity_score" only when scoring is on.
_SORT_EXPR = {
    "opportunity_score": "s.opportunity_score",
    "distress_score": "s.distress_score",
    "land_value": "m.land_value",
    "building_value": "m.improvement_value",
    "total_value": "(COALESCE(m.land_value,0)+COALESCE(m.improvement_value,0))",
    "lot_sqft": "m.area_sqft",
    "home_sqft": "m.home_sqft",
    "land_share": "(m.land_value / NULLIF(COALESCE(m.land_value,0)+COALESCE(m.improvement_value,0),0))",
    "last_sale_date": "m.last_sale_date",
    "last_sale_price": "m.last_sale_price",
    "years_owned": "(CURRENT_DATE - m.last_sale_date)",
    "condition_gap": "m.condition_gap",
    "address": "m.address",
}

# integer land-use class parsed from the (text) code, guarding non-numeric codes
_LU_CODE = "NULLIF(regexp_replace(m.land_use_code,'[^0-9]','','g'),'')::int"


def _land_use_clause(cat: str) -> Optional[str]:
    """A land-use bucket -> a numeric class-range predicate. Ranges come from a
    trusted constant (never user input), so inlining the bounds is injection-safe."""
    ranges = _LAND_USE_RANGES.get(cat)
    if not ranges:
        return None
    ors = " OR ".join(f"{_LU_CODE} BETWEEN {lo} AND {hi}" for lo, hi in ranges)
    return f"({ors})"


def _sig_exists(sig: str) -> str:
    """A parcel-has-this-signal predicate (sig is a trusted constant)."""
    return ("EXISTS (SELECT 1 FROM parcel_signals ps WHERE ps.parcel_id = m.parcel_id "
            f"AND ps.signal_type = '{sig}')")


def _land_use_label(code) -> str:
    """Realtor-readable property type from the Ohio DTE class code."""
    import re
    digits = re.sub(r"\D", "", str(code or ""))
    if not digits:
        return ""
    n = int(digits)
    if n in (300, 400, 500):
        return "Vacant land"
    if 510 <= n <= 519:
        return "Single-family"
    if 520 <= n <= 549:
        return "2-4 family"
    if (401 <= n <= 403) or (550 <= n <= 599):
        return "Multifamily"
    if 300 <= n <= 399:
        return "Industrial"
    if 404 <= n <= 499:
        return "Commercial"
    return ""


def _lead_filters(f: dict):
    """Shared WHERE builder for /parcels, /geojson, and /export — one filter
    vocabulary everywhere.

    Filter-first: the score is an OPTIONAL overlay, not a gate. Every filter reads
    the raw county record (owner, value, size, distress, buildability...), so a
    realtor browses EVERY matching lot regardless of its ranking; a min_score is
    only applied when the caller asks for one (scoring toggled on). Parcels that
    aren't a normal, acquirable lot (public/exempt, condo, satellite, land-dominant
    commercial, floodway, amenity) are always hidden via the stored constraints."""
    where: list[str] = ["m.geom IS NOT NULL"]
    params: dict = {}
    if not f.get("include_hidden"):
        where.append("NOT COALESCE(jsonb_exists_any(s.constraints->'active', "
                     "CAST(:hidden AS text[])), false)")
        params["hidden"] = _HIDDEN_CLASSES
    if f.get("min_score") is not None and not f.get("show_all"):
        where.append("s.opportunity_score >= :min_score"); params["min_score"] = f["min_score"]
    if f.get("use_class"):
        where.append("s.use_classification = :use_class"); params["use_class"] = f["use_class"]

    # --- region (defaults to the team's target markets) ---
    if f.get("neighborhood"):
        where.append("m.neighborhood = :neighborhood"); params["neighborhood"] = f["neighborhood"]
    else:
        from config import settings
        where.append("m.neighborhood = ANY(:targets)")
        params["targets"] = list(settings.target_regions)

    # --- property type & size ---
    if f.get("land_use"):
        clause = _land_use_clause(f["land_use"])
        if clause:
            where.append(clause)
    if f.get("is_vacant") is not None:
        where.append("m.has_structure = :has_struct"); params["has_struct"] = not f["is_vacant"]
    if f.get("min_lot_sqft") is not None:
        where.append("m.area_sqft >= :min_sq"); params["min_sq"] = f["min_lot_sqft"]
    if f.get("max_lot_sqft") is not None:
        where.append("m.area_sqft <= :max_sq"); params["max_sq"] = f["max_lot_sqft"]
    if f.get("min_home_sqft") is not None:
        where.append("m.home_sqft >= :min_hs"); params["min_hs"] = f["min_home_sqft"]
    if f.get("max_home_sqft") is not None:
        where.append("m.home_sqft <= :max_hs"); params["max_hs"] = f["max_home_sqft"]
    if f.get("zoning"):
        where.append("m.zoning_code ILIKE :zoning"); params["zoning"] = f"%{f['zoning']}%"
    if f.get("min_units") is not None:
        where.append("m.num_units >= :min_u"); params["min_u"] = f["min_units"]
    if f.get("max_units") is not None:
        where.append("m.num_units <= :max_u"); params["max_u"] = f["max_units"]

    # --- value (all $ ranges; land_share is a percentage of total value) ---
    if f.get("min_land_value") is not None:
        where.append("m.land_value >= :min_lv"); params["min_lv"] = f["min_land_value"]
    if f.get("max_land_value") is not None:
        where.append("m.land_value <= :max_lv"); params["max_lv"] = f["max_land_value"]
    if f.get("min_building_value") is not None:
        where.append("m.improvement_value >= :min_bv"); params["min_bv"] = f["min_building_value"]
    if f.get("max_building_value") is not None:
        where.append("m.improvement_value <= :max_bv"); params["max_bv"] = f["max_building_value"]
    if f.get("min_total_value") is not None:
        where.append("(COALESCE(m.land_value,0)+COALESCE(m.improvement_value,0)) >= :min_tv")
        params["min_tv"] = f["min_total_value"]
    if f.get("max_total_value") is not None:
        where.append("(COALESCE(m.land_value,0)+COALESCE(m.improvement_value,0)) <= :max_tv")
        params["max_tv"] = f["max_total_value"]
    _ls = "m.land_value / NULLIF(COALESCE(m.land_value,0)+COALESCE(m.improvement_value,0),0)"
    if f.get("min_land_share") is not None:
        where.append(f"{_ls} >= :min_ls"); params["min_ls"] = f["min_land_share"] / 100.0
    if f.get("max_land_share") is not None:
        where.append(f"{_ls} <= :max_ls"); params["max_ls"] = f["max_land_share"] / 100.0
    if f.get("min_sale_price") is not None:
        where.append("m.last_sale_price >= :min_sp"); params["min_sp"] = f["min_sale_price"]
    if f.get("max_sale_price") is not None:
        where.append("m.last_sale_price <= :max_sp"); params["max_sp"] = f["max_sale_price"]
    # "diamond in the rough": a house whose building value/sqft is far below its
    # block (condition_gap), folded with the local area's value (area_land_value)
    # so it's a run-down house in a GREAT area, not the worst house on a cheap one
    if f.get("min_condition_gap") is not None:
        where.append("m.condition_gap >= :min_cg"); params["min_cg"] = f["min_condition_gap"]
    if f.get("min_area_value") is not None:
        where.append("m.area_land_value >= :min_av"); params["min_av"] = f["min_area_value"]

    # --- ownership & motivation ---
    if f.get("owner_type"):
        where.append("m.owner_type = :owner_type"); params["owner_type"] = f["owner_type"]
    if f.get("owner_name"):
        where.append("m.owner_name_raw ILIKE :owner_name"); params["owner_name"] = f"%{f['owner_name']}%"
    if f.get("absentee") is not None:
        where.append("m.is_absentee = :absentee"); params["absentee"] = f["absentee"]
    if f.get("out_of_state"):
        # owner mailing address is out of Ohio (the state token sits before the zip)
        where.append("m.owner_mailing_addr ~ ' [A-Z]{2} [0-9]{5}' "
                     "AND substring(m.owner_mailing_addr from ' ([A-Z]{2}) [0-9]{5}') <> 'OH'")
    if f.get("homestead"):
        # Ohio Homestead Exemption -> owner is 65+ or permanently disabled
        where.append("m.homestead = true")
    if f.get("owned_years_min"):
        # long-held: owned by the same party for N+ years (motivated / low-basis).
        # NULL sale dates can't be judged, so they don't match.
        where.append("m.last_sale_date IS NOT NULL "
                     "AND m.last_sale_date <= CURRENT_DATE - make_interval(years => :oy)")
        params["oy"] = int(f["owned_years_min"])
    if f.get("transferred_since"):
        # recently transferred (e.g. recently deeded into a trust). Exclude the
        # corrupted future sale dates so they don't masquerade as 'recent'.
        where.append("m.last_sale_date >= CAST(:tsince AS date) "
                     "AND m.last_sale_date <= CURRENT_DATE")
        params["tsince"] = f["transferred_since"]
    if f.get("bank_owned"):
        where.append("m.owner_name_raw ~* :bank_re"); params["bank_re"] = _BANK_RE
    if f.get("cmha_owned"):
        where.append("m.owner_name_raw ~* :cmha_re"); params["cmha_re"] = _CMHA_RE
    if f.get("port_owned"):
        where.append("m.owner_name_raw ~* :port_re"); params["port_re"] = _PORT_RE

    # --- distress & activity ---
    if f.get("has_tax_lien"):
        where.append(_sig_exists("tax_delinquent"))
    if f.get("has_code_violation"):
        where.append(_sig_exists("code_violation"))
    if f.get("landbank"):
        where.append(_sig_exists("landbank_inventory"))
    if f.get("has_distress"):
        where.append("EXISTS (SELECT 1 FROM parcel_signals ps WHERE ps.parcel_id = m.parcel_id "
                     "AND ps.signal_type IN ('tax_delinquent','sheriff_sale','code_violation'))")
    if f.get("has_sheriff_sale"):
        where.append("EXISTS (SELECT 1 FROM parcel_signals ps WHERE ps.parcel_id = m.parcel_id "
                     "AND ps.signal_type = 'sheriff_sale' AND ps.event_date >= CURRENT_DATE)")

    # --- utilities / infrastructure ---
    # sewer_status: 'sewer' = not in the septic inventory (public sewer likely),
    # 'septic' = a known private system, so no sanitary sewer at the property
    if f.get("sewer_status") == "septic":
        where.append("m.on_septic = true")
    elif f.get("sewer_status") == "sewer":
        where.append("COALESCE(m.on_septic, false) = false")
    if f.get("max_slope_pct") is not None:
        where.append("m.avg_slope_pct <= :max_slope"); params["max_slope"] = f["max_slope_pct"]
    if f.get("min_buildable_sqft") is not None:
        where.append("m.buildable_sqft >= :min_bld"); params["min_bld"] = f["min_buildable_sqft"]
    if f.get("max_water_ft") is not None:
        where.append("m.water_main_ft <= :max_wft"); params["max_wft"] = f["max_water_ft"]

    # --- buildability excludes ---
    if f.get("exclude_flood"):
        where.append("COALESCE(m.flood_flag,false) = false")
    if f.get("exclude_slope"):
        where.append("COALESCE(m.slope_flag,false) = false")
    if f.get("exclude_historic"):
        where.append("COALESCE(m.historic_flag,false) = false")
    if f.get("exclude_cso"):
        where.append("COALESCE(m.cso_flag,false) = false")
    if f.get("exclude_recent_permit"):
        where.append("NOT EXISTS (SELECT 1 FROM development_permits dp "
                     "WHERE dp.parcel_id = m.parcel_id "
                     "AND dp.issued_date >= now() - interval '24 months')")
    return where, params


def lead_filter_params(
    # scoring overlay (optional — the score is no longer a gate)
    min_score: Optional[float] = Query(None, ge=0, le=100),
    show_all: bool = False,
    use_class: Optional[str] = None,
    include_hidden: bool = False,               # show even not-acquirable/junk lots
    neighborhood: Optional[str] = None,
    # property type & size
    land_use: Optional[str] = None,             # vacant / single_family / ...
    is_vacant: Optional[bool] = None,
    min_lot_sqft: Optional[float] = None,
    max_lot_sqft: Optional[float] = None,
    min_home_sqft: Optional[float] = None,
    max_home_sqft: Optional[float] = None,
    zoning: Optional[str] = None,
    min_units: Optional[float] = None,
    max_units: Optional[float] = None,
    # value
    min_land_value: Optional[float] = None,
    max_land_value: Optional[float] = None,
    min_building_value: Optional[float] = None,
    max_building_value: Optional[float] = None,
    min_total_value: Optional[float] = None,
    max_total_value: Optional[float] = None,
    min_land_share: Optional[float] = Query(None, ge=0, le=100),  # % of total value
    max_land_share: Optional[float] = Query(None, ge=0, le=100),
    min_sale_price: Optional[float] = None,
    max_sale_price: Optional[float] = None,
    min_condition_gap: Optional[float] = Query(None, ge=0, le=100),  # worse than its block
    min_area_value: Optional[float] = None,                          # area-value fold
    # ownership & motivation
    owner_type: Optional[str] = None,
    owner_name: Optional[str] = None,
    absentee: Optional[bool] = None,
    out_of_state: Optional[bool] = None,        # owner mailing address not in Ohio
    homestead: Optional[bool] = None,           # owner 65+ / disabled (homestead exemption)
    owned_years_min: Optional[int] = Query(None, ge=1, le=120),  # long-held (e.g. 30+)
    transferred_since: Optional[str] = None,    # ISO date; recently-transferred cutoff
    bank_owned: Optional[bool] = None,          # REO / lender-owned
    cmha_owned: Optional[bool] = None,          # Cincinnati Metro Housing Authority
    port_owned: Optional[bool] = None,          # Port of Greater Cincinnati
    # distress & activity
    has_tax_lien: Optional[bool] = None,
    has_code_violation: Optional[bool] = None,
    landbank: Optional[bool] = None,            # in a land-bank / Port inventory
    has_distress: Optional[bool] = None,
    has_sheriff_sale: Optional[bool] = None,
    # utilities / infrastructure
    sewer_status: Optional[str] = None,         # sewer | septic
    max_water_ft: Optional[float] = None,       # feet to nearest hydrant (water main proxy)
    max_slope_pct: Optional[float] = None,      # average grade ceiling (topography)
    min_buildable_sqft: Optional[float] = None, # usable (sub-15%-grade) area floor
    # buildability excludes
    exclude_flood: Optional[bool] = None,
    exclude_slope: Optional[bool] = None,
    exclude_historic: Optional[bool] = None,
    exclude_cso: Optional[bool] = None,
    exclude_recent_permit: Optional[bool] = None,
) -> dict:
    """One declaration of the realtor filter vocabulary, shared across the list,
    the map, and the export via Depends — so every surface filters identically.
    Only exact-data filters (no proxies); mortgage/lien/reverse-mortgage specifics
    await a future county-Recorder feed."""
    return {
        "min_score": min_score, "show_all": show_all, "use_class": use_class,
        "include_hidden": include_hidden, "neighborhood": neighborhood,
        "land_use": land_use, "is_vacant": is_vacant,
        "min_lot_sqft": min_lot_sqft, "max_lot_sqft": max_lot_sqft,
        "min_home_sqft": min_home_sqft, "max_home_sqft": max_home_sqft,
        "zoning": zoning, "min_units": min_units, "max_units": max_units,
        "min_land_value": min_land_value, "max_land_value": max_land_value,
        "min_building_value": min_building_value, "max_building_value": max_building_value,
        "min_total_value": min_total_value, "max_total_value": max_total_value,
        "min_land_share": min_land_share, "max_land_share": max_land_share,
        "min_sale_price": min_sale_price, "max_sale_price": max_sale_price,
        "min_condition_gap": min_condition_gap, "min_area_value": min_area_value,
        "owner_type": owner_type, "owner_name": owner_name, "absentee": absentee,
        "out_of_state": out_of_state, "homestead": homestead,
        "owned_years_min": owned_years_min,
        "transferred_since": transferred_since, "bank_owned": bank_owned,
        "cmha_owned": cmha_owned, "port_owned": port_owned,
        "has_tax_lien": has_tax_lien, "has_code_violation": has_code_violation,
        "landbank": landbank, "has_distress": has_distress,
        "has_sheriff_sale": has_sheriff_sale,
        "sewer_status": sewer_status, "max_water_ft": max_water_ft,
        "max_slope_pct": max_slope_pct, "min_buildable_sqft": min_buildable_sqft,
        "exclude_flood": exclude_flood, "exclude_slope": exclude_slope,
        "exclude_historic": exclude_historic, "exclude_cso": exclude_cso,
        "exclude_recent_permit": exclude_recent_permit,
    }


@app.get("/neighborhoods")
def neighborhoods(min_score: float = Query(50, ge=0, le=100)) -> dict:
    """Region picker: the team's TARGET markets with their lead counts and best
    score, ranked by opportunity. Scoped to target regions so the picker stays
    focused (7 markets, not 86)."""
    from config import settings
    rows = _query("""
        SELECT m.neighborhood,
               count(*) FILTER (WHERE s.opportunity_score >= :ms) AS leads,
               round(max(s.opportunity_score), 1) AS best_score,
               round(avg(s.opportunity_score) FILTER (WHERE s.opportunity_score > 0), 1) AS avg_score
        FROM parcel_master m JOIN parcel_scores s USING (parcel_id)
        WHERE m.neighborhood = ANY(:targets)
        GROUP BY m.neighborhood
        ORDER BY leads DESC
    """, {"ms": min_score, "targets": list(settings.target_regions)})
    return {"count": len(rows), "min_score": min_score, "neighborhoods": rows}


@app.get("/neighborhoods/bounds")
def neighborhood_bounds(name: Optional[str] = None) -> dict:
    """Bounding box [w,s,e,n] of a neighborhood's parcels (or the whole county
    when name is omitted) — lets the map fly to a region without loading its
    geometry, so viewport loading can take over from there."""
    where = "neighborhood = :nb" if name else "TRUE"
    rows = _query(f"""
        SELECT ST_XMin(ext) AS w, ST_YMin(ext) AS s,
               ST_XMax(ext) AS e, ST_YMax(ext) AS n
        FROM (SELECT ST_Extent(geom) AS ext FROM parcel_master WHERE {where}) q
    """, {"nb": name} if name else {})
    if not rows or rows[0]["w"] is None:
        raise HTTPException(status_code=404, detail="no parcels for that region")
    return rows[0]


_LEAD_SELECT = """
    SELECT m.parcel_id, m.address, m.neighborhood, m.owner_name_raw, m.owner_type,
           m.owner_mailing_addr, m.is_absentee, m.land_use_code, m.zoning_code,
           m.il_ratio, m.land_value, m.improvement_value,
           (COALESCE(m.land_value,0)+COALESCE(m.improvement_value,0)) AS total_value,
           round((m.land_value / NULLIF(COALESCE(m.land_value,0)+COALESCE(m.improvement_value,0),0))::numeric, 3) AS land_share,
           m.area_sqft, m.home_sqft, m.num_units, m.last_sale_date, m.last_sale_price,
           m.condition_gap, m.area_land_value,
           m.on_septic, m.water_main_ft, m.avg_slope_pct, m.buildable_sqft,
           CASE WHEN m.last_sale_date IS NOT NULL AND m.last_sale_date <= CURRENT_DATE
                THEN round(((CURRENT_DATE - m.last_sale_date) / 365.25)::numeric, 0) END AS years_owned,
           s.opportunity_score, s.development_score, s.owner_motivation_score,
           s.distress_score, s.demand_score, s.use_classification,
           s.constraints->>'active' AS constraints
    FROM parcel_scores s JOIN parcel_master m USING (parcel_id)
"""


@app.get("/parcels")
def list_parcels(
    filters: dict = Depends(lead_filter_params),
    sort: str = Query("land_value"),   # any key in _SORT_EXPR
    desc: bool = True,
    limit: int = Query(100, le=1000),
    offset: int = 0,
) -> dict:
    """Filterable parcel search (joins master + the optional score overlay). The
    realtor sorts by any whitelisted field; the default is land value, a sensible
    neutral order when scoring is off. Also returns the total match count so the
    list can show 'N lots' independent of the page size."""
    where, params = _lead_filters(filters)
    expr = _SORT_EXPR.get(sort, _SORT_EXPR["land_value"])
    direction = "DESC" if desc else "ASC"
    total = _query(f"SELECT count(*) AS n FROM parcel_scores s "
                   f"JOIN parcel_master m USING (parcel_id) "
                   f"WHERE {' AND '.join(where)}", params)[0]["n"]
    params.update({"limit": limit, "offset": offset})
    results = _query(f"""
        {_LEAD_SELECT}
        WHERE {" AND ".join(where)}
        ORDER BY {expr} {direction} NULLS LAST, m.parcel_id
        LIMIT :limit OFFSET :offset
    """, params)
    return {"count": len(results), "total": total, "limit": limit,
            "offset": offset, "sort": sort, "desc": desc, "results": results}


@app.get("/export")
def export_leads(
    filters: dict = Depends(lead_filter_params),
    fmt: str = Query("xlsx", pattern="^(xlsx|csv)$"),
    sort: str = Query("land_value"),
    desc: bool = True,
    limit: int = Query(2000, le=10000),
):
    """Download the current filter as a call sheet (.xlsx or .csv), in the same
    order the realtor is viewing: address, region, score overlay, ownership +
    mailing address for outreach, valuation, zoning, upcoming sheriff sale."""
    import io
    from datetime import date

    import pandas as pd
    from fastapi.responses import StreamingResponse

    where, params = _lead_filters(filters)
    params["limit"] = limit
    expr = _SORT_EXPR.get(sort, _SORT_EXPR["land_value"])
    direction = "DESC" if desc else "ASC"
    # inject outreach-only columns (sheriff-sale date, signal count) at the FROM line
    select = _LEAD_SELECT.replace(
        "\n    FROM parcel_scores s JOIN parcel_master m USING (parcel_id)",
        """,
           (SELECT min(ps.event_date) FROM parcel_signals ps
             WHERE ps.parcel_id = m.parcel_id AND ps.signal_type = 'sheriff_sale'
               AND ps.event_date >= CURRENT_DATE) AS next_sheriff_sale,
           (SELECT count(*) FROM parcel_signals ps
             WHERE ps.parcel_id = m.parcel_id) AS signal_count
    FROM parcel_scores s JOIN parcel_master m USING (parcel_id)""")
    rows = _query(f"""
        {select}
        WHERE {" AND ".join(where)}
        ORDER BY {expr} {direction} NULLS LAST, m.parcel_id
        LIMIT :limit
    """, params)
    df = pd.DataFrame(rows)
    if not df.empty:
        df.insert(0, "rank", range(1, len(df) + 1))

    region = (filters.get("neighborhood") or "all-regions").replace(" ", "_").lower()
    return _spreadsheet_response(df, f"infill_leads_{region}_{date.today():%Y%m%d}", fmt)


def _spreadsheet_response(df, stem: str, fmt: str, sheet: str = "Leads"):
    """Stream a DataFrame as .csv or a frozen-header, auto-width .xlsx download."""
    import io

    import pandas as pd
    from fastapi.responses import StreamingResponse

    if fmt == "csv":
        buf = io.StringIO()
        df.to_csv(buf, index=False)
        return StreamingResponse(
            iter([buf.getvalue()]), media_type="text/csv",
            headers={"Content-Disposition": f'attachment; filename="{stem}.csv"'})
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as xw:
        df.to_excel(xw, index=False, sheet_name=sheet)
        ws = xw.sheets[sheet]
        for col_cells in ws.columns:  # readable widths
            width = max(len(str(c.value)) if c.value is not None else 0 for c in col_cells)
            ws.column_dimensions[col_cells[0].column_letter].width = min(max(width + 2, 8), 48)
        ws.freeze_panes = "A2"
    buf.seek(0)
    return StreamingResponse(
        buf, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="{stem}.xlsx"'})


def _parcel_dossier(parcel_id: str) -> dict:
    """The full parcel dossier: master + score components + signals timeline +
    assemblage membership + neighborhood demand + audit flags. Factored out so
    both /parcels/{id} and a lead's detail view show the same auto-populated
    'basics' — the moment an agent saves a lead, everything we already know about
    the parcel travels with it."""
    master = _query("""
        SELECT *, ST_Y(ST_Centroid(geom))::float AS lat,
                  ST_X(ST_Centroid(geom))::float AS lng
        FROM parcel_master WHERE parcel_id = :p
    """, {"p": parcel_id})
    if not master:
        raise HTTPException(status_code=404, detail="parcel not found")
    master[0].pop("geom", None); master[0].pop("centroid", None)
    lat, lng = master[0].pop("lat", None), master[0].pop("lng", None)
    # a "curb view" of the house: an inline Street View Static image when a Google
    # Maps key is configured (the drive-by, recreated at the desk), else null —
    # the frontend still offers free Street View / aerial deep-links from lat/lng.
    from config import settings
    streetview_url = None
    if settings.google_maps_key and lat is not None:
        streetview_url = (
            f"https://maps.googleapis.com/maps/api/streetview?size=600x300"
            f"&location={lat},{lng}&fov=75&source=outdoor&key={settings.google_maps_key}")
    scores = _query("SELECT * FROM parcel_scores WHERE parcel_id = :p", {"p": parcel_id})
    signals = _query(
        "SELECT signal_type, event_date, status, severity, source FROM parcel_signals "
        "WHERE parcel_id = :p ORDER BY event_date DESC", {"p": parcel_id})

    assemblage = None
    if master[0].get("assemblage_id"):
        a = _query("""
            SELECT id, owner_name_norm, parcel_count, combined_sqft, combined_land_value
            FROM assemblages WHERE id = :a
        """, {"a": master[0]["assemblage_id"]})
        if a:
            members = _query("""
                SELECT m.parcel_id, m.address, m.area_sqft, m.land_value,
                       s.opportunity_score
                FROM parcel_master m LEFT JOIN parcel_scores s USING (parcel_id)
                WHERE m.assemblage_id = :a ORDER BY m.parcel_id
            """, {"a": master[0]["assemblage_id"]})
            assemblage = {**a[0], "members": members}
    demand = None
    if master[0].get("neighborhood"):
        d = _query("SELECT * FROM neighborhood_demand WHERE neighborhood = :n",
                   {"n": master[0]["neighborhood"]})
        demand = d[0] if d else None
    audit = _query(
        "SELECT code, severity, detail FROM parcel_audit_flag WHERE parcel_id = :p "
        "ORDER BY severity, code", {"p": parcel_id})
    # plain-English read of the parcel's zoning district, from the transcribed
    # official code; says so plainly when a district isn't transcribed yet
    from scoring.zoning_info import describe as _describe_zoning
    zoning = _describe_zoning(master[0].get("zoning_code"), master[0].get("neighborhood"),
                              municipality=master[0].get("municipality"))

    return {"master": master[0], "scores": scores[0] if scores else None,
            "signals": signals, "assemblage": assemblage, "demand": demand,
            "audit_flags": audit, "zoning": zoning,
            "lat": lat, "lng": lng, "streetview_url": streetview_url}


@app.get("/parcels/search")
def parcels_search(q: str = Query(..., min_length=2),
                   limit: int = Query(20, ge=1, le=50)) -> dict:
    """Look up any parcel by address or parcel id, for the Discover map's search
    box. Returns a centroid lat/lng so the UI can fly straight to the lot. Any
    score (incl. 0 / knocked-out) is searchable — an agent may want to diligence
    a parcel the ranking hides. Defined before /parcels/{id} so 'search' isn't
    swallowed as a parcel id."""
    term = q.strip()
    rows = _query("""
        SELECT m.parcel_id, m.address, m.neighborhood, m.zoning_code,
               s.opportunity_score, s.use_classification,
               ST_Y(ST_Centroid(m.geom))::float AS lat,
               ST_X(ST_Centroid(m.geom))::float AS lng
        FROM parcel_master m
        LEFT JOIN parcel_scores s USING (parcel_id)
        WHERE m.geom IS NOT NULL
          AND (m.address ILIKE :like OR m.parcel_id LIKE :pid)
        ORDER BY s.opportunity_score DESC NULLS LAST, m.parcel_id
        LIMIT :lim
    """, {"like": f"%{term}%", "pid": term.replace(" ", "") + "%", "lim": limit})
    return {"count": len(rows), "results": rows}


@app.get("/parcels/{parcel_id}/geojson")
def parcel_geojson(parcel_id: str) -> dict:
    """A single parcel's geometry as a GeoJSON feature — so the map can outline a
    searched lot even when it falls outside the current score/region filter (and
    therefore isn't in the main /geojson slice)."""
    rows = _query("""
        SELECT jsonb_build_object(
            'type', 'Feature',
            'geometry', ST_AsGeoJSON(m.geom)::jsonb,
            'properties', jsonb_build_object(
                'parcel_id', m.parcel_id, 'address', m.address,
                'opportunity_score', s.opportunity_score)
        ) AS feature
        FROM parcel_master m LEFT JOIN parcel_scores s USING (parcel_id)
        WHERE m.parcel_id = :p AND m.geom IS NOT NULL
    """, {"p": parcel_id})
    if not rows:
        raise HTTPException(status_code=404, detail="parcel geometry not found")
    return {"type": "FeatureCollection", "features": [rows[0]["feature"]]}


@app.get("/parcels/{parcel_id}")
def get_parcel(parcel_id: str) -> dict:
    """Full dossier: master + score components + signals timeline + assemblage
    membership (the cluster's stats and every underlying lot, so an assembled
    opportunity is never confused with a single parcel)."""
    return _parcel_dossier(parcel_id)


# --- lead pipeline (CRM funnel) --------------------------------------------
# The outreach-driven funnel: find -> vet -> reach out -> hear back -> hand off.
# Order is the funnel order; 'passed' is a terminal archive reachable from
# anywhere (a lead that died in diligence or got a 'no').
STAGES = ["prospect", "diligence", "outreach", "responded", "handed_off", "passed"]
RESPONSE_OUTCOMES = ["positive", "negative"]
_PHOTO_MIME = {"image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp",
               "image/heic": ".heic", "image/heif": ".heif"}


class LeadIn(BaseModel):
    parcel_id: str


class LeadPatch(BaseModel):
    stage: Optional[str] = None
    response_outcome: Optional[str] = None   # positive | negative
    responded_at: Optional[str] = None
    diligence: Optional[dict] = None         # {checklist_key: bool} the agent confirms
    offer_amount: Optional[float] = None
    offer_date: Optional[str] = None
    deal_terms: Optional[str] = None
    close_price: Optional[float] = None
    close_date: Optional[str] = None


class EntryIn(BaseModel):
    stage: str
    body: str


class LettersIn(BaseModel):
    lead_ids: list[int]


def _owned_lead(lead_id: int, user: str) -> dict:
    rows = _query("SELECT * FROM leads WHERE id = :id AND user_email = :u",
                  {"id": lead_id, "u": user})
    if not rows:
        raise HTTPException(status_code=404, detail="lead not found")
    return rows[0]


@app.get("/leads")
def list_leads(request: Request) -> dict:
    """The agent's whole pipeline, one row per saved lead, with the live parcel
    metrics the board needs (score, zoning, neighborhood, demand headline) plus a
    note/photo count. Grouped into stages by the frontend."""
    rows = _query("""
        SELECT l.id, l.parcel_id, l.stage, l.added_score, l.offer_amount,
               l.close_price, l.response_outcome, l.responded_at,
               l.updated_at, l.created_at,
               m.address, m.neighborhood, m.zoning_code, m.owner_name_raw,
               m.land_value, m.condition_gap, m.homestead,
               s.opportunity_score, s.use_classification,
               nd.demand_score,
               (SELECT count(*) FROM lead_entries e WHERE e.lead_id = l.id) AS entry_count,
               (SELECT count(*) FROM lead_entries e
                WHERE e.lead_id = l.id AND e.kind = 'photo') AS photo_count,
               (SELECT body FROM lead_entries e
                WHERE e.lead_id = l.id AND e.kind = 'note' AND e.body IS NOT NULL
                ORDER BY e.created_at DESC LIMIT 1) AS latest_note,
               (SELECT max(o.generated_at) FROM lead_outreach o WHERE o.lead_id = l.id) AS last_outreach_at,
               (SELECT o.status FROM lead_outreach o WHERE o.lead_id = l.id
                ORDER BY o.generated_at DESC LIMIT 1) AS last_outreach_status
        FROM leads l
        JOIN parcel_master m USING (parcel_id)
        LEFT JOIN parcel_scores s USING (parcel_id)
        LEFT JOIN neighborhood_demand nd ON nd.neighborhood = m.neighborhood
        WHERE l.user_email = :u
        ORDER BY l.updated_at DESC
    """, {"u": current_user(request)})
    return {"count": len(rows), "stages": STAGES, "leads": rows}


@app.post("/leads", status_code=201)
def add_lead(lead: LeadIn, request: Request) -> dict:
    """Save a parcel to the pipeline (Watchlist). Idempotent: adding a parcel
    already in the pipeline returns the existing lead, so the button is safe to
    double-click. Snapshots the opportunity score at add time."""
    user = current_user(request)
    if not _query("SELECT 1 FROM parcel_master WHERE parcel_id = :p",
                  {"p": lead.parcel_id}):
        raise HTTPException(status_code=404, detail="parcel not found")
    existing = _query("SELECT * FROM leads WHERE user_email = :u AND parcel_id = :p",
                      {"u": user, "p": lead.parcel_id})
    if existing:
        return {**existing[0], "created": False}
    rows = _execute("""
        INSERT INTO leads (user_email, parcel_id, added_score)
        VALUES (:u, :p, (SELECT opportunity_score FROM parcel_scores WHERE parcel_id = :p))
        RETURNING *
    """, {"u": user, "p": lead.parcel_id})
    return {**rows[0], "created": True}


@app.get("/leads/export")
def export_pipeline(request: Request,
                    fmt: str = Query("xlsx", pattern="^(xlsx|csv)$"),
                    stage: Optional[str] = None):
    """Export the agent's saved pipeline (optionally a single stage, e.g.
    'watchlist') to a spreadsheet. EVERY fact is spread across its own column, and
    a set of objective 'criteria' flags makes plain what a person might have
    filtered for to reach each property — owned 30+ years, individual owner, tax
    delinquent, and so on. No judgement is made about whether a feature is good or
    bad: the flags are factual matches to the filter vocabulary, and a leading
    'Notable criteria' column lists the true ones for quick scanning."""
    import re
    from datetime import date

    import pandas as pd

    user = current_user(request)
    if stage is not None and stage not in STAGES:
        raise HTTPException(status_code=400, detail="unknown stage")
    rows = _query(f"""
        SELECT l.stage, l.added_score, l.created_at::date AS added_on,
               m.parcel_id, m.address, m.neighborhood,
               m.owner_name_raw, m.owner_type, m.owner_mailing_addr, m.is_absentee,
               m.homestead, m.land_use_code, m.zoning_code, m.num_units,
               m.land_value, m.improvement_value,
               (COALESCE(m.land_value,0)+COALESCE(m.improvement_value,0)) AS total_value,
               round((m.land_value / NULLIF(COALESCE(m.land_value,0)+COALESCE(m.improvement_value,0),0))::numeric, 3) AS land_share,
               m.area_sqft, m.home_sqft, m.il_ratio, m.has_structure,
               m.last_sale_date, m.last_sale_price,
               CASE WHEN m.last_sale_date IS NOT NULL AND m.last_sale_date <= CURRENT_DATE
                    THEN round(((CURRENT_DATE - m.last_sale_date) / 365.25)::numeric, 0) END AS years_owned,
               m.on_septic, m.water_main_ft, m.avg_slope_pct, m.max_slope_pct,
               m.buildable_pct, m.buildable_sqft,
               m.flood_flag, m.floodway_flag, m.slope_flag, m.historic_flag, m.cso_flag,
               s.opportunity_score, s.development_score, s.owner_motivation_score,
               s.distress_score, s.demand_score, s.use_classification,
               (m.owner_mailing_addr ~ ' [A-Z]{{2}} [0-9]{{5}}'
                 AND substring(m.owner_mailing_addr from ' ([A-Z]{{2}}) [0-9]{{5}}') <> 'OH') AS out_of_state,
               {_sig_exists('tax_delinquent')} AS tax_delinquent,
               {_sig_exists('code_violation')} AS code_violation,
               EXISTS (SELECT 1 FROM parcel_signals ps WHERE ps.parcel_id = m.parcel_id
                       AND ps.signal_type = 'sheriff_sale' AND ps.event_date >= CURRENT_DATE) AS sheriff_sale,
               (SELECT min(ps.event_date) FROM parcel_signals ps WHERE ps.parcel_id = m.parcel_id
                 AND ps.signal_type = 'sheriff_sale' AND ps.event_date >= CURRENT_DATE) AS next_sheriff_sale,
               {_sig_exists('landbank_inventory')} AS landbank,
               nd.turnover_pct, nd.median_price_24mo, nd.demand_score AS area_demand_score,
               nd.builds_per_1k
        FROM leads l
        JOIN parcel_master m USING (parcel_id)
        LEFT JOIN parcel_scores s USING (parcel_id)
        LEFT JOIN neighborhood_demand nd ON nd.neighborhood = m.neighborhood
        WHERE l.user_email = :u {"AND l.stage = :stage" if stage else ""}
        ORDER BY l.updated_at DESC
    """, {"u": user, **({"stage": stage} if stage else {})})

    stem = f"pipeline_{stage or 'all'}_{date.today():%Y%m%d}"
    df = pd.DataFrame(rows)
    if df.empty:
        return _spreadsheet_response(
            pd.DataFrame(columns=["Stage", "Address", "Area", "Parcel ID"]), stem, fmt, "Pipeline")

    # --- objective criteria flags (factual matches to the filter vocabulary) ---
    yrs = pd.to_numeric(df["years_owned"], errors="coerce")
    ls = pd.to_numeric(df["land_share"], errors="coerce")
    hs = pd.to_numeric(df["home_sqft"], errors="coerce")
    ot = df["owner_type"].fillna("")
    nm = df["owner_name_raw"].fillna("")
    bool_ = lambda c: df[c].fillna(False).astype(bool)  # noqa: E731
    bank_pat = _BANK_RE.replace(r"\y", r"\b")
    auth_pat = f"({_CMHA_RE}|{_PORT_RE})".replace(r"\y", r"\b")
    flags: dict = {
        "Owned 30+ yr": yrs >= 30,
        "Owned 20+ yr": yrs >= 20,
        "Owned 10+ yr": yrs >= 10,
        "Individual owner": ot.eq("individual"),
        "LLC owner": ot.eq("llc"),
        "Trust owner": ot.eq("trust"),
        "Absentee owner": bool_("is_absentee"),
        "Out-of-state owner": bool_("out_of_state"),
        "Senior owner (65+ homestead)": bool_("homestead"),
        "Bank/REO owner": nm.str.contains(bank_pat, case=False, regex=True, na=False),
        "Land bank / Port": nm.str.contains(auth_pat, case=False, regex=True, na=False) | bool_("landbank"),
        "Vacant land": df["has_structure"].apply(lambda v: v is False),
        "Land >= 50% of value": ls >= 0.5,
        "Small house (<=1800 sqft)": (hs > 0) & (hs <= 1800),
        "On septic (no sewer)": bool_("on_septic"),
        "Tax delinquent": bool_("tax_delinquent"),
        "Code violation": bool_("code_violation"),
        "Upcoming sheriff sale": bool_("sheriff_sale"),
    }
    # a single 'notable criteria' summary: the true flags, with only the highest
    # tenure bucket, so it reads like the filters a person set (not redundant)
    tenure_labels = ["Owned 30+ yr", "Owned 20+ yr", "Owned 10+ yr"]
    summary_order = [k for k in flags if k not in tenure_labels]
    notable = []
    for i in range(len(df)):
        parts = []
        for tl in tenure_labels:
            if bool(flags[tl].iloc[i]):
                parts.append(tl)
                break
        parts += [k for k in summary_order if bool(flags[k].iloc[i])]
        notable.append("; ".join(parts))

    for label, series in flags.items():
        df[label] = series.map(lambda b: "Yes" if bool(b) else "")
    df["notable_criteria"] = notable
    df["property_type"] = df["land_use_code"].map(_land_use_label)
    # readable sewer status; "Public sewer likely" because absence from the septic
    # inventory is strong evidence, not proof (see ingestion/infrastructure.py)
    df["sewer_service"] = df["on_septic"].map(
        lambda v: "Private septic (no sewer)" if bool(v) else "Public sewer likely")
    for c in ("flood_flag", "floodway_flag", "slope_flag", "historic_flag", "cso_flag"):
        df[c] = df[c].map(lambda b: "Yes" if bool(b) else "")

    facts = [
        ("owner_name_raw", "Owner"), ("owner_type", "Owner type"),
        ("owner_mailing_addr", "Owner mailing address"), ("property_type", "Property type"),
        ("land_use_code", "DTE class"), ("zoning_code", "Zoning"), ("num_units", "Units"),
        ("land_value", "Land value"), ("improvement_value", "Building value"),
        ("total_value", "Total value"), ("land_share", "Land share (0-1)"),
        ("il_ratio", "I/L ratio"),
        ("last_sale_price", "Last sale price"), ("years_owned", "Years owned"),
        ("next_sheriff_sale", "Next sheriff sale"),
        ("opportunity_score", "Opportunity score"), ("development_score", "Development score"),
        ("owner_motivation_score", "Owner-motivation score"), ("distress_score", "Distress score"),
        ("demand_score", "Demand score"), ("use_classification", "Play type"),
        ("sewer_service", "Sewer service"), ("water_main_ft", "Water main within (ft)"),
        ("avg_slope_pct", "Average grade (%)"), ("max_slope_pct", "Steepest grade (%)"),
        ("buildable_pct", "Buildable area (%)"), ("buildable_sqft", "Buildable area (sqft)"),
        ("flood_flag", "Floodplain"), ("floodway_flag", "Floodway"),
        ("slope_flag", "Steep slope"), ("historic_flag", "Historic"), ("cso_flag", "CSO"),
        ("area_demand_score", "Area demand score"), ("turnover_pct", "Area 24mo turnover %"),
        ("median_price_24mo", "Area median sale (24mo)"), ("builds_per_1k", "Area new builds / 1k"),
        ("added_on", "Added on"), ("added_score", "Score when added"),
    ]
    front = [("address", "Address"), ("neighborhood", "Area"),
             ("parcel_id", "Parcel ID"), ("notable_criteria", "Notable criteria (filter matches)"),
             ("area_sqft", "Lot size (sqft)"), ("home_sqft", "House size (sqft)"),
             ("last_sale_date", "Last sale date")]
    cols = [c for c, _ in front] + list(flags) + [c for c, _ in facts]
    rename = {c: h for c, h in front + facts}
    out = df[cols].rename(columns=rename)
    return _spreadsheet_response(out, stem, fmt, "Pipeline")


# --- outreach letters (registered before the /leads/{lead_id} catch-all) ------
def _ensure_outreach(lead_id: int) -> dict:
    """The lead's latest not-yet-sent outreach row, or a fresh one — so repeatedly
    previewing a letter reuses the same response token until it's marked sent."""
    rows = _query("SELECT * FROM lead_outreach WHERE lead_id = :l AND status = 'generated' "
                  "ORDER BY generated_at DESC LIMIT 1", {"l": lead_id})
    if rows:
        return rows[0]
    return _execute("INSERT INTO lead_outreach (lead_id) VALUES (:l) RETURNING *",
                    {"l": lead_id})[0]


def _letter_ctx(lead_id: int, user: str) -> dict:
    """Merge context for one lead's letter: owner + property + a response link that
    carries the outreach token (the QR / short link on the printed page)."""
    from config import settings

    lead = _owned_lead(lead_id, user)
    m = _query("SELECT owner_name_raw, address, owner_mailing_addr, neighborhood "
               "FROM parcel_master WHERE parcel_id = :p", {"p": lead["parcel_id"]})
    if not m:
        raise HTTPException(status_code=404, detail="parcel not found")
    m = m[0]
    outreach = _ensure_outreach(lead_id)   # still logs "letter generated" for the pipeline
    # the printed QR / link: the team website by default (no deploy needed), or the
    # app's tracked /r/{token} page when outreach_link_url is blank
    link = settings.outreach_link_url or f"{settings.public_base_url}/r/{outreach['response_token']}"
    return {
        "owner_name": _titlecase(m.get("owner_name_raw")),
        "property_address": _titlecase(m.get("address")),
        "neighborhood": m.get("neighborhood") or "your area",
        "mailing_lines": [m["owner_mailing_addr"]] if m.get("owner_mailing_addr") else [],
        "response_url": link,
    }


def _titlecase(s: Optional[str]) -> Optional[str]:
    return s.title() if isinstance(s, str) else s


def _address_slug(address: Optional[str], fallback: str) -> str:
    """A filesystem-safe filename piece from a property address, so a downloaded
    letter is filed by the property rather than an opaque id
    ("8884 Cherry St" -> "8884_Cherry_St")."""
    import re
    slug = re.sub(r"[^A-Za-z0-9]+", "_", (address or "").strip()).strip("_")
    return slug[:60] or fallback


@app.get("/leads/{lead_id}/letter.pdf")
def lead_letter(lead_id: int, request: Request):
    """A single print-ready outreach letter PDF for a lead (creates/reuses an
    outreach row + response token). Named after the property address so the
    downloaded files organize themselves."""
    from fastapi.responses import Response

    from api.outreach import render_letters
    ctx = _letter_ctx(lead_id, current_user(request))
    pdf = render_letters([ctx])
    name = f"letter_{_address_slug(ctx.get('property_address'), f'lead_{lead_id}')}.pdf"
    return Response(content=pdf, media_type="application/pdf",
                    headers={"Content-Disposition": f'inline; filename="{name}"'})


_DOCX_MIME = ("application/vnd.openxmlformats-officedocument"
              ".wordprocessingml.document")


@app.get("/leads/{lead_id}/letter.docx")
def lead_letter_docx(lead_id: int, request: Request):
    """The same outreach letter as an EDITABLE Word document, so the team can
    adjust a name or personalise a line before printing."""
    from fastapi.responses import Response

    from api.outreach import render_letters_docx
    ctx = _letter_ctx(lead_id, current_user(request))
    data = render_letters_docx([ctx])
    name = f"letter_{_address_slug(ctx.get('property_address'), f'lead_{lead_id}')}.docx"
    return Response(content=data, media_type=_DOCX_MIME,
                    headers={"Content-Disposition": f'attachment; filename="{name}"'})


@app.post("/leads/letters")
def lead_letters_batch(payload: LettersIn, request: Request,
                       fmt: str = Query("pdf", pattern="^(pdf|docx)$")):
    """A batch of letters as one multi-page PDF (one letter per page) — for
    printing a stack in a single job."""
    from datetime import date

    from fastapi.responses import Response

    from api.outreach import render_letters, render_letters_docx
    user = current_user(request)
    ctxs = [_letter_ctx(i, user) for i in payload.lead_ids]
    if not ctxs:
        raise HTTPException(status_code=400, detail="no leads")
    data = render_letters_docx(ctxs) if fmt == "docx" else render_letters(ctxs)
    # a one-lead "batch" is really a single letter, so file it by address too;
    # a real stack gets the count + date
    if len(ctxs) == 1:
        stem = f"letter_{_address_slug(ctxs[0].get('property_address'), 'lead')}"
    else:
        stem = f"letters_{len(ctxs)}_{date.today():%Y%m%d}"
    media = _DOCX_MIME if fmt == "docx" else "application/pdf"
    return Response(content=data, media_type=media,
                    headers={"Content-Disposition": f'attachment; filename="{stem}.{fmt}"'})


def _response_lookup(token: str, record: Optional[str] = None) -> Optional[str]:
    """Resolve an outreach response_token to its property address, optionally
    recording the owner's outcome. Public (the unguessable token is the auth):
    a positive reply advances the lead to 'responded', a negative archives it to
    'passed'. Returns None for an unknown/invalid token."""
    import uuid as _uuid
    try:
        _uuid.UUID(str(token))
    except (ValueError, TypeError):
        return None
    rows = _query("""
        SELECT o.id AS oid, o.lead_id, m.address
        FROM lead_outreach o
        JOIN leads l ON l.id = o.lead_id
        JOIN parcel_master m ON m.parcel_id = l.parcel_id
        WHERE o.response_token = CAST(:t AS uuid)
    """, {"t": str(token)})
    if not rows:
        return None
    row = rows[0]
    if record in RESPONSE_OUTCOMES:
        _execute("UPDATE lead_outreach SET status = 'responded', responded_at = now(), "
                 "outcome = :o WHERE id = :i", {"o": record, "i": row["oid"]})
        _execute("""
            UPDATE leads SET response_outcome = :o, responded_at = CURRENT_DATE,
                stage = CASE WHEN :o = 'positive' THEN 'responded' ELSE 'passed' END,
                updated_at = now()
            WHERE id = :l
        """, {"o": record, "l": row["lead_id"]})
    return row["address"]


@app.get("/r/{token}")
def response_page(token: str):
    """Public response page an owner reaches from the letter's QR / short link."""
    from fastapi.responses import HTMLResponse

    from api import letter_template as T
    from api.outreach import response_page_html
    addr = _response_lookup(token)
    return HTMLResponse(response_page_html(addr, done=False, outcome=None, contact=T.SENDER))


@app.post("/r/{token}")
def response_submit(token: str, outcome: str = Form(...)):
    """Owner's reply from the response page — logs the outcome and advances the
    lead, then shows a thank-you (contact info still front and centre)."""
    from fastapi.responses import HTMLResponse

    from api import letter_template as T
    from api.outreach import response_page_html
    picked = outcome if outcome in RESPONSE_OUTCOMES else "positive"
    addr = _response_lookup(token, record=picked)
    return HTMLResponse(response_page_html(addr, done=True, outcome=picked, contact=T.SENDER))


@app.post("/leads/{lead_id}/outreach/sent")
def lead_outreach_sent(lead_id: int, request: Request) -> dict:
    """Mark the lead's current letter as mailed and advance it to the Outreach
    stage (awaiting a response)."""
    user = current_user(request)
    _owned_lead(lead_id, user)
    row = _ensure_outreach(lead_id)
    _execute("UPDATE lead_outreach SET status = 'sent', sent_at = now() WHERE id = :i",
             {"i": row["id"]})
    _execute("UPDATE leads SET stage = 'outreach', updated_at = now() "
             "WHERE id = :l AND user_email = :u", {"l": lead_id, "u": user})
    return {"ok": True, "token": str(row["response_token"])}


@app.post("/leads/{lead_id}/outreach/unsent")
def lead_outreach_unsent(lead_id: int, request: Request) -> dict:
    """Undo 'mark sent': revert the latest letter to un-sent, and if the lead is
    still sitting at Outreach, move it back to Diligence."""
    user = current_user(request)
    _owned_lead(lead_id, user)
    rows = _query("SELECT id FROM lead_outreach WHERE lead_id = :l AND status = 'sent' "
                  "ORDER BY generated_at DESC LIMIT 1", {"l": lead_id})
    if rows:
        _execute("UPDATE lead_outreach SET status = 'generated', sent_at = NULL WHERE id = :i",
                 {"i": rows[0]["id"]})
    _execute("UPDATE leads SET stage = CASE WHEN stage = 'outreach' THEN 'diligence' ELSE stage END, "
             "updated_at = now() WHERE id = :l AND user_email = :u", {"l": lead_id, "u": user})
    return {"ok": True}


@app.get("/leads/{lead_id}")
def get_lead(lead_id: int, request: Request) -> dict:
    """A lead's full working file: the auto-populated parcel dossier (the basics
    we already know — score breakdown, zoning, demand, signals, data checks) plus
    the funnel: structured deal fields and the per-stage note/photo timeline."""
    lead = _owned_lead(lead_id, current_user(request))
    entries = _query("""
        SELECT id, stage, kind, body, photo_name, photo_mime, created_at
        FROM lead_entries WHERE lead_id = :id ORDER BY created_at ASC
    """, {"id": lead_id})
    outreach = _query(
        "SELECT status, sent_at, responded_at, outcome, generated_at "
        "FROM lead_outreach WHERE lead_id = :id ORDER BY generated_at DESC LIMIT 1",
        {"id": lead_id})
    return {"lead": lead, "dossier": _parcel_dossier(lead["parcel_id"]),
            "entries": entries, "stages": STAGES,
            "outreach": outreach[0] if outreach else None}


@app.patch("/leads/{lead_id}")
def update_lead(lead_id: int, patch: LeadPatch, request: Request) -> dict:
    """Advance the stage, record a response, tick the diligence checklist, or fill
    in deal fields. Only provided fields change."""
    import json
    user = current_user(request)
    _owned_lead(lead_id, user)
    if patch.stage is not None and patch.stage not in STAGES:
        raise HTTPException(status_code=400, detail=f"stage must be one of {STAGES}")
    if patch.response_outcome is not None and patch.response_outcome not in RESPONSE_OUTCOMES:
        raise HTTPException(status_code=400,
                            detail=f"response_outcome must be one of {RESPONSE_OUTCOMES}")
    # exclude_UNSET (not exclude_none): a field the client actually sent — even as
    # null — is applied, so a response/outcome can be CLEARED (undo); fields the
    # client didn't mention are left untouched.
    fields = patch.model_dump(exclude_unset=True)
    if not fields:
        raise HTTPException(status_code=400, detail="nothing to update")
    params = {"id": lead_id, "u": user}
    assignments = []
    for k, v in fields.items():
        if k == "diligence" and v is not None:        # dict -> jsonb
            assignments.append("diligence = CAST(:diligence AS jsonb)")
            params["diligence"] = json.dumps(v)
        else:
            assignments.append(f"{k} = :{k}"); params[k] = v
    rows = _execute(
        f"UPDATE leads SET {', '.join(assignments)}, updated_at = now() "
        f"WHERE id = :id AND user_email = :u RETURNING *", params)
    return rows[0]


@app.delete("/leads/{lead_id}")
def delete_lead(lead_id: int, request: Request) -> dict:
    """Remove a lead (and its notes/photos, via ON DELETE CASCADE). Also cleans
    up any photo files on disk."""
    user = current_user(request)
    _owned_lead(lead_id, user)
    photos = _query("SELECT photo_path FROM lead_entries "
                    "WHERE lead_id = :id AND photo_path IS NOT NULL", {"id": lead_id})
    _execute("DELETE FROM leads WHERE id = :id AND user_email = :u",
             {"id": lead_id, "u": user})
    for p in photos:
        _unlink_quiet(p["photo_path"])
    _rmdir_quiet(lead_id)
    return {"deleted": lead_id}


@app.post("/leads/{lead_id}/entries", status_code=201)
def add_entry(lead_id: int, entry: EntryIn, request: Request) -> dict:
    """Add a text note to a funnel stage of a lead."""
    user = current_user(request)
    _owned_lead(lead_id, user)
    if entry.stage not in STAGES:
        raise HTTPException(status_code=400, detail=f"stage must be one of {STAGES}")
    body = entry.body.strip()
    if not body:
        raise HTTPException(status_code=400, detail="note body is empty")
    rows = _execute("""
        INSERT INTO lead_entries (lead_id, stage, kind, body)
        VALUES (:l, :s, 'note', :b)
        RETURNING id, stage, kind, body, photo_name, photo_mime, created_at
    """, {"l": lead_id, "s": entry.stage, "b": body})
    _execute("UPDATE leads SET updated_at = now() WHERE id = :id", {"id": lead_id})
    return rows[0]


@app.post("/leads/{lead_id}/photos", status_code=201)
async def add_photo(lead_id: int, request: Request,
                    stage: str = Form(...), caption: str = Form(""),
                    file: UploadFile = File(...)) -> dict:
    """Attach a site-visit (or any-stage) photo to a lead. Stored on the local
    filesystem, served back through /leads/{id}/photos/{entry_id}."""
    import uuid
    from pathlib import Path

    from config import settings
    user = current_user(request)
    _owned_lead(lead_id, user)
    if stage not in STAGES:
        raise HTTPException(status_code=400, detail=f"stage must be one of {STAGES}")
    ext = _PHOTO_MIME.get((file.content_type or "").lower())
    if not ext:
        raise HTTPException(status_code=415,
                            detail=f"unsupported image type {file.content_type!r}")
    data = await file.read()
    if len(data) > settings.lead_photo_max_bytes:
        raise HTTPException(status_code=413, detail="image too large")
    dest_dir = Path(settings.lead_photos_dir) / str(lead_id)
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest = dest_dir / f"{uuid.uuid4().hex}{ext}"
    dest.write_bytes(data)
    rows = _execute("""
        INSERT INTO lead_entries (lead_id, stage, kind, body, photo_path,
                                  photo_name, photo_mime)
        VALUES (:l, :s, 'photo', :cap, :path, :name, :mime)
        RETURNING id, stage, kind, body, photo_name, photo_mime, created_at
    """, {"l": lead_id, "s": stage, "cap": caption.strip() or None,
          "path": str(dest), "name": file.filename, "mime": file.content_type})
    _execute("UPDATE leads SET updated_at = now() WHERE id = :id", {"id": lead_id})
    return rows[0]


@app.get("/leads/{lead_id}/photos/{entry_id}")
def get_photo(lead_id: int, entry_id: int, request: Request) -> FileResponse:
    """Serve a lead's photo bytes (owner-gated)."""
    from pathlib import Path
    _owned_lead(lead_id, current_user(request))
    rows = _query("SELECT photo_path, photo_mime FROM lead_entries "
                  "WHERE id = :e AND lead_id = :l AND kind = 'photo'",
                  {"e": entry_id, "l": lead_id})
    if not rows or not rows[0]["photo_path"] or not Path(rows[0]["photo_path"]).exists():
        raise HTTPException(status_code=404, detail="photo not found")
    return FileResponse(rows[0]["photo_path"],
                        media_type=rows[0]["photo_mime"] or "image/jpeg")


@app.delete("/leads/{lead_id}/entries/{entry_id}")
def delete_entry(lead_id: int, entry_id: int, request: Request) -> dict:
    """Delete a note or photo from a lead (removes the file for photos)."""
    _owned_lead(lead_id, current_user(request))
    rows = _query("SELECT photo_path FROM lead_entries "
                  "WHERE id = :e AND lead_id = :l", {"e": entry_id, "l": lead_id})
    _execute("DELETE FROM lead_entries WHERE id = :e AND lead_id = :l",
             {"e": entry_id, "l": lead_id})
    if rows and rows[0]["photo_path"]:
        _unlink_quiet(rows[0]["photo_path"])
    return {"deleted": entry_id}


def _unlink_quiet(path: str) -> None:
    from pathlib import Path
    try:
        Path(path).unlink(missing_ok=True)
    except OSError:
        pass


def _rmdir_quiet(lead_id: int) -> None:
    """Remove a lead's (now-empty) photo directory. Never fatal."""
    from pathlib import Path

    from config import settings
    try:
        (Path(settings.lead_photos_dir) / str(lead_id)).rmdir()
    except OSError:
        pass  # not empty or doesn't exist — fine


# --- lead audit (Phase 0 of the lead-audit plan) ---------------------------
# A review harness for grounding the board in reality: serve un-reviewed top
# leads with an aerial/Street-View deep-link, capture a real/fake verdict, and
# report precision@N. See docs/lead-audit-plan.md and scoring/leadaudit/.

class LabelIn(BaseModel):
    parcel_id: str
    label: str
    reason_code: Optional[str] = None
    notes: Optional[str] = None


@app.get("/audit/precision")
def audit_precision() -> dict:
    """Precision@N over the current board — the metric the audit drives."""
    from scoring.leadaudit.precision import compute
    try:
        return compute()
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"precision unavailable: {exc}")


@app.get("/audit/queue")
def audit_queue(neighborhood: Optional[str] = None,
                min_score: float = Query(0, ge=0, le=100),
                max_score: float = Query(100, ge=0, le=100),
                limit: int = Query(25, ge=1, le=200),
                offset: int = Query(0, ge=0)) -> dict:
    """Un-reviewed leads to audit, highest score first. 'Un-reviewed' = no human
    ('review'/'agent') label yet; any heuristic ('history') guess is returned as
    a hint. `offset` pages deeper into the ranking so a reviewer isn't stuck on
    the top N, and `min_score`/`max_score` let them target a score band (e.g.
    audit the 50-60 middle, not just the marquee leads). Includes a centroid
    lat/lng so the UI can deep-link to aerial + Street View."""
    from scoring.leadaudit.labels import EFFECTIVE_LABEL_SQL
    where = ["s.opportunity_score > :ms", "s.opportunity_score <= :xs",
             "NOT EXISTS (SELECT 1 FROM lead_labels ll WHERE ll.parcel_id = s.parcel_id "
             "AND ll.source IN ('review','agent'))"]
    params: dict = {"ms": min_score, "xs": max_score, "lim": limit, "off": offset}
    if neighborhood:
        where.append("m.neighborhood = :nb"); params["nb"] = neighborhood
    rows = _query(f"""
        WITH eff AS ({EFFECTIVE_LABEL_SQL})
        SELECT s.parcel_id, m.address, m.neighborhood, m.zoning_code,
               s.opportunity_score, s.use_classification,
               ST_Y(ST_Centroid(m.geom))::float AS lat,
               ST_X(ST_Centroid(m.geom))::float AS lng,
               eff.label AS hint_label, eff.reason_code AS hint_reason
        FROM parcel_scores s
        JOIN parcel_master m USING (parcel_id)
        LEFT JOIN eff ON eff.parcel_id = s.parcel_id
        WHERE {' AND '.join(where)}
        ORDER BY s.opportunity_score DESC, s.parcel_id
        LIMIT :lim OFFSET :off
    """, params)
    return {"count": len(rows), "queue": rows}


@app.get("/audit/search")
def audit_search(q: str = Query(..., min_length=2),
                 limit: int = Query(25, ge=1, le=100)) -> dict:
    """Find any parcel by address or parcel id to audit directly — so a reviewer
    can jump to a specific lot they know, not only work down the ranked queue.
    Returns already-labelled parcels too (with their current verdict) so a prior
    call can be reviewed or overridden. Score 0 / knocked-out parcels included."""
    from scoring.leadaudit.labels import EFFECTIVE_LABEL_SQL
    term = q.strip()
    rows = _query(f"""
        WITH eff AS ({EFFECTIVE_LABEL_SQL})
        SELECT s.parcel_id, m.address, m.neighborhood, m.zoning_code,
               s.opportunity_score, s.use_classification,
               ST_Y(ST_Centroid(m.geom))::float AS lat,
               ST_X(ST_Centroid(m.geom))::float AS lng,
               eff.label AS hint_label, eff.reason_code AS hint_reason,
               eff.source AS hint_source
        FROM parcel_master m
        JOIN parcel_scores s USING (parcel_id)
        LEFT JOIN eff ON eff.parcel_id = m.parcel_id
        WHERE m.geom IS NOT NULL
          AND (m.address ILIKE :like OR m.parcel_id LIKE :pid)
        ORDER BY s.opportunity_score DESC NULLS LAST, m.parcel_id
        LIMIT :lim
    """, {"like": f"%{term}%", "pid": term.replace(" ", "") + "%", "lim": limit})
    return {"count": len(rows), "results": rows}


@app.post("/audit/label", status_code=201)
def audit_label(body: LabelIn, request: Request) -> dict:
    """Record a reviewer's verdict on a parcel (source='review'). Appends a row
    (full audit trail); the newest human verdict becomes the effective label."""
    from scoring.leadaudit.labels import is_valid
    ok, msg = is_valid(body.label, body.reason_code)
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    if not _query("SELECT 1 FROM parcel_master WHERE parcel_id = :p", {"p": body.parcel_id}):
        raise HTTPException(status_code=404, detail="parcel not found")
    rows = _execute("""
        INSERT INTO lead_labels (parcel_id, label, reason_code, source, reviewer, notes)
        VALUES (:p, :l, :r, 'review', :u, :n)
        RETURNING id, parcel_id, label, reason_code, reviewed_at
    """, {"p": body.parcel_id, "l": body.label, "r": body.reason_code,
          "u": current_user(request), "n": (body.notes or None)})
    return rows[0]


def _bbox_where(bbox: Optional[str], where: list[str], params: dict) -> None:
    """Add a viewport bounding-box filter (w,s,e,n in lng/lat). Uses the `&&`
    index operator so 'load the parcels I can see' is fast. Lets the map render
    EVERY lot in view instead of only the global top-N by score."""
    if not bbox:
        return
    try:
        w, s, e, n = (float(x) for x in bbox.split(","))
    except (ValueError, TypeError):
        raise HTTPException(status_code=400, detail="bbox must be 'w,s,e,n'")
    where.append("m.geom && ST_MakeEnvelope(:bw, :bs, :be, :bn, 4326)")
    params.update({"bw": w, "bs": s, "be": e, "bn": n})


@app.get("/geojson")
def geojson(filters: dict = Depends(lead_filter_params),
            bbox: Optional[str] = None,
            limit: int = Query(1000, le=8000)) -> dict:
    """GeoJSON for the current filter (capped). Honors the full realtor filter
    set, including `show_all` (every matching lot regardless of score) and a
    viewport `bbox` so the map can render everything currently in view."""
    where, params = _lead_filters(filters)
    _bbox_where(bbox, where, params)
    params["limit"] = limit
    rows = _query(f"""
        SELECT jsonb_build_object(
            'type','Feature',
            'geometry', ST_AsGeoJSON(m.geom)::jsonb,
            'properties', jsonb_build_object(
                'parcel_id', m.parcel_id, 'opportunity_score', s.opportunity_score,
                'use_classification', s.use_classification)
        ) AS f
        FROM parcel_scores s JOIN parcel_master m USING (parcel_id)
        WHERE {" AND ".join(where)}
        ORDER BY s.opportunity_score DESC LIMIT :limit
    """, params)
    return {"type": "FeatureCollection", "features": [r["f"] for r in rows]}


@app.get("/assemblies")
def list_assemblies(kind: Optional[str] = Query(None, pattern="^(same_owner|multi_owner)$"),
                    min_acres: float = Query(3.0, ge=0),
                    neighborhood: Optional[str] = None,
                    sort: str = Query("combined_acres",
                                      pattern="^(combined_acres|parcel_count|combined_land_value)$"),
                    limit: int = Query(1000, le=2000)) -> dict:
    """Multi-parcel tracts: adjacent parcels that TOGETHER make a developable
    site. `same_owner` is one negotiation; `multi_owner` needs every owner to
    agree, so it is listed separately and never mixed in."""
    rows = _query(f"""
        SELECT a.id, a.kind, a.owner_name_norm, a.parcel_count, a.owner_count,
               a.neighborhood, a.combined_acres, a.combined_sqft,
               a.combined_land_value,
               (SELECT count(*) FROM parcel_master m
                 WHERE m.assemblage_id = a.id AND m.has_structure IS FALSE) AS vacant_members,
               (SELECT string_agg(DISTINCT m.zoning_code, ', ')
                  FROM parcel_master m WHERE m.assemblage_id = a.id) AS zoning
        FROM assemblages a
        WHERE a.combined_acres >= :min_acres
          AND (CAST(:kind AS text) IS NULL OR a.kind = CAST(:kind AS text))
          AND (CAST(:nb AS text) IS NULL OR a.neighborhood = CAST(:nb AS text))
        ORDER BY a.{sort} DESC NULLS LAST
        LIMIT :limit
    """, {"min_acres": min_acres, "kind": kind, "nb": neighborhood, "limit": limit})
    return {"count": len(rows), "assemblies": rows}


@app.get("/assemblies/{assembly_id}")
def get_assembly(assembly_id: int) -> dict:
    """One assembly with every member parcel, so an agent can work the group."""
    head = _query("SELECT * FROM assemblages WHERE id = :i", {"i": assembly_id})
    if not head:
        raise HTTPException(status_code=404, detail="assembly not found")
    head[0].pop("geom", None)
    members = _query("""
        SELECT m.parcel_id, m.address, m.owner_name_raw, m.owner_type, m.zoning_code,
               m.area_sqft, round((m.area_sqft / 43560.0)::numeric, 2) AS acres,
               m.land_value, m.improvement_value, m.has_structure, m.on_septic,
               s.opportunity_score, s.use_classification
        FROM parcel_master m
        LEFT JOIN parcel_scores s USING (parcel_id)
        WHERE m.assemblage_id = :i
        ORDER BY m.area_sqft DESC NULLS LAST
    """, {"i": assembly_id})
    return {"assembly": head[0], "members": members}


@app.get("/geojson_assemblages")
def geojson_assemblages(assembly_id: Optional[int] = None,
                        kind: Optional[str] = None,
                        min_acres: float = Query(3.0, ge=0),
                        neighborhood: Optional[str] = None,
                        limit: int = Query(1000, le=3000)) -> dict:
    """Assemblage outlines (union of member parcels) for the map — rendered as
    a distinct dashed layer over the parcel fills so an assembled tract reads as
    one site while the member lots stay visible underneath.

    Pass `assembly_id` to outline a single tract — the app does this only when an
    assembly is opened, so ordinary browsing stays uncluttered."""
    rows = _query("""
        SELECT jsonb_build_object(
            'type','Feature',
            'geometry', ST_AsGeoJSON(a.geom)::jsonb,
            'properties', jsonb_build_object(
                'assemblage_id', a.id, 'kind', a.kind, 'owner', a.owner_name_norm,
                'parcel_count', a.parcel_count, 'owner_count', a.owner_count,
                'combined_acres', a.combined_acres)
        ) AS f
        FROM assemblages a
        WHERE (CAST(:aid AS int) IS NULL OR a.id = CAST(:aid AS int))
          AND a.combined_acres >= :min_acres
          AND (CAST(:kind AS text) IS NULL OR a.kind = CAST(:kind AS text))
          AND (CAST(:nb AS text) IS NULL OR a.neighborhood = CAST(:nb AS text))
        ORDER BY a.combined_acres DESC LIMIT :limit
    """, {"aid": assembly_id, "kind": kind, "min_acres": min_acres,
          "limit": limit, "nb": neighborhood})
    return {"type": "FeatureCollection", "features": [r["f"] for r in rows]}


@app.get("/alerts")
def alerts(limit: int = Query(50, le=500), include_notified: bool = True) -> dict:
    """Recent score-change alerts (new-high / score-jump), newest first."""
    where = "1=1" if include_notified else "a.notified_at IS NULL"
    rows = _query(f"""
        SELECT a.id, a.parcel_id, a.alert_type, a.old_score, a.new_score,
               a.created_at, a.notified_at, m.address, s.use_classification,
               s.opportunity_score
        FROM alerts a
        JOIN parcel_master m USING (parcel_id)
        LEFT JOIN parcel_scores s USING (parcel_id)
        WHERE {where}
        ORDER BY a.created_at DESC
        LIMIT :limit
    """, {"limit": limit})
    return {"count": len(rows), "alerts": rows}


@app.get("/tiles/{z}/{x}/{y}.mvt")
def tiles(z: int, x: int, y: int):
    """Vector tiles of scored parcels for the map, served via pg_tileserv/Martin."""
    return {"detail": "served by tile backend (pg_tileserv/Martin)"}
