"""Mail-merge for uploaded LOI/GL letter templates (bulk address tab). Plain
paragraph-level substitution over a .docx — the layout is whatever the agent
uploaded; we only fill in the merge fields: {owner_name}, {property_address},
{mailing_address}, {today}.

Limitation: only paragraph and table-cell text is merged (not headers or
footers), and a merged paragraph's formatting comes from its first run — a
placeholder split across differently-formatted runs loses that split, not
the text.
"""
from __future__ import annotations

import io


def _substitute(text: str, ctx: dict) -> str:
    for key, value in ctx.items():
        text = text.replace("{" + key + "}", value or "")
    return text


def _merge_paragraphs(paragraphs, ctx: dict) -> None:
    for p in paragraphs:
        original = "".join(r.text for r in p.runs) or p.text
        if "{" not in original:
            continue
        merged = _substitute(original, ctx)
        if merged == original:
            continue
        if p.runs:
            p.runs[0].text = merged
            for r in p.runs[1:]:
                r.text = ""
        else:
            p.text = merged


def fill_docx_template(template_path: str, ctx: dict) -> bytes:
    """Open an uploaded .docx template, substitute merge fields, return the
    filled document's bytes (a fresh in-memory copy — the template on disk is
    never modified)."""
    from docx import Document

    doc = Document(template_path)
    _merge_paragraphs(doc.paragraphs, ctx)
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                _merge_paragraphs(cell.paragraphs, ctx)
    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()
