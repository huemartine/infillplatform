"""Contract guards for the lead-pipeline API. These are import-only (no DB), so
they lock the funnel's shape — the part a frontend/backend drift would silently
break. The DB-bound endpoints are verified against the live stack; here we pin
the stage vocabulary, the photo whitelist, and the partial-update semantics."""
from __future__ import annotations

from api import main


def test_stage_vocabulary_and_order():
    # the outreach funnel walks prospect -> ... -> handed_off, with 'passed' a
    # terminal archive at the end. Order/vocab drift here breaks stage advance.
    assert main.STAGES == ["prospect", "diligence", "outreach", "responded", "handed_off", "passed"]
    assert main.RESPONSE_OUTCOMES == ["positive", "negative"]


def test_lead_patch_response_and_diligence():
    # the patch carries the new response + diligence fields, jsonb diligence included
    patch = main.LeadPatch(stage="responded", response_outcome="positive",
                           diligence={"teardown": True, "comps": False})
    fields = patch.model_dump(exclude_none=True)
    assert fields["stage"] == "responded" and fields["response_outcome"] == "positive"
    assert fields["diligence"] == {"teardown": True, "comps": False}


def test_photo_whitelist_is_images_only():
    assert set(main._PHOTO_MIME) == {
        "image/jpeg", "image/png", "image/webp", "image/heic", "image/heif"}
    assert all(ext.startswith(".") for ext in main._PHOTO_MIME.values())
    # a document type must not be accepted as a photo
    assert "application/pdf" not in main._PHOTO_MIME
    assert "text/plain" not in main._PHOTO_MIME


def test_lead_patch_only_sends_provided_fields():
    """update_lead builds its SET clause from model_dump(exclude_unset=True), so a
    patch that touches only the stage must not disturb the other fields."""
    patch = main.LeadPatch(stage="outreach")
    fields = patch.model_dump(exclude_unset=True)
    assert fields == {"stage": "outreach"}
    assert "response_outcome" not in fields and "offer_amount" not in fields


def test_lead_patch_can_clear_a_field_for_undo():
    """exclude_unset is what makes 'undo' work: a client can explicitly send null
    to CLEAR the response, distinct from not mentioning it at all."""
    patch = main.LeadPatch(response_outcome=None, responded_at=None, stage="outreach")
    fields = patch.model_dump(exclude_unset=True)
    assert fields == {"response_outcome": None, "responded_at": None, "stage": "outreach"}
    # a patch that doesn't mention response_outcome leaves it untouched
    assert "response_outcome" not in main.LeadPatch(stage="passed").model_dump(exclude_unset=True)


def test_lead_patch_carries_deal_fields_when_set():
    patch = main.LeadPatch(offer_amount=185000, deal_terms="Cash, 30-day close")
    fields = patch.model_dump(exclude_none=True)
    assert fields == {"offer_amount": 185000, "deal_terms": "Cash, 30-day close"}


def test_pipeline_routes_registered():
    paths = {r.path for r in main.app.routes}
    for p in ("/leads", "/leads/{lead_id}", "/leads/{lead_id}/entries",
              "/leads/{lead_id}/photos", "/leads/{lead_id}/photos/{entry_id}"):
        assert p in paths, p


def test_outreach_routes_registered():
    # letter routes must exist and precede the /leads/{lead_id} catch-all
    order = [r.path for r in main.app.routes if getattr(r, "path", "").startswith("/leads")]
    for p in ("/leads/letters", "/leads/{lead_id}/letter.pdf", "/leads/{lead_id}/outreach/sent",
              "/leads/{lead_id}/outreach/unsent"):
        assert p in order, p
    assert order.index("/leads/letters") < order.index("/leads/{lead_id}")
    assert order.index("/leads/{lead_id}/letter.pdf") < order.index("/leads/{lead_id}")


def test_render_letters_produces_a_merged_pdf():
    from api.outreach import render_letters
    pdf = render_letters([{
        "owner_name": "Jane Doe", "property_address": "123 Main St",
        "neighborhood": "Madeira", "mailing_lines": ["456 Elm St, Cincinnati OH 45202"],
        "response_url": "http://localhost:8000/r/abc-123",
    }])
    assert pdf[:5] == b"%PDF-" and len(pdf) > 1000
    # batch of 2 is larger than 1 (a page each)
    two = render_letters([{"owner_name": "A", "response_url": "u"},
                          {"owner_name": "B", "response_url": "u"}])
    assert len(two) > len(pdf) - 5000  # sane lower bound; two letters render


def test_response_page_registered_and_public():
    paths = {r.path for r in main.app.routes}
    assert "/r/{token}" in paths


def test_response_page_html_puts_contact_front_and_center():
    from api.outreach import response_page_html
    contact = {"team": "Oyler Hines", "phone": "(513) 555-0100", "email": "team@oylerhines.com"}
    page = response_page_html("123 Main St", done=False, outcome=None, contact=contact)
    assert "Oyler Hines" in page
    assert "tel:5135550100" in page and "mailto:team@oylerhines.com" in page   # tap-to-contact
    assert 'value="positive"' in page and 'value="negative"' in page           # yes/no
    assert "123 Main St" in page
    done = response_page_html("123 Main St", done=True, outcome="positive", contact=contact)
    assert "Thank you" in done and "tel:5135550100" in done                    # contact stays


def test_audit_routes_registered():
    paths = {r.path for r in main.app.routes}
    for p in ("/audit/precision", "/audit/queue", "/audit/search", "/audit/label"):
        assert p in paths, p


def test_lead_filters_default_hides_junk_not_low_scores():
    # filter-first: the score is no longer a gate. Junk classes (not-acquirable,
    # condo, satellite, ...) are hidden via the stored constraints, but a real
    # low-scoring lot still passes so a realtor can find it by their own criteria.
    where, params = main._lead_filters({})
    sql = " ".join(where)
    assert "jsonb_exists_any" in sql
    assert params["hidden"] == main._HIDDEN_CLASSES
    assert "s.opportunity_score > 0" not in sql   # no score gate anymore
    assert "min_score" not in params


def test_lead_filters_min_score_is_optional_overlay():
    # a min_score only constrains when asked for (scoring toggled on)...
    where, params = main._lead_filters({"min_score": 50})
    assert "s.opportunity_score >= :min_score" in " ".join(where) and params["min_score"] == 50
    # ...and show_all suppresses it (ignore the ranking entirely)
    w2, _ = main._lead_filters({"min_score": 50, "show_all": True})
    assert "s.opportunity_score >= :min_score" not in " ".join(w2)


def test_lead_filters_include_hidden_drops_the_junk_gate():
    where, _ = main._lead_filters({"include_hidden": True})
    assert "jsonb_exists_any" not in " ".join(where)


def test_lead_filters_new_vocabulary():
    where, params = main._lead_filters({
        "land_use": "single_family", "min_land_share": 40, "max_land_share": 90,
        "out_of_state": True, "min_building_value": 1000, "min_home_sqft": 800,
        "has_code_violation": True, "landbank": True, "exclude_flood": True,
        "exclude_recent_permit": True, "min_units": 2,
    })
    sql = " ".join(where)
    assert "BETWEEN 510 AND 519" in sql                       # land-use bucket
    assert ":min_ls" in sql and abs(params["min_ls"] - 0.40) < 1e-9   # % -> ratio
    assert ":max_ls" in sql and abs(params["max_ls"] - 0.90) < 1e-9
    assert "substring(m.owner_mailing_addr" in sql            # out-of-state owner
    # homestead (senior 65+/disabled) predicate
    assert "m.homestead = true" in " ".join(main._lead_filters({"homestead": True})[0])
    # "diamond in the rough": worse-than-block gap folded with area value
    cw, cp = main._lead_filters({"min_condition_gap": 40, "min_area_value": 150000})
    csql = " ".join(cw)
    assert "m.condition_gap >= :min_cg" in csql and cp["min_cg"] == 40
    assert "m.area_land_value >= :min_av" in csql and cp["min_av"] == 150000
    assert main._SORT_EXPR["condition_gap"] == "m.condition_gap"
    assert "m.improvement_value >= :min_bv" in sql
    assert "m.home_sqft >= :min_hs" in sql
    assert "signal_type = 'code_violation'" in sql
    assert "signal_type = 'landbank_inventory'" in sql
    assert "m.flood_flag,false) = false" in sql
    assert "development_permits" in sql                       # exclude recent permit
    assert "m.num_units >= :min_u" in sql


def test_utility_infrastructure_filters():
    """Sewer/water: 'septic' means a known private system (no sanitary
    sewer); 'sewer' means absent from the septic inventory, so NULL must count as
    not-septic (COALESCE) rather than dropping the parcel."""
    w, _ = main._lead_filters({"sewer_status": "septic"})
    assert "m.on_septic = true" in " ".join(w)
    w2, _ = main._lead_filters({"sewer_status": "sewer"})
    assert "COALESCE(m.on_septic, false) = false" in " ".join(w2)
    w3, p3 = main._lead_filters({"max_water_ft": 300})
    usql = " ".join(w3)
    assert "m.water_main_ft <= :max_wft" in usql and p3["max_wft"] == 300


def test_lead_filters_exact_data_predicates():
    where, params = main._lead_filters({
        "owner_type": "trust", "owner_name": "smith", "has_tax_lien": True,
        "min_land_value": 5000, "transferred_since": "2023-01-01",
    })
    sql = " ".join(where)
    assert "m.owner_type = :owner_type" in sql and params["owner_type"] == "trust"
    assert "m.owner_name_raw ILIKE :owner_name" in sql and params["owner_name"] == "%smith%"
    assert "signal_type = 'tax_delinquent'" in sql
    assert "m.land_value >= :min_lv" in sql and params["min_lv"] == 5000
    # recent transfer excludes the corrupted future sale dates
    assert "m.last_sale_date <= CURRENT_DATE" in sql


def test_leads_export_route_precedes_catchall():
    """/leads/export must be registered before /leads/{lead_id}, or 'export' is
    swallowed as a lead id."""
    order = [r.path for r in main.app.routes if getattr(r, "path", "").startswith("/leads")]
    assert "/leads/export" in order and "/leads/{lead_id}" in order
    assert order.index("/leads/export") < order.index("/leads/{lead_id}")


def test_land_use_label_maps_dte_classes():
    assert main._land_use_label("510") == "Single-family"
    assert main._land_use_label("500") == "Vacant land"
    assert main._land_use_label("520") == "2-4 family"
    assert main._land_use_label("404") == "Commercial"
    assert main._land_use_label(None) == "" and main._land_use_label("") == ""


def test_parcel_search_route_precedes_catchall():
    """/parcels/search and /parcels/{id}/geojson must be registered before the
    /parcels/{parcel_id} catch-all, or 'search' is swallowed as a parcel id."""
    order = [r.path for r in main.app.routes if getattr(r, "path", "").startswith("/parcels")]
    assert "/parcels/search" in order and "/parcels/{parcel_id}/geojson" in order
    assert order.index("/parcels/search") < order.index("/parcels/{parcel_id}")
    assert order.index("/parcels/{parcel_id}/geojson") < order.index("/parcels/{parcel_id}")


def test_ownership_source_filters():
    # the Oyler Hines acquisition-source filters build the right predicates
    where, params = main._lead_filters({
        "owned_years_min": 30, "bank_owned": True, "cmha_owned": True, "port_owned": True,
    })
    sql = " ".join(where)
    assert "make_interval(years => :oy)" in sql and params["oy"] == 30
    assert "m.owner_name_raw ~* :bank_re" in sql and params["bank_re"] == main._BANK_RE
    assert "m.owner_name_raw ~* :cmha_re" in sql
    assert "m.owner_name_raw ~* :port_re" in sql
    # existing filters must still coexist (kept per the team's request)
    w2, p2 = main._lead_filters({"owner_type": "trust", "has_tax_lien": True, "owned_years_min": 20})
    s2 = " ".join(w2)
    assert "m.owner_type = :owner_type" in s2 and "signal_type = 'tax_delinquent'" in s2
    assert "make_interval" in s2 and p2["oy"] == 20


def test_bank_pattern_excludes_surnames():
    # a naive "\bBANK\b" would catch "BANK DANNY W"; the curated pattern requires
    # institution markers. (\y is Postgres's word boundary -> \b for Python re.)
    import re
    rx = re.compile(main._BANK_RE.replace(r"\y", r"\b"), re.IGNORECASE)
    assert rx.search("BANK OF AMERICA NATIONAL ASSOCIATION")
    assert rx.search("FIFTH THIRD BANK")
    assert not rx.search("BANK DANNY W & LISA G")


def test_target_region_scoping_when_no_region():
    # with no region chosen, the app scopes to the team's target markets
    where, params = main._lead_filters({})
    sql = " ".join(where)
    assert "m.neighborhood = ANY(:targets)" in sql
    assert "Madeira" in params["targets"]
    # an explicit region overrides the scope (no ANY clause)
    where2, _ = main._lead_filters({"neighborhood": "Oakley"})
    assert "m.neighborhood = :neighborhood" in " ".join(where2)
    assert "ANY(:targets)" not in " ".join(where2)
