"""Guards on who the API thinks you are.

Every lead, note, photo and preference is scoped by `current_user()`, so this one
function is the whole access-control surface. The rule it enforces: Cloudflare
Access's header is the only identity trusted by default, and anything else is a
401 rather than a shared login. Import-only, no DB.
"""
from __future__ import annotations

import pytest
from fastapi import HTTPException

from api import main


class _Req:
    """Minimal stand-in for starlette's Request — current_user only reads headers."""
    def __init__(self, **headers):
        self.headers = {k.lower().replace("_", "-"): v for k, v in headers.items()}


def _with_dev_auth(monkeypatch, on: bool):
    """Settings is a frozen dataclass, so swap in a modified copy rather than
    mutating it — current_user imports `settings` at call time, so the module
    attribute is what it sees."""
    import dataclasses

    import config
    monkeypatch.setattr(config, "settings", dataclasses.replace(
        config.settings, dev_auth=on, dev_user_email="dev@local"))


def test_access_header_is_the_identity(monkeypatch):
    """The header Cloudflare Access injects after authenticating against the
    allow-list. Trusted in both modes — it is the production path."""
    for mode in (True, False):
        _with_dev_auth(monkeypatch, mode)
        req = _Req(cf_access_authenticated_user_email="bill@oylerhines.com")
        assert main.current_user(req) == "bill@oylerhines.com"


def test_no_identity_fails_closed_in_production(monkeypatch):
    """THE bug this module exists to prevent. The old code fell through to a
    shared dev identity, so an app exposed without Access signed every visitor in
    as the same user — each of them seeing and editing everyone's leads. With
    DEV_AUTH off there is no fallback: no Access header means 401."""
    _with_dev_auth(monkeypatch, False)
    with pytest.raises(HTTPException) as e:
        main.current_user(_Req())
    assert e.value.status_code == 401


def test_x_user_email_is_ignored_in_production(monkeypatch):
    """A caller sets this header themselves, so honouring it in production lets
    anyone impersonate any agent by typing their address. It must not be a way
    past Access even when Access is missing."""
    _with_dev_auth(monkeypatch, False)
    with pytest.raises(HTTPException) as e:
        main.current_user(_Req(x_user_email="bill@oylerhines.com"))
    assert e.value.status_code == 401


def test_a_spoofed_header_cannot_override_access(monkeypatch):
    """Access forwards client headers rather than stripping them, so a request
    can arrive carrying BOTH. The authenticated one has to win in either mode."""
    for mode in (True, False):
        _with_dev_auth(monkeypatch, mode)
        req = _Req(cf_access_authenticated_user_email="real@oylerhines.com",
                   x_user_email="attacker@example.com")
        assert main.current_user(req) == "real@oylerhines.com"


def test_dev_auth_keeps_local_development_working(monkeypatch):
    """Opting in restores the convenience: per-user testing via X-User-Email, and
    a default identity so the app is usable with no headers at all."""
    _with_dev_auth(monkeypatch, True)
    assert main.current_user(_Req(x_user_email="agent2@test")) == "agent2@test"
    assert main.current_user(_Req()) == "dev@local"


def test_dev_auth_defaults_off_so_a_deploy_fails_closed(monkeypatch):
    """An operator who never sets DEV_AUTH — or fat-fingers the value — must get
    the SAFE behaviour. A default of true, or a permissive parse, would put the
    hole back on every deploy that forgets to override it."""
    from config import _envflag

    monkeypatch.delenv("DEV_AUTH", raising=False)
    assert _envflag("DEV_AUTH") is False, "unset must not enable dev auth"
    for raw in ("", "  ", "false", "0", "no", "off", "FALSE", "maybe", "True-ish"):
        monkeypatch.setenv("DEV_AUTH", raw)
        assert _envflag("DEV_AUTH") is False, raw
    for raw in ("1", "true", "TRUE", " yes ", "on"):
        monkeypatch.setenv("DEV_AUTH", raw)
        assert _envflag("DEV_AUTH") is True, raw
