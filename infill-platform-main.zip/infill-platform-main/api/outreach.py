"""Print-ready outreach-letter PDFs — the physical mailer that introduces the
Oyler Hines team, merged with a parcel's owner + mailing address, and carrying a
QR code + short link to the digital response page. Copy lives in
`api/letter_template.py`; this module owns layout only (reportlab).
"""
from __future__ import annotations

import html as _html
import io
import os
from datetime import date

_ASSETS = os.path.join(os.path.dirname(__file__), "assets")
_NAVY = "#12395b"
_TEAL = "#29a9c9"


def _img(path: str, width: float):
    """A reportlab Image scaled to `width`, preserving aspect ratio."""
    from reportlab.lib.utils import ImageReader
    from reportlab.platypus import Image
    iw, ih = ImageReader(path).getSize()
    return Image(path, width=width, height=width * ih / iw)


def response_page_html(address, done: bool, outcome, contact: dict) -> str:
    """The public response page an owner reaches by scanning the letter's QR / short
    link. Deliberately simple and mobile-first, with the Oyler Hines contact info
    front and centre (call / email buttons at the top and in the footer), plus a
    one-tap yes/no. `contact` is the letter template's SENDER dict."""
    team = _html.escape(contact.get("team", "Oyler Hines"))
    phone = _html.escape(contact.get("phone", ""))
    email = _html.escape(contact.get("email", ""))
    tel = "".join(c for c in phone if c.isdigit() or c == "+")
    addr = _html.escape(address) if address else None

    contact_block = (
        f'<div class="contact">'
        f'<a class="btn call" href="tel:{tel}">📞 Call {phone}</a>'
        f'<a class="btn email" href="mailto:{email}">✉ Email us</a>'
        f'</div>')

    if done:
        msg = ("Thanks — we've got your response and someone from our team will reach "
               "out soon." if outcome == "positive"
               else "Understood — thanks for letting us know. If anything changes, "
               "we're always here.")
        inner = f"<h1>Thank you</h1><p>{msg}</p>{contact_block}"
    else:
        about = f"about your property at <b>{addr}</b>" if addr else "from our team"
        inner = (
            f"<h1>Interested in your property?</h1>"
            f"<p>Thanks for reaching out {about}. We'd love to talk — there is no "
            f"obligation at all.</p>{contact_block}"
            f'<form method="post" class="respond">'
            f'<button class="btn yes" name="outcome" value="positive">👍 Yes, I\'d like to talk</button>'
            f'<button class="btn no" name="outcome" value="negative">Not interested</button>'
            f"</form>")

    return f"""<!doctype html><html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{team}</title><style>
 body {{ margin:0; font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;
   background:#0f172a; color:#0f172a; display:flex; min-height:100vh; align-items:center;
   justify-content:center; padding:20px; box-sizing:border-box; }}
 .card {{ background:#fff; border-radius:16px; max-width:420px; width:100%; padding:28px;
   box-shadow:0 10px 40px rgba(0,0,0,.35); text-align:center; }}
 .brand {{ font-size:26px; font-weight:800; letter-spacing:-.5px; }}
 .sub {{ color:#64748b; font-size:13px; margin-bottom:18px; }}
 h1 {{ font-size:20px; margin:14px 0 8px; }}
 p {{ color:#334155; line-height:1.5; }}
 .contact {{ display:flex; flex-direction:column; gap:10px; margin:18px 0; }}
 .btn {{ display:block; width:100%; padding:14px; border-radius:10px; font-size:16px;
   font-weight:700; text-decoration:none; border:none; cursor:pointer; box-sizing:border-box; }}
 .btn.call {{ background:#16a34a; color:#fff; }}
 .btn.email {{ background:#f1f5f9; color:#0f172a; }}
 .respond {{ display:flex; flex-direction:column; gap:10px; margin-top:6px; }}
 .btn.yes {{ background:#2563eb; color:#fff; }}
 .btn.no {{ background:transparent; color:#64748b; font-weight:600; }}
 .foot {{ margin-top:20px; color:#94a3b8; font-size:12px; }}
</style></head><body><div class="card">
 <div class="brand">{team}</div><div class="sub">Real Estate · Cincinnati</div>
 {inner}
 <div class="foot">{phone} · {email}</div>
</div></body></html>"""


def _qr_image(url: str, size_pt: float = 96):
    import qrcode
    from reportlab.platypus import Image
    img = qrcode.make(url)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    return Image(buf, width=size_pt, height=size_pt)


def _story(ctx: dict):
    """The flowables for one Oyler Hines letter. ctx: owner_name, property_address,
    response_url (the QR target — the team website). Matches the team's template:
    greeting, body, three options, sign-off, then Bill's bio with a QR beside it,
    and the wire-fraud + LOI disclosures in small print."""
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import inch
    from reportlab.platypus import (ListFlowable, ListItem, Paragraph, Spacer,
                                    Table, TableStyle)

    from api import letter_template as T

    base = getSampleStyleSheet()["Normal"]
    body = ParagraphStyle("body", parent=base, fontSize=10.5, leading=14, spaceAfter=8)
    bull = ParagraphStyle("bull", parent=base, fontSize=10.5, leading=13.5, spaceAfter=3)
    sig = ParagraphStyle("sig", parent=base, fontSize=10, leading=13)
    signame = ParagraphStyle("signame", parent=base, fontSize=11, leading=15, fontName="Helvetica-Bold")
    cap = ParagraphStyle("cap", parent=base, fontSize=7.5, leading=9, alignment=1, textColor="#555555")
    tiny = ParagraphStyle("tiny", parent=base, fontSize=6, leading=7.4, textColor="#8a8a8a", spaceAfter=3)

    signame.textColor = _NAVY
    link = ParagraphStyle("link", parent=sig, textColor=_TEAL)

    def fmt(s: str) -> str:
        return s.format(owner_name=ctx.get("owner_name") or "Neighbor",
                        property_address=ctx.get("property_address") or "your property")

    s = []
    # letterhead: the Coldwell Banker + Oyler Hines lockup, centered
    header = _img(os.path.join(_ASSETS, "header_logo.png"), 2.15 * inch)
    header.hAlign = "CENTER"
    s.append(header)
    s.append(Spacer(1, 12))

    d = date.today()
    s.append(Paragraph(f"{d:%B} {d.day}, {d.year}", body))
    s.append(Spacer(1, 6))
    s.append(Paragraph(fmt(T.GREETING), body))
    for para in T.BODY_BEFORE:
        s.append(Paragraph(fmt(para), body))
    s.append(ListFlowable(
        [ListItem(Paragraph(fmt(b), bull), leftIndent=8) for b in T.BULLETS],
        bulletType="bullet", start="•", leftIndent=16))
    s.append(Spacer(1, 6))
    for para in T.BODY_AFTER:
        s.append(Paragraph(fmt(para), body))
    s.append(Spacer(1, 10))

    # signature: Bill's photo | his bio (name in brand navy/teal) | QR to the site
    from reportlab.platypus import Image
    photo = Image(os.path.join(_ASSETS, "bill_round.png"), width=0.95 * inch, height=0.95 * inch)
    bio = [
        Paragraph(f'<font color="{_NAVY}">BILL</font> <font color="{_TEAL}">HINES</font>', signame),
        Paragraph(T.SENDER["title"], sig),
        Paragraph(T.SENDER["team"], sig),
        Paragraph(f'{T.SENDER["phone"]} · {T.SENDER["email"]}', sig),
        Paragraph(T.SENDER["website"], link),
        Paragraph(T.SENDER["address"], sig),
    ]
    qr_cell = [_qr_image(ctx.get("response_url", ""), 76),
               Spacer(1, 2), Paragraph("Scan to visit<br/>oylerhines.com", cap)]
    sigtbl = Table([[photo, bio, qr_cell]], colWidths=[1.1 * inch, 3.25 * inch, 1.15 * inch])
    sigtbl.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"),
                                ("LEFTPADDING", (0, 0), (0, 0), 0),
                                ("ALIGN", (2, 0), (2, 0), "CENTER"),
                                ("TOPPADDING", (0, 0), (0, 0), 2)]))
    s.append(sigtbl)

    # footer brand logos, then the wire-fraud + LOI small print
    s.append(Spacer(1, 8))
    foot = _img(os.path.join(_ASSETS, "footer_logos.png"), 1.15 * inch)
    foot.hAlign = "LEFT"
    s.append(foot)
    s.append(Spacer(1, 6))
    for disc in T.DISCLOSURES:
        s.append(Paragraph(disc, tiny))
    return s


def _fmt_ctx(s: str, ctx: dict) -> str:
    """Merge one template string against a letter context."""
    return s.format(owner_name=ctx.get("owner_name") or "Neighbor",
                    property_address=ctx.get("property_address") or "your property")


def render_letters_docx(ctxs: list[dict]) -> bytes:
    """The same letter as an EDITABLE Word document — so the team can adjust a
    name, tweak a sentence, or personalise a line before printing.

    Mirrors the PDF layout: letterhead, date, greeting, body, the three options
    as real bullets, then Bill's photo + bio + QR side by side, and the
    disclosures in small print. One letter per page.
    """
    from docx import Document
    from docx.enum.section import WD_SECTION
    from docx.enum.table import WD_TABLE_ALIGNMENT
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.shared import Inches, Pt, RGBColor

    from api import letter_template as T

    doc = Document()
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Inches(8.5), Inches(11)   # US Letter, explicit
    sec.top_margin, sec.bottom_margin = Inches(0.55), Inches(0.5)
    sec.left_margin = sec.right_margin = Inches(1)
    normal = doc.styles["Normal"]
    normal.font.name = "Calibri"
    normal.font.size = Pt(10.5)

    def para(text="", size=10.5, bold=False, color=None, space_after=8, align=None):
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(space_after)
        p.paragraph_format.space_before = Pt(0)
        if align is not None:
            p.alignment = align
        if text:
            r = p.add_run(text)
            r.font.size, r.bold = Pt(size), bold
            if color:
                r.font.color.rgb = color
        return p

    navy, teal = RGBColor(0x12, 0x39, 0x5B), RGBColor(0x29, 0xA9, 0xC9)

    for i, ctx in enumerate(ctxs):
        if i:
            doc.add_page_break()

        logo = os.path.join(_ASSETS, "header_logo.png")
        if os.path.exists(logo):
            p = para(space_after=10, align=WD_ALIGN_PARAGRAPH.CENTER)
            p.add_run().add_picture(logo, width=Inches(2.15))

        d = date.today()
        para(f"{d:%B} {d.day}, {d.year}")
        para(_fmt_ctx(T.GREETING, ctx))
        for block in T.BODY_BEFORE:
            para(_fmt_ctx(block.replace("&amp;", "&"), ctx))
        for b in T.BULLETS:
            bp = doc.add_paragraph(style="List Bullet")   # real bullets, not a "•" char
            bp.paragraph_format.space_after = Pt(3)
            bp.add_run(_fmt_ctx(b, ctx)).font.size = Pt(10.5)
        for block in T.BODY_AFTER:
            para(_fmt_ctx(block, ctx))

        # signature: photo | bio | QR. Explicit widths on the table AND every cell.
        tbl = doc.add_table(rows=1, cols=3)
        tbl.alignment = WD_TABLE_ALIGNMENT.LEFT
        widths = (Inches(1.1), Inches(3.25), Inches(1.15))
        tbl.autofit = False
        for cell, w in zip(tbl.rows[0].cells, widths):
            cell.width = w
        photo_cell, bio_cell, qr_cell = tbl.rows[0].cells

        headshot = os.path.join(_ASSETS, "bill_round.png")
        if os.path.exists(headshot):
            photo_cell.paragraphs[0].add_run().add_picture(headshot, width=Inches(0.95))

        name_p = bio_cell.paragraphs[0]
        name_p.paragraph_format.space_after = Pt(0)
        r1 = name_p.add_run("BILL "); r1.bold = True; r1.font.color.rgb = navy; r1.font.size = Pt(11)
        r2 = name_p.add_run("HINES"); r2.bold = True; r2.font.color.rgb = teal; r2.font.size = Pt(11)
        for line, col in ((T.SENDER["title"], None), (T.SENDER["team"], None),
                          (f'{T.SENDER["phone"]} · {T.SENDER["email"]}', None),
                          (T.SENDER["website"], teal), (T.SENDER["address"], None)):
            lp = bio_cell.add_paragraph()
            lp.paragraph_format.space_after = Pt(0)
            lr = lp.add_run(line); lr.font.size = Pt(10)
            if col:
                lr.font.color.rgb = col

        qp = qr_cell.paragraphs[0]
        qp.alignment = WD_ALIGN_PARAGRAPH.CENTER
        qr_png = io.BytesIO()
        _qr_pil(ctx.get("response_url", "")).save(qr_png, format="PNG")
        qr_png.seek(0)
        qp.add_run().add_picture(qr_png, width=Inches(1.0))
        cap = qr_cell.add_paragraph()
        cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
        cr = cap.add_run("Scan to visit\noylerhines.com".replace("\n", " "))
        cr.font.size = Pt(7.5); cr.font.color.rgb = RGBColor(0x55, 0x55, 0x55)

        foot = os.path.join(_ASSETS, "footer_logos.png")
        if os.path.exists(foot):
            p = para(space_after=6)
            p.add_run().add_picture(foot, width=Inches(1.15))
        for disc in T.DISCLOSURES:
            para(disc.replace("&amp;", "&"), size=6, space_after=3,
                 color=RGBColor(0x8A, 0x8A, 0x8A))

    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()


def _qr_pil(url: str):
    """QR as a PIL image (the docx path needs the image, not a reportlab flowable)."""
    import qrcode
    return qrcode.make(url)


def render_letters(ctxs: list[dict]) -> bytes:
    """One PDF, one letter per ctx (page break between) — for printing a stack."""
    from reportlab.lib.pagesizes import letter as LETTER
    from reportlab.lib.units import inch
    from reportlab.platypus import PageBreak, SimpleDocTemplate

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=LETTER, title="Outreach letters",
                            topMargin=0.55 * inch, bottomMargin=0.5 * inch,
                            leftMargin=1 * inch, rightMargin=1 * inch)
    flow: list = []
    for i, ctx in enumerate(ctxs):
        if i:
            flow.append(PageBreak())
        flow.extend(_story(ctx))
    doc.build(flow)
    return buf.getvalue()
