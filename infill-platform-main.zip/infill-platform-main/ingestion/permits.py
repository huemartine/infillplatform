"""New-construction building permits (Cincinnati Socrata uhjb-xac9).

    python -m ingestion.permits [--since 2019-01-01]

Loads permits where workclassmapped='New' and permittypemapped='Building' (an
actual new structure) since a cutoff, resolving each permit's `pin` to the
canonical parcel_id. Used as the development outcome for scoring/backtest.py.
"""
from __future__ import annotations

import argparse

from ingestion.common import HttpClient
from ingestion.resolve import canonical_parcel_id

_BASE = "https://data.cincinnati-oh.gov/resource/uhjb-xac9.json"
_PAGE = 5000


def build(since: str = "2019-01-01") -> dict:
    from sqlalchemy import text

    from config import settings
    from ingestion.load import _engine

    headers = {"User-Agent": "infill-platform/0.1"}
    if settings.socrata_app_token:
        headers["X-App-Token"] = settings.socrata_app_token
    http = HttpClient(min_interval_s=0.2, headers=headers)

    where = (f"workclassmapped='New' AND permittypemapped='Building' "
             f"AND issueddate > '{since}T00:00:00'")
    stmt = text("""
        INSERT INTO development_permits (permit_num, parcel_id, work_class, permit_type,
            proposed_use, issued_date, est_cost, units, address, neighborhood)
        VALUES (:permit_num, :parcel_id, :work_class, :permit_type, :proposed_use,
                :issued_date, :est_cost, :units, :address, :neighborhood)
        ON CONFLICT (permit_num) DO UPDATE SET parcel_id = EXCLUDED.parcel_id,
            issued_date = EXCLUDED.issued_date, est_cost = EXCLUDED.est_cost
    """)

    offset, total, matched = 0, 0, 0
    eng = _engine()
    while True:
        rows = http.get(_BASE, params={
            "$where": where, "$order": "permitnum", "$limit": _PAGE, "$offset": offset,
        }).json()
        if not rows:
            break
        batch = []
        for r in rows:
            pid = canonical_parcel_id((r.get("pin") or "").strip('"'))
            if pid:
                matched += 1
            batch.append({
                "permit_num": r.get("permitnum"),
                "parcel_id": pid,
                "work_class": r.get("workclassmapped"),
                "permit_type": r.get("permittypemapped"),
                "proposed_use": (r.get("proposeduse") or "").strip('"') or None,
                "issued_date": (r.get("issueddate") or "")[:10] or None,
                "est_cost": _num(r.get("estprojectcostdec")),
                "units": _num(r.get("units")),
                "address": r.get("originaladdress1"),
                "neighborhood": r.get("neighborhood"),
            })
        with eng.begin() as conn:
            conn.execute(stmt, batch)
        total += len(batch)
        offset += _PAGE
        if len(rows) < _PAGE:
            break
    # keep only permits that resolve to a parcel we actually score
    with eng.begin() as conn:
        conn.execute(text("""
            UPDATE development_permits d SET parcel_id = NULL
            WHERE parcel_id IS NOT NULL
              AND NOT EXISTS (SELECT 1 FROM parcel_master m WHERE m.parcel_id = d.parcel_id)
        """))
        joinable = conn.execute(text(
            "SELECT count(*) FROM development_permits WHERE parcel_id IS NOT NULL")).scalar()
    summary = {"permits": total, "with_pin": matched, "joined_to_parcel": joinable}
    print(f"permits loaded: {summary}", flush=True)
    return summary


def _num(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--since", default="2019-01-01")
    build(ap.parse_args().since)


if __name__ == "__main__":
    main()
