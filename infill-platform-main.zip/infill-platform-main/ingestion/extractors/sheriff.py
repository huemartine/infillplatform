"""Hamilton County sheriff-sale extractor (Section 5.5) — upcoming foreclosure
auctions from the RealAuction platform (hamilton.sheriffsaleauction.ohio.gov).

Recon notes (verified live 2026-07-07):
  - The site 403s non-browser user agents; a browser UA string is required.
  - Auctions run weekly on Wednesdays. A date's PREVIEW page
    (?zaction=AUCTION&Zmethod=PREVIEW&AUCTIONDATE=mm/dd/yyyy) renders a shell and
    carries prev/next auction links; a non-auction date renders an empty shell
    (no BLHeaderDateDisplay), which is how discovery tells them apart.
  - Auction items load via a session-scoped AJAX endpoint
    (?zaction=AUCTION&Zmethod=UPDATE&FNC=LOAD&AREA=W) returning JSON:
    {retHTML: <templated item markup>, rlist: "aid,aid,..."}. The PREVIEW GET
    must precede the loader call (the session cookie pins the auction date).
  - Item markup carries Case Status / Case # / Parcel ID / address / Appraised
    Value / Opening Bid. Parcel IDs are dash-formatted book-page-parcel
    ("211-69-41"), zero-padded 3+4+4 to the Auditor's 11-char form
    ("21100690041") — verified against parcel_master.
  - Scrape etiquette: ~1 req/sec, a dozen requests per weekly run.

Signals: signal_type='sheriff_sale', event_date=auction date (future; decay
clamps to 1.0), severity=opening bid $, raw_ref=case number (stable across
re-scrapes; upsert refreshes status/date on adjournments).
"""
from __future__ import annotations

import json
import re
from datetime import date, datetime, timedelta
from typing import Iterator, Optional

import pandas as pd

from ..base import Extractor, RawBatch, Resource
from ..common import HttpClient

_BASE = "https://hamilton.sheriffsaleauction.ohio.gov"
_BROWSER_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
               "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36")
_PROBE_DAYS = 70        # probe window for upcoming auction Wednesdays
_MAX_AUCTIONS = 8       # cap on auction days per run
_MAX_PAGES = 20         # loader pagination cap per auction day


class SheriffSaleExtractor(Extractor):
    source_id = "sheriff_sale"
    target = "signals"
    resolves_parcels = True  # normalize emits canonical parcel_id directly (tier 1)

    def __init__(self, base: str = _BASE):
        self._base = base.rstrip("/")
        self._http = HttpClient(min_interval_s=1.0, headers={"User-Agent": _BROWSER_UA})

    # -- discovery: probe upcoming Wednesdays directly. (The site's own
    # Next-Auction links are unreliable — observed pointing 6 months backwards
    # on a zero-item day — so link-walking is out.) --------------------------

    def discover(self) -> list[Resource]:
        dates = []
        for i in range(_PROBE_DAYS):
            day = date.today() + timedelta(days=i)
            if day.weekday() != 2:  # auctions run Wednesdays
                continue
            if "BLHeaderDateDisplay" in self._preview(day):
                dates.append(day)
            if len(dates) >= _MAX_AUCTIONS:
                break
        return [Resource(
            source_id=self.source_id, name=f"auction_{d:%Y%m%d}",
            url=f"{self._base}/index.cfm", kind="scrape",
            params={"auction_date": d.isoformat()},
        ) for d in dates]

    def _preview(self, day: date) -> str:
        return self._http.get(
            f"{self._base}/index.cfm",
            params={"zaction": "AUCTION", "Zmethod": "PREVIEW",
                    "AUCTIONDATE": f"{day:%m/%d/%Y}"}).text

    # -- extraction: session-scoped loader, paged until no new items ----------

    def extract(self, resource: Resource, since: Optional[datetime]) -> Iterator[RawBatch]:
        day = date.fromisoformat(resource.params["auction_date"])
        self._preview(day)  # pin the session to this auction date
        seen: set[str] = set()
        pages = []
        for page in range(_MAX_PAGES):
            body = self._http.get(
                f"{self._base}/index.cfm",
                params={"zaction": "AUCTION", "Zmethod": "UPDATE", "FNC": "LOAD",
                        "AREA": "W", "PageDir": 0 if page == 0 else 1, "doR": 0}
            ).text.strip()
            try:
                data = json.loads(body)
            except json.JSONDecodeError:
                break
            ids = [i for i in (data.get("rlist") or "").split(",") if i]
            new = [i for i in ids if i not in seen]
            if not new:
                break
            seen.update(new)
            pages.append({"auction_date": day.isoformat(),
                          "retHTML": data.get("retHTML", ""), "rlist": ids})
        if pages:
            yield RawBatch(resource=resource, records=pages, page=0)

    # -- normalization: parse templated markup into signal rows ---------------

    def normalize(self, batch: RawBatch) -> pd.DataFrame:
        rows = []
        for page in batch.records:
            for item in _split_items(page["retHTML"]):
                case_no = _field(item, "Case #")
                parcel_raw = _field(item, "Parcel ID")
                parcel_id = sheriff_parcel_to_canonical(parcel_raw)
                if not case_no or not parcel_id:
                    continue
                rows.append({
                    "parcel_id": parcel_id,
                    "raw_ref": case_no.split(" ")[0],   # base case number, stable
                    "signal_type": "sheriff_sale",
                    "event_date": page["auction_date"],
                    "status": _field(item, "Case Status") or "SCHEDULED",
                    "severity": _dollars(_field(item, "Opening Bid")),
                    "source": self.source_id,
                    "address": _field(item, "Property Address"),
                    "appraised": _dollars(_field(item, "Appraised Value")),
                })
        return pd.DataFrame(rows)


def sheriff_parcel_to_canonical(raw: Optional[str]) -> Optional[str]:
    """'211-69-41' -> '21100690041' (book 3 + page 4 + parcel 4, zero-padded).
    Verified against parcel_master. Returns None if the shape doesn't fit."""
    if not raw:
        return None
    parts = raw.strip().split("-")
    if len(parts) != 3 or not all(p.isdigit() for p in parts):
        return None
    book, page, parcel = parts
    if len(book) > 3 or len(page) > 4 or len(parcel) > 4:
        return None
    return book.zfill(3) + page.zfill(4) + parcel.zfill(4)


def _split_items(ret_html: str) -> list[str]:
    chunks = re.split(r'id="AITEM_\d+"', ret_html)
    return chunks[1:]  # first chunk precedes any item


def _field(item_html: str, label: str) -> Optional[str]:
    # templated markup: <th ...>Label:</th><td @CAD_DTA\">value@G
    m = re.search(re.escape(label) + r':</th><td[^>]*>\s*([^@<]*)', item_html)
    if not m:
        return None
    value = m.group(1).strip().rstrip(",")
    return value or None


def _dollars(v: Optional[str]) -> Optional[float]:
    if not v:
        return None
    try:
        return float(v.replace("$", "").replace(",", ""))
    except ValueError:
        return None
