"""CAGIS parcel extractor — the base spatial layer (Section 5.1).

Discovery resolved the spec-preferred source: the hosted **FeatureServer**
"Hamilton County Parcels - Open Data" (Open_Data/FeatureServer/51), which the
spec prefers over a MapServer and which conveniently carries both parcel geometry
*and* Auditor attributes (market land/improvement value, ownership, sale history,
tax-delinquency and foreclosure flags). That lets the underutilization MVP run
off one authoritative county source.

Notes from the spec baked in:
  - Prefer FeatureServer over MapServer; page with resultOffset/resultRecordCount
    (server caps at 2000; layer advertises supportsPagination=true).
  - Source SR is State Plane; request outSR=4326 on the wire.
  - parcel_id source-of-truth is the Auditor parcel number (AUDPCLID here).
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Iterator, Optional

import pandas as pd

from ..base import Extractor, RawBatch, Resource
from ..common import HttpClient, normalize_address, normalize_owner_name, paginate_offset
from ..resolve import canonical_parcel_id

_PAGE_SIZE = 2000

# Known-good hosted FeatureServer (resolved via ArcGIS search, owner=cagisopendata).
_OPEN_DATA_LAYER = (
    "https://services.arcgis.com/JyZag7oO4NteHGiq/arcgis/rest/services"
    "/Open_Data/FeatureServer/51"
)
# ArcGIS Online search fallback if the hosted layer id ever drifts.
_AGOL_SEARCH = "https://www.arcgis.com/sharing/rest/search"

# Attributes we pull (subset of 97). Names verified against the live layer.
_OUT_FIELDS = ",".join([
    "AUDPCLID", "PARCELID", "OWNNM1", "OWNNM2",
    "MLADR1", "OWNADCITY", "OWNADSTATE", "OWNADZIP",
    "ADDRNO", "ADDRST", "ADDRSF",
    "MKTLND", "MKTIMP", "MKT_TOTAL_VAL",
    "CLASS", "EXLUCODE", "NUM_UNITS", "ACREDEED",
    "SALDAT", "SALAMT", "CNTFLG", "FORECL_FLAG", "DELQ_TAXES", "NHBDNO",
    "HMSD_FLAG",   # Homestead Exemption: owner 65+ or permanently disabled
])


class CagisExtractor(Extractor):
    source_id = "cagis"

    def __init__(self, layer_url: Optional[str] = None):
        self._layer_url = (layer_url or _OPEN_DATA_LAYER).rstrip("/")
        self._http = HttpClient(min_interval_s=0.2,
                                headers={"User-Agent": "infill-platform/0.1"})

    def discover(self) -> list[Resource]:
        """Confirm the configured layer is live and query-able; if not, fall back
        to the ArcGIS search API rather than baking in a dead URL."""
        try:
            meta = self._http.get(self._layer_url, params={"f": "json"}).json()
            if meta.get("name"):
                return [self._resource(self._layer_url)]
        except Exception:
            pass
        results = self._http.get(_AGOL_SEARCH, params={
            "q": 'title:"Hamilton County Parcel" type:"Feature Service" owner:cagisopendata',
            "f": "json", "num": 5,
        }).json().get("results", [])
        url = next((r["url"] for r in results if r.get("url")), None)
        if not url:
            raise RuntimeError("Could not resolve a live CAGIS parcel FeatureServer")
        return [self._resource(url.rstrip("/"))]

    def _resource(self, layer_url: str) -> Resource:
        return Resource(source_id=self.source_id, name="cagis_parcels",
                        url=f"{layer_url}/query", kind="arcgis_feature",
                        params={"outFields": _OUT_FIELDS})

    def extract(self, resource: Resource, since: Optional[datetime]) -> Iterator[RawBatch]:
        base_params = {
            "where": "1=1",
            "outFields": resource.params.get("outFields", _OUT_FIELDS),
            "returnGeometry": "true",
            "outSR": 4326,          # reproject from State Plane on the wire
            "f": "geojson",
        }
        for page, records in enumerate(paginate_offset(
            self._http, resource.url, base_params,
            offset_key="resultOffset", count_key="resultRecordCount",
            page_size=_PAGE_SIZE,
            records_path=lambda body: body.get("features", []),
        )):
            yield RawBatch(resource=resource, records=records, page=page)

    def normalize(self, batch: RawBatch) -> pd.DataFrame:
        rows = [self._row(f) for f in batch.records]
        df = pd.DataFrame([r for r in rows if r is not None])
        return df

    def _row(self, feat: dict) -> Optional[dict]:
        p = feat.get("properties", {})
        parcel_id = canonical_parcel_id(p.get("AUDPCLID") or p.get("PARCELID"))
        if not parcel_id:
            return None
        land = _num(p.get("MKTLND"))
        imp = _num(p.get("MKTIMP"))
        site_addr = _join_addr(p.get("ADDRNO"), p.get("ADDRST"), p.get("ADDRSF"))
        owner_mail = p.get("MLADR1")
        return {
            "parcel_id": parcel_id,
            "address": site_addr,
            "address_norm": normalize_address(site_addr),
            "owner_name_raw": p.get("OWNNM1"),
            "owner_name_norm": normalize_owner_name(p.get("OWNNM1")),
            "owner_mailing_addr": _join_addr(owner_mail, p.get("OWNADCITY"),
                                             p.get("OWNADSTATE"), p.get("OWNADZIP")),
            # absentee: owner's mailing street differs from the site street
            "is_absentee": _is_absentee(site_addr, owner_mail),
            "owner_type": _owner_type(p.get("OWNNM1")),
            "land_value": land,
            "improvement_value": imp,
            "total_value": _num(p.get("MKT_TOTAL_VAL")),
            "il_ratio": round(imp / land, 4) if land else None,
            "land_use_code": _str(p.get("CLASS")),
            "num_units": _num(p.get("NUM_UNITS")),
            "acreage": _num(p.get("ACREDEED")),
            # None (unknown), not False: complexes book improvements on a few
            # deeds and leave satellite deeds NULL-valued — those aren't vacant
            "has_structure": (imp > 0) if imp is not None else None,
            "last_sale_date": _epoch_ms_to_date(p.get("SALDAT")),
            "last_sale_price": _num(p.get("SALAMT")),
            # Homestead Exemption -> owner is 65+ or permanently disabled (public,
            # exact-data proxy for a senior / likely-to-sell owner). 'Y'/'N'.
            "homestead": (str(p.get("HMSD_FLAG") or "").upper() == "Y"),
            "neighborhood": _str(p.get("NHBDNO")),
            # raw distress flags, carried through for signal derivation
            "_forecl_flag": p.get("FORECL_FLAG"),
            "_delq_taxes": _num(p.get("DELQ_TAXES")),
            "_cnt_flag": p.get("CNTFLG"),
            "geometry": feat.get("geometry"),
        }


def derive_signals(df: pd.DataFrame, asof: Optional[datetime] = None) -> pd.DataFrame:
    """Emit parcel_signals rows from CAGIS's own distress fields (foreclosure flag,
    tax delinquency). A legitimate early distress signal before the Phase 2 feeds
    (RealAuction, Clerk of Courts) land. event_date is the extract date since these
    are standing flags, not dated filings."""
    asof = (asof or datetime.now(timezone.utc)).date()
    out = []
    for _, r in df.iterrows():
        if str(r.get("_forecl_flag") or "").upper() == "Y":
            out.append(_signal(r["parcel_id"], "foreclosure_filing", asof, "cagis"))
        if (r.get("_delq_taxes") or 0) > 0:
            out.append(_signal(r["parcel_id"], "tax_delinquent", asof, "cagis",
                               severity=float(r["_delq_taxes"])))
    return pd.DataFrame(out)


def _signal(parcel_id, signal_type, event_date, source, severity=None) -> dict:
    return {"parcel_id": parcel_id, "signal_type": signal_type,
            "event_date": event_date, "status": "flag", "severity": severity,
            "source": source}


# --- small field helpers ---------------------------------------------------

def _num(v):
    try:
        return float(v) if v is not None else None
    except (TypeError, ValueError):
        return None


def _str(v):
    return None if v is None else str(v).strip() or None


def _join_addr(*parts) -> Optional[str]:
    joined = " ".join(str(p).strip() for p in parts if p not in (None, "", " "))
    return joined or None


def _epoch_ms_to_date(v):
    # County feeds carry sentinel/out-of-range epochs (0, negatives) and
    # mis-encoded values that land decades in the FUTURE (observed 2097-2099).
    # A recorded sale cannot be in the future, so the upper bound is 'now' (not a
    # fixed 2100) — this keeps the ~484 bogus future dates out of last_sale_date,
    # which otherwise masquerade as the most-recent transfers in date filters.
    try:
        secs = float(v) / 1000
    except (TypeError, ValueError):
        return None
    now = datetime.now(timezone.utc).timestamp()
    if not -631152000 <= secs <= now:  # ~1950-01-01 .. today
        return None
    try:
        return datetime.fromtimestamp(secs, tz=timezone.utc).date().isoformat()
    except (OSError, OverflowError, ValueError):
        return None


def _is_absentee(site_addr: Optional[str], owner_mail: Optional[str]) -> Optional[bool]:
    if not site_addr or not owner_mail:
        return None
    return normalize_address(site_addr) != normalize_address(owner_mail)


_INSTITUTIONAL_KEYWORDS = (
    "HOSPITAL", "MEDICAL CENTER", "HEALTH SYSTEM", "HEALTH ALLIANCE",
    "UNIVERSITY", "COLLEGE", "SEMINARY",
    "CHURCH", "CATHEDRAL", "CHAPEL", "TEMPLE", "SYNAGOGUE", "MOSQUE",
    "DIOCESE", "ARCHDIOCESE", "MINISTRIES",
    "CEMETERY", "RAILROAD", "RAILWAY", "TRANSIT AUTHORITY",
)


def _owner_type(name: Optional[str]) -> str:
    n = (name or "").upper()
    # public and institutional checks run BEFORE llc: "HAMILTON COUNTY LAND
    # REUTILIZATION CORPORATION" and "CHRIST HOSPITAL INC" must not read as llc
    if any(k in n for k in (
            "CITY OF", "COUNTY", "STATE OF", "LAND REUTIL", "PORT ", "AUTHORITY",
            "PARK BOARD", "BOARD OF PARK", "BD OF PARK", "PARK COMM",
            "BOARD OF EDUCATION", "BD OF EDUCATION", "SCHOOL DISTRICT",
            "UNITED STATES", "METROPOLITAN SEWER", "TOWNSHIP", "VILLAGE OF")):
        return "public"
    if any(k in n for k in _INSTITUTIONAL_KEYWORDS):
        return "institutional"
    if any(k in n for k in (" LLC", " INC", " CORP", " CO ", " LP", " LLP", " LTD")):
        return "llc"
    # Auditor style abbreviates trustee/trust as a trailing "TR" ("SMITH JANE TR")
    if "TRUST" in n or " TR " in n or n.endswith(" TR"):
        return "trust"
    return "individual"
