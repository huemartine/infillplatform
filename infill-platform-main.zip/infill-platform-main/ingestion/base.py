"""Ingestion contracts shared by every source.

Each source implements one `Extractor`. The interface is deliberately small:
`discover` resolves live endpoints (so we degrade gracefully when a county
service URL or Socrata dataset id changes), `extract` yields raw records in
pages since a watermark, and `normalize` maps a raw batch to a canonical
DataFrame keyed by `parcel_id`. Raw records are archived to S3 verbatim before
normalization, so every downstream value traces back to an immutable extract.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Iterator, Optional, Protocol, runtime_checkable

import pandas as pd


@dataclass(frozen=True)
class Resource:
    """A concrete, resolved endpoint to pull from (a layer URL, dataset id, etc.)."""

    source_id: str
    name: str
    url: str
    kind: str  # "arcgis_feature" | "socrata" | "csv" | "scrape" | "regrid"
    params: dict = field(default_factory=dict)


@dataclass
class RawBatch:
    """A page of raw records plus where it landed in the S3 archive."""

    resource: Resource
    records: list[dict]
    s3_path: Optional[str] = None
    page: int = 0


@runtime_checkable
class Extractor(Protocol):
    """One per source. Stateless; all run state lives in `ingest_runs`."""

    source_id: str

    def discover(self) -> list[Resource]:
        """Resolve live endpoints. Browse service directories / catalog APIs
        rather than baking URLs into code, so URL drift degrades gracefully."""
        ...

    def extract(self, resource: Resource, since: Optional[datetime]) -> Iterator[RawBatch]:
        """Yield raw records page by page from `since` (None => full backfill).
        Pagination/rate-limiting handled via ingestion.common."""
        ...

    def normalize(self, batch: RawBatch) -> pd.DataFrame:
        """Map a raw batch to a staging DataFrame with canonical column names
        and a resolvable `parcel_id`. No scoring logic here."""
        ...
