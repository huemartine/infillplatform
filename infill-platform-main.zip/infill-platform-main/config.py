"""Runtime settings, loaded from environment (.env in dev). Kept dependency-light
so the ingestion/scoring code can import it without pulling the web stack."""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

_ROOT = Path(__file__).resolve().parent


def _load_dotenv() -> None:
    env = _ROOT / ".env"
    if not env.exists():
        return
    for line in env.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        os.environ.setdefault(k.strip(), v.strip())


_load_dotenv()


def _envflag(name: str) -> bool:
    """Read a boolean env var, defaulting to FALSE when unset or unrecognised.

    Used for switches that loosen security, so anything other than an explicit
    opt-in has to read as off — an operator who never sets the variable, or sets
    it to something we don't understand, must get the safe behaviour.
    """
    return os.environ.get(name, "").strip().lower() in {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class Settings:
    database_url: str = os.environ.get(
        "DATABASE_URL", "postgresql://infill:infill@localhost:5432/infill")
    s3_endpoint: str = os.environ.get("S3_ENDPOINT", "")
    s3_bucket_raw: str = os.environ.get("S3_BUCKET_RAW", "infill-raw")
    s3_access_key: str = os.environ.get("S3_ACCESS_KEY", "")
    s3_secret_key: str = os.environ.get("S3_SECRET_KEY", "")
    socrata_app_token: str = os.environ.get("SOCRATA_APP_TOKEN", "")
    scoring_config_path: str = os.environ.get(
        "SCORING_CONFIG_PATH", str(_ROOT / "scoring" / "config" / "scoring.yaml"))
    # Local filesystem fallback for the raw archive when no S3/MinIO is configured.
    raw_archive_dir: str = os.environ.get("RAW_ARCHIVE_DIR", str(_ROOT / "data" / "raw"))
    # Where agents' site-visit photos are stored (served back through the API).
    lead_photos_dir: str = os.environ.get("LEAD_PHOTOS_DIR", str(_ROOT / "data" / "lead_photos"))
    lead_photo_max_bytes: int = int(os.environ.get("LEAD_PHOTO_MAX_BYTES", str(15 * 1024 * 1024)))
    # Uploaded LOI/GL letter templates (.docx) for the bulk address tab.
    letter_templates_dir: str = os.environ.get(
        "LETTER_TEMPLATES_DIR", str(_ROOT / "data" / "letter_templates"))
    letter_template_max_bytes: int = int(
        os.environ.get("LETTER_TEMPLATE_MAX_BYTES", str(5 * 1024 * 1024)))
    # Alerting: notify when a parcel newly crosses the threshold, or jumps by
    # min_jump into the interesting range. Delivery: Slack webhook or stdout.
    alert_score_threshold: float = float(os.environ.get("ALERT_SCORE_THRESHOLD", "70"))
    alert_min_jump: float = float(os.environ.get("ALERT_MIN_JUMP", "15"))
    alert_slack_webhook: str = os.environ.get("ALERT_SLACK_WEBHOOK", "")
    # --- Identity ---------------------------------------------------------
    # In production the ONLY trusted identity is the Cf-Access-Authenticated-User-Email
    # header that Cloudflare Access injects. A client can set X-User-Email or send
    # no header at all, so honouring either of those means anyone can read and
    # write any agent's leads.
    #
    # DEV_AUTH gates that convenience, and it defaults to FALSE so a deploy that
    # forgets to set anything fails CLOSED (401) instead of silently signing every
    # visitor in as the same shared user. Local dev opts in via .env.
    dev_auth: bool = _envflag("DEV_AUTH")
    # identity for notes/My-Leads when Cloudflare Access isn't in front (local dev
    # only — inert unless dev_auth is on)
    dev_user_email: str = os.environ.get("DEV_USER_EMAIL", "dev@local")
    # Optional Google Maps key: when set, the dossier embeds a Street View Static
    # image of the house (the "drive-by" recreated inline). Without it, the dossier
    # still deep-links to Street View / aerial (free, no key). Google's ~$200/mo
    # credit covers ~28k image loads. Display only — Google's terms forbid running
    # ML/analysis on the imagery, so it's never used for the condition score.
    google_maps_key: str = os.environ.get("GOOGLE_MAPS_KEY", "")
    # Public origin the app's own response page (/r/{token}) is served from — used
    # only when outreach_link_url is blank (i.e. self-hosted response tracking).
    public_base_url: str = os.environ.get("PUBLIC_BASE_URL", "http://localhost:8000")
    # Where the letter's QR / short link sends owners. Defaults to the Oyler Hines
    # website (works today, no deploy, but no automatic per-owner response tracking).
    # Set to "" to instead use the app's tracked /r/{token} page (once it's deployed
    # publicly at PUBLIC_BASE_URL).
    outreach_link_url: str = os.environ.get("OUTREACH_LINK_URL", "https://oylerhines.com/")
    # The team's target markets. The app focuses on these — the region picker,
    # map, ranked list, and export are all scoped to them so non-target areas
    # don't clutter the tool. Override with TARGET_REGIONS (comma-separated).
    target_regions: tuple = tuple(
        r.strip() for r in os.environ.get(
            "TARGET_REGIONS",
            "Madeira,Montgomery,Indian Hill,Blue Ash,Symmes Township,Hyde Park,Oakley"
        ).split(",") if r.strip())


settings = Settings()
